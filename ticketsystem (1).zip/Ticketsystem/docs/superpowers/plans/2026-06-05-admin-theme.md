# Admin Theme Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** When an admin logs in to `dashboard/user.php`, automatically apply a dark charcoal theme, show "Admin" instead of their username, and display a three-card stats bar (total tickets, open, high priority).

**Architecture:** All changes are confined to `dashboard/user.php`. A `body.admin-theme` CSS class drives the entire theme switch via CSS variable overrides. PHP conditionals handle the class, the display name, and the stats bar HTML. No new files, no extra DB queries — the stats variables (`$count_all`, `$count_open`, `$count_high`) are already computed at the top of the file.

**Tech Stack:** PHP 8, CSS custom properties, vanilla HTML.

---

## File Map

| File | Change |
|------|--------|
| `dashboard/user.php` | Add dark CSS block, body class, `$display_name` variable, stats bar HTML |

---

## Task 1: Dark theme CSS

**Files:**
- Modify: `dashboard/user.php:343-347` (just before `</style>`)

- [ ] **Step 1: Add the dark theme and stats bar CSS block**

Find these lines (343–347):
```
      .ticket-row > :nth-child(7) { display: none; }
      .main { padding: 20px; }
    }
    @media (max-width: 560px) {
      .stats { grid-template-columns: 1fr; }
      .tickets-toolbar { flex-direction: column; align-items: flex-start; }
    }
  </style>
```

Replace with:
```
      .ticket-row > :nth-child(7) { display: none; }
      .main { padding: 20px; }
    }
    @media (max-width: 560px) {
      .stats { grid-template-columns: 1fr; }
      .tickets-toolbar { flex-direction: column; align-items: flex-start; }
    }

    /* ── Admin dark theme ── */
    body.admin-theme {
      --bg:            #111827;
      --surface:       #1F2937;
      --surface-2:     #374151;
      --border:        #374151;
      --border-strong: #4B5563;
      --text:          #F9FAFB;
      --text-muted:    #D1D5DB;
      --text-subtle:   #9CA3AF;
    }
    body.admin-theme .btn-outline {
      background: #1F2937;
      border-color: #374151;
    }

    /* ── Admin stats bar ── */
    .stats-bar {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 16px;
      margin-bottom: 24px;
    }
    .stat-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--r-lg);
      padding: 20px 24px;
    }
    .stat-number {
      font-size: 28px;
      font-weight: 700;
      letter-spacing: -0.03em;
      color: var(--text);
    }
    .stat-label {
      font-size: 12px;
      color: var(--text-muted);
      margin-top: 4px;
    }
  </style>
```

- [ ] **Step 2: Verify PHP syntax**

```bash
php -l /Users/youssef/Projects/Ticketsystem/dashboard/user.php
```

Expected: `No syntax errors detected`

- [ ] **Step 3: Commit**

```bash
git add dashboard/user.php
git commit -m "style: add admin dark theme and stats bar CSS"
```

---

## Task 2: PHP changes — body class, display name, stats bar HTML

**Files:**
- Modify: `dashboard/user.php:7` (display name variable)
- Modify: `dashboard/user.php:349` (body tag)
- Modify: `dashboard/user.php:406` (sidebar username)
- Modify: `dashboard/user.php:418` (welcome heading username)
- Modify: `dashboard/user.php:426-428` (insert stats bar between main-head and existing stats)

- [ ] **Step 1: Add `$display_name` variable after line 7**

Find:
```php
$username = $_SESSION['username'];
```

Replace with:
```php
$username     = $_SESSION['username'];
$display_name = is_admin() ? 'Admin' : $username;
```

- [ ] **Step 2: Add `admin-theme` class to `<body>` tag**

Find:
```html
<body>
```

Replace with:
```html
<body<?php if (is_admin()): ?> class="admin-theme"<?php endif; ?>>
```

- [ ] **Step 3: Update sidebar username display**

Find:
```php
          <div class="sidebar-user-name"><?php echo htmlspecialchars($username); ?></div>
```

Replace with:
```php
          <div class="sidebar-user-name"><?php echo htmlspecialchars($display_name); ?></div>
```

Note: the avatar initials line (`strtoupper(substr($username, 0, 2))`) stays unchanged — it should keep showing the real initials.

- [ ] **Step 4: Update welcome heading**

Find:
```php
        <h1>Welcome back, <?php echo htmlspecialchars($username); ?>.</h1>
```

Replace with:
```php
        <h1>Welcome back, <?php echo htmlspecialchars($display_name); ?>.</h1>
```

- [ ] **Step 5: Insert admin stats bar between main-head and existing stats**

Find:
```html
    </div>

    <!-- Stats -->
    <div class="stats">
```

Replace with:
```html
    </div>

    <?php if (is_admin()): ?>
    <div class="stats-bar">
      <div class="stat-card">
        <div class="stat-number"><?php echo (int)$count_all; ?></div>
        <div class="stat-label">Total Tickets</div>
      </div>
      <div class="stat-card">
        <div class="stat-number"><?php echo (int)$count_open; ?></div>
        <div class="stat-label">Open</div>
      </div>
      <div class="stat-card">
        <div class="stat-number"><?php echo (int)$count_high; ?></div>
        <div class="stat-label">High Priority</div>
      </div>
    </div>
    <?php endif; ?>

    <!-- Stats -->
    <div class="stats">
```

- [ ] **Step 6: Verify PHP syntax**

```bash
php -l /Users/youssef/Projects/Ticketsystem/dashboard/user.php
```

Expected: `No syntax errors detected`

- [ ] **Step 7: Manual smoke test**

1. Log in as a regular user → page should have light theme, no stats bar, username shown in sidebar and heading
2. Log in as admin → page should be dark charcoal, "Admin" shown in sidebar and heading, three stat cards visible above the regular stats row, avatar initials still show the real username initials

- [ ] **Step 8: Commit**

```bash
git add dashboard/user.php
git commit -m "feat: admin dark theme, display name, and stats bar"
```
