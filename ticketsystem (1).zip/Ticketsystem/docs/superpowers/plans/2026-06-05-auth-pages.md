# Auth Pages Redesign Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the light-theme inline-styled auth pages with a dark split-panel design using the shared design system and dot-matrix canvas animation.

**Architecture:** A new `public/css/auth.css` holds shared auth layout CSS (split shell, left panel, form shell, toggles). Each page links `app.css` + `auth.css` in `<head>` and `canvas.js` before `</body>`. The HTML shell on each page is fully rewritten — all PHP business logic is untouched.

**Tech Stack:** PHP 8, `public/css/app.css` (existing), `public/css/auth.css` (new), `public/js/canvas.js` (existing).

---

## File Map

| File | Change |
|------|--------|
| `public/css/auth.css` | Create — shared auth layout CSS |
| `auth/login.php` | Modify — replace HTML shell, keep PHP logic |
| `auth/register.php` | Modify — replace HTML shell, keep PHP logic |
| `auth/change-password.php` | Modify — replace HTML shell, keep PHP logic |

---

## Task 1: Create `public/css/auth.css`

**Files:**
- Create: `public/css/auth.css`

- [ ] **Step 1: Create the shared auth layout stylesheet**

Create `/Users/youssef/Projects/Ticketsystem/public/css/auth.css` with this exact content:

```css
/* ── Auth pages shared layout ── */

.auth-shell {
  display: grid;
  grid-template-columns: 1fr 1fr;
  min-height: 100vh;
  position: relative;
  z-index: 1;
}

/* Left panel — transparent so canvas shows through */
.auth-aside {
  position: relative;
  z-index: 1;
  padding: 48px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.auth-aside::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(ellipse 80% 60% at 30% 30%, rgba(79, 70, 229, 0.18), transparent 65%),
    linear-gradient(180deg, rgba(15, 15, 19, 0.55) 0%, rgba(15, 15, 19, 0.25) 100%);
  pointer-events: none;
  z-index: 0;
}

/* Wordmark */
.aside-logo {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 15px;
  font-weight: 600;
  color: var(--text);
  position: relative;
  z-index: 1;
}
.aside-logo-mark {
  width: 30px;
  height: 30px;
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.12);
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: var(--font-mono);
  font-size: 11px;
  font-weight: 700;
}

/* Glass ticket card */
.aside-ticket {
  margin-top: 48px;
  background: rgba(255, 255, 255, 0.04);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: var(--r-lg);
  padding: 20px 22px;
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  position: relative;
  z-index: 1;
}
.aside-ticket-top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}
.aside-ticket-id {
  font-size: 12px;
  color: var(--text-subtle);
}
.aside-ticket-title {
  font-size: 14px;
  font-weight: 500;
  color: var(--text);
  margin-bottom: 8px;
  line-height: 1.4;
}
.aside-ticket-meta {
  font-size: 12px;
  color: var(--text-muted);
}

/* Tagline */
.aside-tagline {
  margin-top: auto;
  font-size: 34px;
  font-weight: 700;
  letter-spacing: -0.03em;
  line-height: 1.1;
  color: var(--text);
  position: relative;
  z-index: 1;
}

/* Right panel */
.auth-form-wrap {
  background: var(--surface);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 48px;
  position: relative;
  z-index: 1;
}
.auth-form {
  width: 100%;
  max-width: 400px;
  display: flex;
  flex-direction: column;
}

/* Heading */
.auth-form h1 {
  font-size: 40px;
  font-weight: 700;
  letter-spacing: -0.03em;
  line-height: 1.05;
  color: var(--text);
  margin-bottom: 8px;
}
.auth-lede {
  font-size: 15px;
  color: var(--text-muted);
  margin-bottom: 28px;
}

/* Alerts */
.alert-error {
  background: var(--priority-high-soft);
  color: var(--priority-high);
  border: 1px solid rgba(239, 68, 68, 0.25);
  border-radius: var(--r);
  padding: 12px 16px;
  font-size: 13px;
  line-height: 1.5;
  margin-bottom: 20px;
}
.alert-error ul { margin: 4px 0 0 16px; padding: 0; }
.alert-success {
  background: var(--priority-low-soft);
  color: var(--priority-low);
  border: 1px solid rgba(34, 197, 94, 0.25);
  border-radius: var(--r);
  padding: 12px 16px;
  font-size: 13px;
  margin-bottom: 20px;
}

/* Fields container */
.fields {
  display: flex;
  flex-direction: column;
  gap: 16px;
  margin-bottom: 24px;
}

/* Password toggle */
.password-wrap { position: relative; }
.password-wrap .input { padding-right: 44px; }
.password-toggle {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  padding: 4px;
  border-radius: 6px;
  color: var(--text-muted);
  transition: color 140ms ease;
  line-height: 1;
}
.password-toggle:hover { color: var(--text); }

/* Submit button full-width modifier */
.btn-block { width: 100%; margin-top: 24px; }

/* Back link (change-password only) */
.auth-back {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  font-weight: 500;
  color: var(--text-muted);
  margin-bottom: 28px;
  transition: color 140ms ease;
}
.auth-back:hover { color: var(--text); }

/* Page-switch link */
.auth-switch {
  text-align: center;
  font-size: 14px;
  color: var(--text-muted);
  margin-top: 20px;
}
.auth-switch a { color: var(--brand); font-weight: 500; }
.auth-switch a:hover { text-decoration: underline; }

/* Responsive */
@media (max-width: 900px) {
  .auth-shell { grid-template-columns: 1fr; }
  .auth-aside { display: none; }
  .auth-form-wrap { padding: 32px 24px; align-items: flex-start; padding-top: 48px; }
}
```

- [ ] **Step 2: Verify the file was created**

```bash
ls -la /Users/youssef/Projects/Ticketsystem/public/css/
```

Expected: `app.css` and `auth.css` both listed.

---

## Task 2: Redesign `auth/login.php`

**Files:**
- Modify: `auth/login.php` — lines 53–end (HTML shell only, PHP logic on lines 1–52 is untouched)

The PHP logic ends at line 52 (`unset($_SESSION['flash_success']);`). Everything from the closing `?>` and the `<!doctype html>` onward is replaced.

- [ ] **Step 1: Replace the HTML shell**

Find the line:
```php
$flash = $_SESSION['flash_success'] ?? null;
unset($_SESSION['flash_success']);
?>
<!doctype html>
```

Keep the PHP lines as-is. Replace everything from `?>` to the end of the file with:

```php
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign in — TicketSystem</title>
  <link rel="stylesheet" href="/public/css/app.css">
  <link rel="stylesheet" href="/public/css/auth.css">
</head>
<body>

<div class="auth-shell">

  <aside class="auth-aside">
    <div class="aside-logo">
      <span class="aside-logo-mark">TS</span>
      TicketSystem
    </div>

    <div class="aside-ticket">
      <div class="aside-ticket-top">
        <span class="aside-ticket-id font-mono">TS-042</span>
        <span class="pill priority-high"><span class="pill-dot"></span>High</span>
      </div>
      <div class="aside-ticket-title">API gateway timeout on /tickets endpoint</div>
      <div class="aside-ticket-meta">Opened 3m ago &middot; Assigned to you</div>
    </div>

    <div class="aside-tagline">
      Every issue tracked.<br>Nothing lost.
    </div>
  </aside>

  <div class="auth-form-wrap">
    <form class="auth-form" method="POST" action="/auth/login.php">

      <h1>Welcome back.</h1>
      <p class="auth-lede">Sign in to your workspace.</p>

      <?php if (!empty($errors)): ?>
        <div class="alert-error">
          <?php if (count($errors) === 1): ?>
            <?php echo htmlspecialchars($errors[0]); ?>
          <?php else: ?>
            <ul>
              <?php foreach ($errors as $error): ?>
                <li><?php echo htmlspecialchars($error); ?></li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>
      <?php endif; ?>

      <?php if ($flash): ?>
        <div class="alert-success"><?php echo htmlspecialchars($flash); ?></div>
      <?php endif; ?>

      <div class="fields">

        <div class="form-group">
          <label class="label" for="email">Email</label>
          <input
            class="input"
            type="email"
            id="email"
            name="email"
            value="<?php echo htmlspecialchars($email); ?>"
            placeholder="you@example.com"
            autocomplete="email"
            required>
        </div>

        <div class="form-group">
          <label class="label" for="password">Password</label>
          <div class="password-wrap">
            <input
              class="input"
              type="password"
              id="password"
              name="password"
              placeholder="Enter your password"
              autocomplete="current-password"
              required>
            <button type="button" class="password-toggle" onclick="togglePw('password','pw-icon1')" aria-label="Show or hide password">
              <span id="pw-icon1"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></span>
            </button>
          </div>
        </div>

      </div>

      <button type="submit" class="btn btn-primary btn-lg btn-block">Sign in</button>

      <p class="auth-switch">
        Don&rsquo;t have an account? <a href="/auth/register.php">Create one</a>
      </p>

    </form>
  </div>

</div>

<script>
var SVG_EYE     = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
var SVG_EYE_OFF = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>';
function togglePw(fieldId, iconId) {
  var input = document.getElementById(fieldId);
  var icon  = document.getElementById(iconId);
  if (input.type === 'password') {
    input.type = 'text';
    icon.innerHTML = SVG_EYE_OFF;
  } else {
    input.type = 'password';
    icon.innerHTML = SVG_EYE;
  }
}
</script>
<script src="/public/js/canvas.js"></script>
</body>
</html>
```

- [ ] **Step 2: Verify PHP syntax**

```bash
php -l /Users/youssef/Projects/Ticketsystem/auth/login.php
```

Expected: `No syntax errors detected in /Users/youssef/Projects/Ticketsystem/auth/login.php`

---

## Task 3: Redesign `auth/register.php`

**Files:**
- Modify: `auth/register.php` — HTML shell only, PHP logic untouched

The PHP logic runs from line 1 to roughly line 70 (ends with a `header('Location: ...')` or `$flash` setup before the closing `?>`). Replace from the closing `?>` before `<!doctype html>` to the end of file.

- [ ] **Step 1: Replace the HTML shell**

Find the `?>` that precedes `<!doctype html>` and replace from there to the end of file with:

```php
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create account — TicketSystem</title>
  <link rel="stylesheet" href="/public/css/app.css">
  <link rel="stylesheet" href="/public/css/auth.css">
</head>
<body>

<div class="auth-shell">

  <aside class="auth-aside">
    <div class="aside-logo">
      <span class="aside-logo-mark">TS</span>
      TicketSystem
    </div>

    <div class="aside-ticket">
      <div class="aside-ticket-top">
        <span class="aside-ticket-id font-mono">TS-042</span>
        <span class="pill priority-high"><span class="pill-dot"></span>High</span>
      </div>
      <div class="aside-ticket-title">API gateway timeout on /tickets endpoint</div>
      <div class="aside-ticket-meta">Opened 3m ago &middot; Assigned to you</div>
    </div>

    <div class="aside-tagline">
      Every issue tracked.<br>Nothing lost.
    </div>
  </aside>

  <div class="auth-form-wrap">
    <form class="auth-form" method="POST" action="/auth/register.php">

      <h1>Create account.</h1>
      <p class="auth-lede">Join TicketSystem today.</p>

      <?php if (!empty($errors)): ?>
        <div class="alert-error">
          <?php if (count($errors) === 1): ?>
            <?php echo htmlspecialchars($errors[0]); ?>
          <?php else: ?>
            <ul>
              <?php foreach ($errors as $error): ?>
                <li><?php echo htmlspecialchars($error); ?></li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>
      <?php endif; ?>

      <div class="fields">

        <div class="form-group">
          <label class="label" for="username">Username</label>
          <input
            class="input"
            type="text"
            id="username"
            name="username"
            value="<?php echo htmlspecialchars($username); ?>"
            placeholder="yourname"
            autocomplete="username"
            required>
        </div>

        <div class="form-group">
          <label class="label" for="email">Email</label>
          <input
            class="input"
            type="email"
            id="email"
            name="email"
            value="<?php echo htmlspecialchars($email); ?>"
            placeholder="you@example.com"
            autocomplete="email"
            required>
        </div>

        <div class="form-group">
          <label class="label" for="password">Password</label>
          <div class="password-wrap">
            <input
              class="input"
              type="password"
              id="password"
              name="password"
              placeholder="At least 8 characters"
              autocomplete="new-password"
              required>
            <button type="button" class="password-toggle" onclick="togglePw('password','pw-icon1')" aria-label="Show or hide password">
              <span id="pw-icon1"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></span>
            </button>
          </div>
        </div>

        <div class="form-group">
          <label class="label" for="confirm_password">Confirm password</label>
          <div class="password-wrap">
            <input
              class="input"
              type="password"
              id="confirm_password"
              name="confirm_password"
              placeholder="Repeat your password"
              autocomplete="new-password"
              required>
            <button type="button" class="password-toggle" onclick="togglePw('confirm_password','pw-icon2')" aria-label="Show or hide password">
              <span id="pw-icon2"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></span>
            </button>
          </div>
        </div>

      </div>

      <button type="submit" class="btn btn-primary btn-lg btn-block">Create account</button>

      <p class="auth-switch">
        Already have an account? <a href="/auth/login.php">Sign in</a>
      </p>

    </form>
  </div>

</div>

<script>
var SVG_EYE     = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
var SVG_EYE_OFF = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>';
function togglePw(fieldId, iconId) {
  var input = document.getElementById(fieldId);
  var icon  = document.getElementById(iconId);
  if (input.type === 'password') {
    input.type = 'text';
    icon.innerHTML = SVG_EYE_OFF;
  } else {
    input.type = 'password';
    icon.innerHTML = SVG_EYE;
  }
}
</script>
<script src="/public/js/canvas.js"></script>
</body>
</html>
```

- [ ] **Step 2: Verify PHP syntax**

```bash
php -l /Users/youssef/Projects/Ticketsystem/auth/register.php
```

Expected: `No syntax errors detected in /Users/youssef/Projects/Ticketsystem/auth/register.php`

---

## Task 4: Redesign `auth/change-password.php`

**Files:**
- Modify: `auth/change-password.php` — HTML shell only, PHP logic untouched

This page is accessed while logged in (it calls `require_login()`). The left panel tagline differs from login/register. No `.auth-switch` link at the bottom — instead a back link at the top of the form.

- [ ] **Step 1: Replace the HTML shell**

Find the `?>` that precedes `<!doctype html>` and replace from there to the end of file with:

```php
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Change password — TicketSystem</title>
  <link rel="stylesheet" href="/public/css/app.css">
  <link rel="stylesheet" href="/public/css/auth.css">
</head>
<body>

<div class="auth-shell">

  <aside class="auth-aside">
    <div class="aside-logo">
      <span class="aside-logo-mark">TS</span>
      TicketSystem
    </div>

    <div class="aside-ticket">
      <div class="aside-ticket-top">
        <span class="aside-ticket-id font-mono">TS-042</span>
        <span class="pill priority-high"><span class="pill-dot"></span>High</span>
      </div>
      <div class="aside-ticket-title">API gateway timeout on /tickets endpoint</div>
      <div class="aside-ticket-meta">Opened 3m ago &middot; Assigned to you</div>
    </div>

    <div class="aside-tagline">
      Keep your account<br>secure.
    </div>
  </aside>

  <div class="auth-form-wrap">
    <form class="auth-form" method="POST" action="/auth/change-password.php">

      <a href="/dashboard/user.php" class="auth-back">&larr; Dashboard</a>

      <h1>New password.</h1>
      <p class="auth-lede">Choose a strong password.</p>

      <?php if (!empty($errors)): ?>
        <div class="alert-error">
          <?php if (count($errors) === 1): ?>
            <?php echo htmlspecialchars($errors[0]); ?>
          <?php else: ?>
            <ul>
              <?php foreach ($errors as $error): ?>
                <li><?php echo htmlspecialchars($error); ?></li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>
      <?php endif; ?>

      <?php if ($flash): ?>
        <div class="alert-success"><?php echo htmlspecialchars($flash); ?></div>
      <?php endif; ?>

      <div class="fields">

        <div class="form-group">
          <label class="label" for="current_password">Current password</label>
          <div class="password-wrap">
            <input
              class="input"
              type="password"
              id="current_password"
              name="current_password"
              placeholder="Enter current password"
              autocomplete="current-password"
              required>
            <button type="button" class="password-toggle" onclick="togglePw('current_password','pw-icon1')" aria-label="Show or hide password">
              <span id="pw-icon1"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></span>
            </button>
          </div>
        </div>

        <div class="form-group">
          <label class="label" for="new_password">New password</label>
          <div class="password-wrap">
            <input
              class="input"
              type="password"
              id="new_password"
              name="new_password"
              placeholder="At least 8 characters"
              autocomplete="new-password"
              required>
            <button type="button" class="password-toggle" onclick="togglePw('new_password','pw-icon2')" aria-label="Show or hide password">
              <span id="pw-icon2"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></span>
            </button>
          </div>
        </div>

        <div class="form-group">
          <label class="label" for="confirm_password">Confirm new password</label>
          <div class="password-wrap">
            <input
              class="input"
              type="password"
              id="confirm_password"
              name="confirm_password"
              placeholder="Repeat new password"
              autocomplete="new-password"
              required>
            <button type="button" class="password-toggle" onclick="togglePw('confirm_password','pw-icon3')" aria-label="Show or hide password">
              <span id="pw-icon3"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></span>
            </button>
          </div>
        </div>

      </div>

      <button type="submit" class="btn btn-primary btn-lg btn-block">Update password</button>

    </form>
  </div>

</div>

<script>
var SVG_EYE     = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
var SVG_EYE_OFF = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>';
function togglePw(fieldId, iconId) {
  var input = document.getElementById(fieldId);
  var icon  = document.getElementById(iconId);
  if (input.type === 'password') {
    input.type = 'text';
    icon.innerHTML = SVG_EYE_OFF;
  } else {
    input.type = 'password';
    icon.innerHTML = SVG_EYE;
  }
}
</script>
<script src="/public/js/canvas.js"></script>
</body>
</html>
```

- [ ] **Step 2: Verify PHP syntax**

```bash
php -l /Users/youssef/Projects/Ticketsystem/auth/change-password.php
```

Expected: `No syntax errors detected in /Users/youssef/Projects/Ticketsystem/auth/change-password.php`

---

## Smoke Test

Run after all four tasks are complete.

- [ ] **Login page** — visit `http://localhost/auth/login.php`
  - Dot-matrix canvas pulses in the background behind the left panel
  - Left: "TS" wordmark, glass ticket card (TS-042 / High / title / meta), tagline "Every issue tracked. Nothing lost."
  - Right: dark surface, "Welcome back." heading, email + password fields, indigo "Sign in" button
  - Eye icon toggles password visibility
  - Submit empty: red alert box appears with error text
  - "Create one" link navigates to register page

- [ ] **Register page** — visit `http://localhost/auth/register.php`
  - Same left panel as login
  - Right: "Create account." heading, 4 fields (username, email, password, confirm password), both password fields have toggles
  - "Sign in" link at bottom navigates to login

- [ ] **Change-password page** — visit `http://localhost/auth/change-password.php` (must be logged in first)
  - Left panel tagline reads "Keep your account secure."
  - Right: "← Dashboard" back link above "New password." heading
  - 3 password fields all with toggles
  - No page-switch link at the bottom
  - Submit with wrong current password: error alert appears

- [ ] **Responsive** — resize browser window below 900px wide on any auth page
  - Left panel disappears entirely
  - Form fills full width with comfortable padding
