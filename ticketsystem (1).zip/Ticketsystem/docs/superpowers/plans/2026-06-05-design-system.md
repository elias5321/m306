# Design System Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Create `public/css/app.css` (shared design tokens + components) and `public/js/canvas.js` (animated dot-matrix background engine) as the foundation for TicketSystem's full dark redesign.

**Architecture:** Two standalone files — no build tools, no npm. `app.css` uses CSS custom properties for all tokens and defines every reusable component class. `canvas.js` is a self-contained IIFE that injects a fixed canvas into any page and animates an indigo dot-matrix grid. Pages link them in sub-projects 2–4.

**Tech Stack:** Vanilla CSS, vanilla JS (Canvas 2D API), Google Fonts (Space Grotesk + Space Mono).

---

## File Map

| File | Change |
|------|--------|
| `public/css/app.css` | **Create** — all tokens, reset, component classes, utilities |
| `public/js/canvas.js` | **Create** — dot-matrix animation IIFE |

---

## Task 1: Create `public/css/app.css`

**Files:**
- Create: `public/css/app.css`

- [ ] **Step 1: Create the `public/css/` directory**

```bash
mkdir -p /Users/youssef/Projects/Ticketsystem/public/css
```

- [ ] **Step 2: Create `public/css/app.css` with this exact content**

```css
/* ═══════════════════════════════════════════════
   TicketSystem — Shared Design System
   Dark charcoal + indigo theme
   ═══════════════════════════════════════════════ */

/* ── Google Fonts ── */
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Space+Mono:ital,wght@0,400;0,700;1,400&display=swap');

/* ── Design Tokens ── */
:root {
  /* Backgrounds */
  --bg:          #0F0F13;
  --surface:     #16161C;
  --surface-2:   #1E1E26;
  --surface-3:   #252530;

  /* Borders */
  --border:        #2A2A35;
  --border-strong: #3A3A48;

  /* Text */
  --text:        #F0F0F5;
  --text-muted:  #8888A0;
  --text-subtle: #555568;

  /* Brand */
  --brand:      #4F46E5;
  --brand-deep: #3730A3;
  --brand-soft: rgba(79, 70, 229, 0.15);

  /* Priority */
  --priority-low:         #22C55E;
  --priority-low-soft:    rgba(34, 197, 94, 0.12);
  --priority-medium:      #F59E0B;
  --priority-medium-soft: rgba(245, 158, 11, 0.12);
  --priority-high:        #EF4444;
  --priority-high-soft:   rgba(239, 68, 68, 0.12);

  /* Status */
  --status-open:          #3B82F6;
  --status-open-soft:     rgba(59, 130, 246, 0.12);
  --status-progress:      #A855F7;
  --status-progress-soft: rgba(168, 85, 247, 0.12);
  --status-closed:        #6B7280;
  --status-closed-soft:   rgba(107, 114, 128, 0.12);

  /* Shape */
  --r:    10px;
  --r-lg: 14px;
  --r-xl: 20px;

  /* Shadows */
  --sh:    0 4px 24px rgba(0, 0, 0, 0.4);
  --sh-lg: 0 8px 40px rgba(0, 0, 0, 0.6);

  /* Typography */
  --font-sans: 'Space Grotesk', ui-sans-serif, system-ui, sans-serif;
  --font-mono: 'Space Mono', ui-monospace, monospace;
}

/* ── Reset ── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

html { scroll-behavior: smooth; }

body {
  font-family: var(--font-sans);
  background: var(--bg);
  color: var(--text);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  letter-spacing: -0.01em;
  line-height: 1.5;
}

a { color: inherit; text-decoration: none; }
button { font: inherit; cursor: pointer; border: none; background: none; color: inherit; }
img, svg { display: block; }
input, select, textarea { font: inherit; }

/* ── Buttons ── */
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 0 20px;
  height: 38px;
  border-radius: 999px;
  font-family: var(--font-sans);
  font-size: 13px;
  font-weight: 600;
  letter-spacing: 0.01em;
  transition: all 180ms ease;
  white-space: nowrap;
  text-decoration: none;
  cursor: pointer;
  border: 1px solid transparent;
}
.btn-sm  { height: 30px; padding: 0 14px; font-size: 12px; }
.btn-lg  { height: 46px; padding: 0 28px; font-size: 15px; }

.btn-primary {
  background: var(--brand);
  color: #fff;
  box-shadow: 0 0 0 rgba(79, 70, 229, 0);
}
.btn-primary:hover {
  background: var(--brand-deep);
  box-shadow: 0 0 24px rgba(79, 70, 229, 0.45);
  transform: translateY(-1px);
}
.btn-primary:active { transform: translateY(0); }

.btn-ghost {
  background: transparent;
  color: var(--text-muted);
  border-color: var(--border);
}
.btn-ghost:hover {
  border-color: var(--brand);
  color: var(--brand);
  background: var(--brand-soft);
}

.btn-danger {
  background: rgba(239, 68, 68, 0.10);
  color: var(--priority-high);
  border-color: rgba(239, 68, 68, 0.20);
}
.btn-danger:hover {
  background: rgba(239, 68, 68, 0.18);
  border-color: rgba(239, 68, 68, 0.35);
}

.btn:disabled,
.btn[disabled] {
  opacity: 0.4;
  cursor: not-allowed;
  transform: none !important;
  box-shadow: none !important;
}

/* ── Inputs ── */
.input {
  display: block;
  width: 100%;
  font-family: var(--font-sans);
  font-size: 14px;
  color: var(--text);
  background: var(--surface-2);
  border: 1px solid var(--border);
  border-radius: var(--r);
  padding: 10px 14px;
  transition: border-color 150ms ease, box-shadow 150ms ease;
  outline: none;
}
.input::placeholder { color: var(--text-subtle); }
.input:focus {
  border-color: var(--brand);
  box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.15);
}
.input:disabled { opacity: 0.5; cursor: not-allowed; }

select.input { cursor: pointer; }

textarea.input {
  resize: vertical;
  min-height: 100px;
  line-height: 1.6;
  padding-top: 12px;
}

/* ── Label ── */
.label {
  display: block;
  font-size: 11px;
  font-weight: 600;
  color: var(--text-muted);
  letter-spacing: 0.08em;
  text-transform: uppercase;
  margin-bottom: 6px;
}

/* ── Form group ── */
.form-group { display: flex; flex-direction: column; gap: 6px; }
.form-error { font-size: 12px; color: var(--priority-high); margin-top: 4px; }

/* ── Cards ── */
.card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r-lg);
  box-shadow: var(--sh);
}
.card-elevated {
  background: var(--surface);
  border: 1px solid var(--border-strong);
  border-radius: var(--r-xl);
  box-shadow: var(--sh-lg);
}

/* ── Pills / Badges ── */
.pill {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 3px 10px;
  border-radius: 999px;
  font-family: var(--font-mono);
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}
.pill-dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: currentColor;
  flex-shrink: 0;
}

.priority-low    { background: var(--priority-low-soft);    color: var(--priority-low);    }
.priority-medium { background: var(--priority-medium-soft); color: var(--priority-medium); }
.priority-high   { background: var(--priority-high-soft);   color: var(--priority-high);   }

.status-open     { background: var(--status-open-soft);     color: var(--status-open);     }
.status-progress { background: var(--status-progress-soft); color: var(--status-progress); }
.status-closed   { background: var(--status-closed-soft);   color: var(--status-closed);   }

/* ── Flash Toast ── */
.toast {
  position: fixed;
  bottom: 28px;
  left: 50%;
  transform: translateX(-50%) translateY(0);
  background: var(--surface);
  border: 1px solid var(--border-strong);
  border-left: 3px solid var(--brand);
  border-radius: var(--r);
  padding: 13px 22px;
  font-size: 13px;
  font-weight: 500;
  color: var(--text);
  box-shadow: var(--sh-lg);
  z-index: 9999;
  white-space: nowrap;
  animation: toast-slide-in 0.32s cubic-bezier(0.16, 1, 0.3, 1) forwards;
}
.toast-error { border-left-color: var(--priority-high); }
.toast-success { border-left-color: var(--priority-low); }

@keyframes toast-slide-in {
  from { opacity: 0; transform: translateX(-50%) translateY(14px); }
  to   { opacity: 1; transform: translateX(-50%) translateY(0); }
}

/* ── Divider ── */
.divider {
  display: flex;
  align-items: center;
  gap: 12px;
  color: var(--text-subtle);
  font-size: 12px;
}
.divider::before,
.divider::after {
  content: '';
  flex: 1;
  height: 1px;
  background: var(--border);
}

/* ── Utility Classes ── */
.font-mono   { font-family: var(--font-mono); }
.text-muted  { color: var(--text-muted); }
.text-subtle { color: var(--text-subtle); }
.text-brand  { color: var(--brand); }
.text-danger { color: var(--priority-high); }
.text-success { color: var(--priority-low); }

.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

/* ── Scrollbar ── */
::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-track { background: var(--bg); }
::-webkit-scrollbar-thumb { background: var(--border-strong); border-radius: 999px; }
::-webkit-scrollbar-thumb:hover { background: var(--text-subtle); }

/* ── Selection ── */
::selection { background: rgba(79, 70, 229, 0.3); color: var(--text); }
```

- [ ] **Step 3: Verify the file exists**

```bash
ls -la /Users/youssef/Projects/Ticketsystem/public/css/app.css
```

Expected: file exists, size > 0.

- [ ] **Step 4: Check for obvious CSS syntax issues**

```bash
grep -c "{" /Users/youssef/Projects/Ticketsystem/public/css/app.css
grep -c "}" /Users/youssef/Projects/Ticketsystem/public/css/app.css
```

Expected: both counts should be equal (every opening brace has a closing brace).

---

## Task 2: Create `public/js/canvas.js`

**Files:**
- Create: `public/js/canvas.js`

- [ ] **Step 1: Create the `public/js/` directory**

```bash
mkdir -p /Users/youssef/Projects/Ticketsystem/public/js
```

- [ ] **Step 2: Create `public/js/canvas.js` with this exact content**

```javascript
(function () {
  'use strict';

  /* ── Config ── */
  var DOT_RADIUS  = 2;
  var SPACING     = 22;
  var MAX_OPACITY = 0.32;
  var TIME_STEP   = 0.0008;
  var DOT_COLOR   = '79, 70, 229'; /* indigo RGB */

  /* ── Create canvas ── */
  var canvas = document.createElement('canvas');
  var ctx    = canvas.getContext('2d');

  canvas.setAttribute('aria-hidden', 'true');
  canvas.style.cssText =
    'position:fixed;top:0;left:0;width:100%;height:100%;' +
    'z-index:0;pointer-events:none;';

  /* Insert as first child so all page content sits on top */
  document.body.insertBefore(canvas, document.body.firstChild);

  /* ── Grid state ── */
  var cols   = 0;
  var rows   = 0;
  var phases = null;
  var time   = 0;

  /* ── Resize ── */
  function resize() {
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;

    cols = Math.ceil(canvas.width  / SPACING) + 2;
    rows = Math.ceil(canvas.height / SPACING) + 2;

    /* Seed a unique phase offset for every dot so they pulse independently */
    phases = new Float32Array(cols * rows);
    for (var i = 0; i < phases.length; i++) {
      phases[i] = Math.random() * Math.PI * 2;
    }
  }

  /* ── Draw loop ── */
  function draw() {
    var w = canvas.width;
    var h = canvas.height;

    ctx.clearRect(0, 0, w, h);

    /* Centre the grid so edge dots are symmetrical */
    var offsetX = (w % SPACING) * 0.5;
    var offsetY = (h % SPACING) * 0.5;

    for (var r = 0; r < rows; r++) {
      for (var c = 0; c < cols; c++) {
        var idx     = r * cols + c;
        var opacity = ((Math.sin(time + phases[idx]) + 1) * 0.5) * MAX_OPACITY;

        var x = offsetX + c * SPACING;
        var y = offsetY + r * SPACING;

        ctx.beginPath();
        ctx.arc(x, y, DOT_RADIUS, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(' + DOT_COLOR + ',' + opacity.toFixed(3) + ')';
        ctx.fill();
      }
    }

    /* ── Radial vignette ── dims centre for readability, edges stay lively ── */
    var cx   = w * 0.5;
    var cy   = h * 0.5;
    var grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(w, h) * 0.72);
    grad.addColorStop(0,   'rgba(15,15,19,0.82)');
    grad.addColorStop(0.5, 'rgba(15,15,19,0.45)');
    grad.addColorStop(1,   'rgba(15,15,19,0.05)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);

    time += TIME_STEP;
    requestAnimationFrame(draw);
  }

  /* ── Init ── */
  resize();
  window.addEventListener('resize', resize);
  draw();

}());
```

- [ ] **Step 3: Verify the file exists**

```bash
ls -la /Users/youssef/Projects/Ticketsystem/public/js/canvas.js
```

Expected: file exists, size > 0.

- [ ] **Step 4: Quick smoke-test — create a throwaway test page**

```bash
cat > /tmp/canvas-test.html << 'EOF'
<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { margin: 0; background: #0F0F13; font-family: sans-serif; color: #F0F0F5; }
    .centre { position: relative; z-index: 1; display: flex; flex-direction: column;
              align-items: center; justify-content: center; min-height: 100vh; gap: 16px; }
    h1 { font-size: 2.5rem; }
    p  { color: #8888A0; }
  </style>
</head>
<body>
  <div class="centre">
    <h1>Canvas Test</h1>
    <p>You should see an animated indigo dot-grid behind this text.</p>
    <p>Dots should be dimmer in the centre, brighter at edges.</p>
  </div>
  <script src="/Users/youssef/Projects/Ticketsystem/public/js/canvas.js"></script>
</body>
</html>
EOF
echo "Open /tmp/canvas-test.html in a browser to verify the animation."
```

Open `/tmp/canvas-test.html` in your browser. You should see:
- Dark `#0F0F13` background
- Animated indigo dots pulsing slowly
- Dots are dimmer at the centre, more visible at the edges
- Text is readable on top

- [ ] **Step 5: Verify `app.css` is loadable by adding it to the test page**

Add `<link rel="stylesheet" href="/Users/youssef/Projects/Ticketsystem/public/css/app.css">` to the test page's `<head>`. The background should still be dark, fonts should switch to Space Grotesk.

- [ ] **Step 6: Report status**

Confirm:
- `public/css/app.css` exists and has balanced braces
- `public/js/canvas.js` exists and runs without console errors in the test page
- Animation is visible and smooth
