# Role Management (Rollenverwaltung) Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add an `admin` role to TicketHub so admin users get a dedicated `/admin/` panel with full control over every ticket.

**Architecture:** A `role` ENUM column on `users` is loaded into `$_SESSION` at login. Two helpers (`is_admin()`, `require_admin()`) in `includes/session.php` act as the central gate. A new `admin/index.php` provides the admin UI. Three existing files get minimal targeted changes to lift ownership restrictions for admins.

**Tech Stack:** PHP 8, MySQL, PDO, vanilla JS — no new dependencies.

---

## File Map

| File | Change |
|------|--------|
| `admin/index.php` | **Create** — full admin panel |
| `includes/session.php` | Add `is_admin()` and `require_admin()` |
| `auth/login.php` | Fetch `role` in SELECT, store in `$_SESSION` |
| `tickets/delete.php` | Bypass ownership check for admins |
| `tickets/edit.php` | Bypass ownership check for admins in fetch + UPDATE |
| `dashboard/user.php` | Show admin link in sidebar + show actions for admins |

---

## Task 1: Database — add `role` column

**Files:**
- Modify: MySQL database (run SQL directly)

- [ ] **Step 1: Run the migration**

Connect to MySQL and run:

```sql
ALTER TABLE users ADD COLUMN role ENUM('user','admin') NOT NULL DEFAULT 'user';
```

- [ ] **Step 2: Verify the column exists**

```sql
DESCRIBE users;
```

Expected: a row showing `role | enum('user','admin') | NO | | user |`

- [ ] **Step 3: Promote yourself to admin**

```sql
UPDATE users SET role = 'admin' WHERE username = 'youssef';
```

Verify:

```sql
SELECT id, username, role FROM users;
```

Expected: your user row shows `admin`, all others show `user`.

---

## Task 2: Session helpers — `is_admin()` and `require_admin()`

**Files:**
- Modify: `includes/session.php`

Current file content (full):

```php
<?php

session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'secure'   => false,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();


function is_logged_in() {
    return isset($_SESSION['user_id']) && $_SESSION['user_id'] !== '';
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: /auth/login.php');
        exit();
    }
}
?>
```

- [ ] **Step 1: Add the two helpers**

Replace the entire file with:

```php
<?php

session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'secure'   => false,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();


function is_logged_in(): bool {
    return isset($_SESSION['user_id']) && $_SESSION['user_id'] !== '';
}

function require_login(): void {
    if (!is_logged_in()) {
        header('Location: /auth/login.php');
        exit();
    }
}

function is_admin(): bool {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function require_admin(): void {
    require_login();
    if (!is_admin()) {
        header('Location: /dashboard/user.php');
        exit();
    }
}
?>
```

- [ ] **Step 2: Verify the file saved correctly**

```bash
grep -n "is_admin\|require_admin" /Users/youssef/Projects/Ticketsystem/includes/session.php
```

Expected output (4 lines showing the function definitions and bodies).

- [ ] **Step 3: Commit**

```bash
git add includes/session.php
git commit -m "feat: add is_admin() and require_admin() helpers"
```

---

## Task 3: Login — fetch and store `role` in session

**Files:**
- Modify: `auth/login.php` (lines 30–38)

Current code at line 30:

```php
$stmt = $pdo->prepare('SELECT id, username, password FROM users WHERE email = :email LIMIT 1');
$stmt->execute([':email' => $email]);
$user = $stmt->fetch();

if ($user && password_verify($password, $user['password'])) {

    session_regenerate_id(true);
    $_SESSION['user_id']  = $user['id'];
    $_SESSION['username'] = $user['username'];
```

- [ ] **Step 1: Update the SELECT query and session assignment**

Replace those lines with:

```php
$stmt = $pdo->prepare('SELECT id, username, password, role FROM users WHERE email = :email LIMIT 1');
$stmt->execute([':email' => $email]);
$user = $stmt->fetch();

if ($user && password_verify($password, $user['password'])) {

    session_regenerate_id(true);
    $_SESSION['user_id']  = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['role']     = $user['role'];
```

- [ ] **Step 2: Test manually**

Open `http://localhost/auth/login.php`, log in as your admin user, then open a PHP-aware browser tool or add this temporarily to dashboard/user.php to verify:

```php
var_dump($_SESSION['role']); // should print string(5) "admin"
```

Remove the debug line after verifying.

- [ ] **Step 3: Commit**

```bash
git add auth/login.php
git commit -m "feat: store role in session on login"
```

---

## Task 4: Delete — bypass ownership check for admins

**Files:**
- Modify: `tickets/delete.php` (lines 19–20)

Current code:

```php
$stmt = $pdo->prepare('DELETE FROM tickets WHERE id = :id AND user_id = :user_id');
$stmt->execute([':id' => $ticket_id, ':user_id' => $_SESSION['user_id']]);
```

- [ ] **Step 1: Replace with admin-aware delete**

Replace those two lines with:

```php
if (is_admin()) {
    $stmt = $pdo->prepare('DELETE FROM tickets WHERE id = :id');
    $stmt->execute([':id' => $ticket_id]);
} else {
    $stmt = $pdo->prepare('DELETE FROM tickets WHERE id = :id AND user_id = :user_id');
    $stmt->execute([':id' => $ticket_id, ':user_id' => $_SESSION['user_id']]);
}
```

- [ ] **Step 2: Verify the full file looks correct**

```bash
cat -n /Users/youssef/Projects/Ticketsystem/tickets/delete.php
```

Expected: the file has the if/else block, `is_admin()` call, and no other logic changed.

- [ ] **Step 3: Commit**

```bash
git add tickets/delete.php
git commit -m "feat: allow admin to delete any ticket"
```

---

## Task 5: Edit — bypass ownership check for admins

**Files:**
- Modify: `tickets/edit.php` (lines 17–18 and lines 99–111)

**Change 1 — ticket fetch (line 17–18):**

Current:

```php
$stmt = $pdo->prepare('SELECT * FROM tickets WHERE id = :id AND user_id = :user_id');
$stmt->execute([':id' => $ticket_id, ':user_id' => $_SESSION['user_id']]);
```

Replace with:

```php
if (is_admin()) {
    $stmt = $pdo->prepare('SELECT * FROM tickets WHERE id = :id');
    $stmt->execute([':id' => $ticket_id]);
} else {
    $stmt = $pdo->prepare('SELECT * FROM tickets WHERE id = :id AND user_id = :user_id');
    $stmt->execute([':id' => $ticket_id, ':user_id' => $_SESSION['user_id']]);
}
```

**Change 2 — UPDATE query (lines 99–111):**

Current:

```php
if (empty($errors)) {
    $stmt = $pdo->prepare(
        'UPDATE tickets SET title = :title, description = :description,
         status = :status, priority = :priority
         WHERE id = :id AND user_id = :user_id'
    );
    $stmt->execute([
        ':title'       => $title,
        ':description' => $description,
        ':status'      => $status,
        ':priority'    => $priority,
        ':id'          => $ticket_id,
        ':user_id'     => $_SESSION['user_id'],
    ]);
```

Replace with:

```php
if (empty($errors)) {
    if (is_admin()) {
        $stmt = $pdo->prepare(
            'UPDATE tickets SET title = :title, description = :description,
             status = :status, priority = :priority
             WHERE id = :id'
        );
        $stmt->execute([
            ':title'       => $title,
            ':description' => $description,
            ':status'      => $status,
            ':priority'    => $priority,
            ':id'          => $ticket_id,
        ]);
    } else {
        $stmt = $pdo->prepare(
            'UPDATE tickets SET title = :title, description = :description,
             status = :status, priority = :priority
             WHERE id = :id AND user_id = :user_id'
        );
        $stmt->execute([
            ':title'       => $title,
            ':description' => $description,
            ':status'      => $status,
            ':priority'    => $priority,
            ':id'          => $ticket_id,
            ':user_id'     => $_SESSION['user_id'],
        ]);
    }
```

- [ ] **Step 1: Apply Change 1 (fetch)**

Edit `tickets/edit.php` lines 17–18 as shown above.

- [ ] **Step 2: Apply Change 2 (UPDATE)**

Edit `tickets/edit.php` lines 99–111 as shown above.

- [ ] **Step 3: Verify**

```bash
grep -n "is_admin" /Users/youssef/Projects/Ticketsystem/tickets/edit.php
```

Expected: two occurrences — one in the fetch block, one in the UPDATE block.

- [ ] **Step 4: Commit**

```bash
git add tickets/edit.php
git commit -m "feat: allow admin to edit any ticket"
```

---

## Task 6: Dashboard — admin sidebar link + action buttons for all tickets

**Files:**
- Modify: `dashboard/user.php`

**Change 1 — sidebar admin link (after the existing change-password link, around line 393):**

Current sidebar Account section:

```php
    <div class="sidebar-section">Account</div>

    <a class="sidebar-link" href="/auth/change-password.php">
      <span class="sidebar-icon"><svg ...lock svg...</svg></span>
      Change password
    </a>
```

Add the admin link immediately after the change-password `</a>`:

```php
    <?php if (is_admin()): ?>
    <a class="sidebar-link" href="/admin/index.php">
      <span class="sidebar-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg></span>
      Admin panel
    </a>
    <?php endif; ?>
```

**Change 2 — action buttons visible for admins (around line 542):**

Current:

```php
          <div class="ticket-actions">
            <?php if ($is_owner): ?>
              <a href="/tickets/edit.php?id=<?php echo (int)$ticket['id']; ?>" class="btn btn-outline btn-sm">Edit</a>
              <form method="POST" action="/tickets/delete.php" style="display:inline" onsubmit="return confirm('Delete this ticket?')">
                <input type="hidden" name="id" value="<?php echo (int)$ticket['id']; ?>">
                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
              </form>
            <?php endif; ?>
          </div>
```

Replace with:

```php
          <div class="ticket-actions">
            <?php if ($is_owner || is_admin()): ?>
              <a href="/tickets/edit.php?id=<?php echo (int)$ticket['id']; ?>" class="btn btn-outline btn-sm">Edit</a>
              <form method="POST" action="/tickets/delete.php" style="display:inline" onsubmit="return confirm('Delete this ticket?')">
                <input type="hidden" name="id" value="<?php echo (int)$ticket['id']; ?>">
                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
              </form>
            <?php endif; ?>
          </div>
```

- [ ] **Step 1: Apply Change 1 (sidebar admin link)**

Find the change-password `</a>` closing tag in `dashboard/user.php` and insert the admin link block after it.

- [ ] **Step 2: Apply Change 2 (action buttons)**

Find `<?php if ($is_owner): ?>` in the ticket-actions div and change it to `<?php if ($is_owner || is_admin()): ?>`.

- [ ] **Step 3: Verify**

```bash
grep -n "is_admin" /Users/youssef/Projects/Ticketsystem/dashboard/user.php
```

Expected: two occurrences — one in the sidebar, one in the ticket-actions block.

- [ ] **Step 4: Commit**

```bash
git add dashboard/user.php
git commit -m "feat: show admin link in sidebar and actions on all tickets for admins"
```

---

## Task 7: Create `admin/index.php`

**Files:**
- Create: `admin/index.php`

- [ ] **Step 1: Create the admin directory**

```bash
mkdir -p /Users/youssef/Projects/Ticketsystem/admin
```

- [ ] **Step 2: Create `admin/index.php` with this exact content**

```php
<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config.php';

require_admin();

$allowed_statuses   = ['open', 'in-progress', 'closed'];
$allowed_priorities = ['low', 'medium', 'high'];

/* ── Handle POST actions (PRG pattern) ── */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action    = $_POST['action'] ?? '';
    $ticket_id = $_POST['id']     ?? '';

    if (!ctype_digit((string)$ticket_id)) {
        header('Location: /admin/index.php');
        exit();
    }

    if ($action === 'update_status') {
        $status = $_POST['status'] ?? '';
        if (in_array($status, $allowed_statuses, true)) {
            $stmt = $pdo->prepare('UPDATE tickets SET status = :status WHERE id = :id');
            $stmt->execute([':status' => $status, ':id' => $ticket_id]);
            $_SESSION['flash_success'] = 'Status updated.';
        }
    } elseif ($action === 'update_priority') {
        $priority = $_POST['priority'] ?? '';
        if (in_array($priority, $allowed_priorities, true)) {
            $stmt = $pdo->prepare('UPDATE tickets SET priority = :priority WHERE id = :id');
            $stmt->execute([':priority' => $priority, ':id' => $ticket_id]);
            $_SESSION['flash_success'] = 'Priority updated.';
        }
    } elseif ($action === 'delete') {
        $stmt = $pdo->prepare('DELETE FROM tickets WHERE id = :id');
        $stmt->execute([':id' => $ticket_id]);
        if ($stmt->rowCount() > 0) {
            $_SESSION['flash_success'] = 'Ticket deleted.';
        }
    }

    header('Location: /admin/index.php');
    exit();
}

/* ── Fetch all tickets ── */
$stmt = $pdo->query(
    'SELECT t.id, t.title, t.status, t.priority, t.created_at, u.username AS author
     FROM tickets t
     JOIN users u ON t.user_id = u.id
     ORDER BY t.created_at DESC'
);
$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);
$total   = count($tickets);

$flash = $_SESSION['flash_success'] ?? null;
unset($_SESSION['flash_success']);

function admin_ticket_id(int $id): string {
    return 'TH-' . str_pad($id, 3, '0', STR_PAD_LEFT);
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Panel &mdash; TicketHub</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: #FAFAF7; --surface: #FFFFFF; --surface-2: #F4F4F0;
      --border: #E7E5DF; --border-strong: #D8D5CC;
      --text: #1A1A1A; --text-muted: #6B6B6B; --text-subtle: #9A9A95;
      --brand: #4F46E5; --brand-soft: #EEF2FF;
      --danger: #DC2626; --danger-soft: #FEE2E2;
      --font-sans: 'Inter', ui-sans-serif, system-ui, sans-serif;
      --font-display: 'Instrument Serif', ui-serif, Georgia, serif;
      --font-mono: 'JetBrains Mono', ui-monospace, monospace;
      --r: 10px; --r-lg: 14px;
      --sh: 0 4px 12px -4px rgba(15,15,15,0.08), 0 1px 2px rgba(15,15,15,0.04);
    }
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: var(--font-sans); background: var(--bg); color: var(--text);
      -webkit-font-smoothing: antialiased; font-size: 14px;
    }
    a { color: inherit; text-decoration: none; }
    button { font: inherit; cursor: pointer; border: none; background: none; color: inherit; }

    /* Top bar */
    .topbar {
      background: var(--surface); border-bottom: 1px solid var(--border);
      padding: 0 32px; height: 60px;
      display: flex; align-items: center; justify-content: space-between;
      position: sticky; top: 0; z-index: 10;
    }
    .topbar-left { display: flex; align-items: center; gap: 16px; }
    .back-link {
      display: flex; align-items: center; gap: 6px;
      font-size: 13px; color: var(--text-muted);
      padding: 6px 10px; border-radius: 8px;
      transition: background 120ms ease;
    }
    .back-link:hover { background: var(--surface-2); color: var(--text); }
    .topbar-divider { width: 1px; height: 20px; background: var(--border); }
    .topbar-title { font-size: 15px; font-weight: 600; letter-spacing: -0.01em; }
    .topbar-badge {
      font-size: 12px; font-family: var(--font-mono);
      background: var(--brand-soft); color: var(--brand);
      padding: 2px 8px; border-radius: 999px; font-weight: 500;
    }
    .topbar-role {
      font-size: 12px; background: var(--surface-2); border: 1px solid var(--border);
      padding: 4px 10px; border-radius: 999px; color: var(--text-muted);
    }

    /* Page */
    .page { max-width: 1200px; margin: 0 auto; padding: 32px; }

    /* Card */
    .card {
      background: var(--surface); border: 1px solid var(--border);
      border-radius: var(--r-lg); overflow: hidden; box-shadow: var(--sh);
    }
    .card-head {
      padding: 20px 24px; border-bottom: 1px solid var(--border);
      display: flex; align-items: center; justify-content: space-between;
    }
    .card-title { font-size: 15px; font-weight: 600; }
    .card-sub { font-size: 13px; color: var(--text-muted); margin-top: 2px; }

    /* Table */
    .ticket-table { width: 100%; border-collapse: collapse; }
    .ticket-table th {
      padding: 10px 16px; text-align: left;
      font-size: 11px; font-weight: 600; letter-spacing: 0.06em; text-transform: uppercase;
      color: var(--text-subtle); background: var(--surface-2);
      border-bottom: 1px solid var(--border);
    }
    .ticket-table td {
      padding: 12px 16px; border-bottom: 1px solid var(--border);
      vertical-align: middle;
    }
    .ticket-table tr:last-child td { border-bottom: none; }
    .ticket-table tr:hover td { background: var(--surface-2); }
    .col-id { width: 80px; }
    .tid { font-family: var(--font-mono); font-size: 12px; color: var(--text-muted); }
    .col-title { font-weight: 500; }
    .col-author { font-size: 13px; color: var(--text-muted); }
    .col-select { width: 150px; }
    .col-actions { width: 90px; text-align: right; }

    /* Inline select */
    .inline-form { display: inline; }
    .select-field {
      appearance: none; -webkit-appearance: none;
      width: 100%; padding: 6px 28px 6px 10px; border-radius: 8px;
      border: 1px solid var(--border); background: var(--surface);
      font: inherit; font-size: 13px; color: var(--text); cursor: pointer;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%236B6B6B' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E");
      background-repeat: no-repeat; background-position: right 8px center;
      transition: border-color 120ms ease;
    }
    .select-field:hover { border-color: var(--border-strong); }
    .select-field:focus { outline: none; border-color: var(--brand); box-shadow: 0 0 0 3px var(--brand-soft); }

    /* Delete button */
    .btn-delete {
      display: inline-flex; align-items: center; justify-content: center;
      height: 32px; padding: 0 12px; border-radius: 8px;
      font-size: 13px; font-weight: 500;
      background: var(--danger-soft); color: var(--danger);
      border: 1px solid #FECACA; transition: background 120ms ease;
    }
    .btn-delete:hover { background: #FECACA; }

    /* Empty state */
    .empty-state { padding: 64px 24px; text-align: center; color: var(--text-muted); }
    .empty-title { font-size: 16px; font-weight: 600; color: var(--text); margin-bottom: 6px; }

    /* Toast */
    .toast {
      position: fixed; bottom: 24px; right: 24px;
      background: var(--text); color: #fff;
      padding: 12px 18px; border-radius: var(--r);
      font-size: 14px; font-weight: 500;
      box-shadow: var(--sh); z-index: 100;
      display: flex; align-items: center; gap: 8px;
    }
  </style>
</head>
<body>

<!-- Top bar -->
<div class="topbar">
  <div class="topbar-left">
    <a href="/dashboard/user.php" class="back-link">
      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
      Dashboard
    </a>
    <div class="topbar-divider"></div>
    <div class="topbar-title">Admin Panel</div>
    <span class="topbar-badge"><?php echo $total; ?> tickets</span>
  </div>
  <div class="topbar-role">
    <?php echo htmlspecialchars($_SESSION['username']); ?> &mdash; admin
  </div>
</div>

<!-- Page body -->
<div class="page">
  <div class="card">
    <div class="card-head">
      <div>
        <div class="card-title">All tickets</div>
        <div class="card-sub">Change status or priority inline. Deletions are permanent.</div>
      </div>
    </div>

    <?php if (empty($tickets)): ?>
      <div class="empty-state">
        <div class="empty-title">No tickets yet</div>
        <p>Users haven&rsquo;t submitted any tickets.</p>
      </div>
    <?php else: ?>
      <table class="ticket-table">
        <thead>
          <tr>
            <th class="col-id">ID</th>
            <th>Title</th>
            <th>Author</th>
            <th class="col-select">Status</th>
            <th class="col-select">Priority</th>
            <th class="col-actions">Delete</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($tickets as $ticket):
            $tid = admin_ticket_id((int)$ticket['id']);
        ?>
          <tr>
            <td class="col-id"><span class="tid"><?php echo htmlspecialchars($tid); ?></span></td>
            <td class="col-title"><?php echo htmlspecialchars($ticket['title']); ?></td>
            <td class="col-author"><?php echo htmlspecialchars($ticket['author']); ?></td>

            <!-- Status inline form -->
            <td class="col-select">
              <form method="POST" class="inline-form">
                <input type="hidden" name="action" value="update_status">
                <input type="hidden" name="id" value="<?php echo (int)$ticket['id']; ?>">
                <select name="status" class="select-field" onchange="this.form.submit()">
                  <option value="open"        <?php echo $ticket['status'] === 'open'        ? 'selected' : ''; ?>>Open</option>
                  <option value="in-progress" <?php echo $ticket['status'] === 'in-progress' ? 'selected' : ''; ?>>In progress</option>
                  <option value="closed"      <?php echo $ticket['status'] === 'closed'      ? 'selected' : ''; ?>>Closed</option>
                </select>
              </form>
            </td>

            <!-- Priority inline form -->
            <td class="col-select">
              <form method="POST" class="inline-form">
                <input type="hidden" name="action" value="update_priority">
                <input type="hidden" name="id" value="<?php echo (int)$ticket['id']; ?>">
                <select name="priority" class="select-field" onchange="this.form.submit()">
                  <option value="low"    <?php echo $ticket['priority'] === 'low'    ? 'selected' : ''; ?>>Low</option>
                  <option value="medium" <?php echo $ticket['priority'] === 'medium' ? 'selected' : ''; ?>>Medium</option>
                  <option value="high"   <?php echo $ticket['priority'] === 'high'   ? 'selected' : ''; ?>>High</option>
                </select>
              </form>
            </td>

            <!-- Delete form -->
            <td class="col-actions">
              <form method="POST" class="inline-form" onsubmit="return confirm('Delete <?php echo htmlspecialchars($tid, ENT_QUOTES); ?>? This cannot be undone.')">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?php echo (int)$ticket['id']; ?>">
                <button type="submit" class="btn-delete">Delete</button>
              </form>
            </td>

          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>

<?php if ($flash): ?>
<div class="toast" id="flash-toast">
  &#10003; <?php echo htmlspecialchars($flash); ?>
</div>
<script>
  setTimeout(function() {
    var t = document.getElementById('flash-toast');
    if (t) { t.style.opacity = '0'; t.style.transition = 'opacity 400ms'; setTimeout(function(){ t.remove(); }, 400); }
  }, 3000);
</script>
<?php endif; ?>

</body>
</html>
```

- [ ] **Step 3: Verify the file exists**

```bash
ls -la /Users/youssef/Projects/Ticketsystem/admin/index.php
```

Expected: file exists with non-zero size.

- [ ] **Step 4: Test manually**

1. Log in as your admin user
2. Visit `http://localhost/admin/index.php` — should see the admin panel with all tickets
3. Try changing a status dropdown — should auto-submit and show a toast
4. Try changing a priority dropdown — same
5. Try the Delete button on a test ticket — confirm dialog, then deletes
6. Log out, log in as a regular user, visit `http://localhost/admin/index.php` — should redirect to dashboard

- [ ] **Step 5: Commit**

```bash
git add admin/index.php
git commit -m "feat: add admin panel with inline ticket management"
```

---

## Final verification

- [ ] Log in as admin → dashboard sidebar shows "Admin panel" link
- [ ] Admin sees Edit/Delete on every ticket row in the dashboard (not just their own)
- [ ] Admin can edit any ticket via `/tickets/edit.php?id=X`
- [ ] Admin can delete any ticket from the dashboard
- [ ] Regular user visits `/admin/index.php` → redirected to dashboard silently
- [ ] Regular user still cannot edit/delete tickets they don't own
