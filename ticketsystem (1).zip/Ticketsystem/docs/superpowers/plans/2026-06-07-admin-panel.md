# Admin Panel Redesign Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the inline styles and old light-theme HTML in `admin/index.php` with the new dark design system — same sidebar+main shell as the other app pages.

**Architecture:** Single file change: `admin/index.php`. PHP lines 1–61 are kept exactly as-is (POST handling, ticket fetch, flash read, `admin_ticket_id()` helper). The closing `?>` on line 62 and everything after it is replaced with the new dark HTML. No new CSS files — `public/css/app.css` + `public/css/dashboard.css` cover all layout and component needs.

**Tech Stack:** PHP 8, `public/css/app.css` (design tokens + base components), `public/css/dashboard.css` (sidebar+main layout — already exists), `public/js/canvas.js` (dot-matrix animation engine — already exists).

---

## File Map

| File | Action | PHP lines to keep |
|------|--------|-------------------|
| `admin/index.php` | **Modify** | Lines 1–61 unchanged |

---

## Task 1: Redesign `admin/index.php`

**Files:**
- Modify: `admin/index.php` (keep PHP lines 1–61, replace line 62 to end of file)

**Context:** PHP lines 1–61 contain: `require_once` calls, `require_admin()`, `$allowed_statuses`/`$allowed_priorities` arrays, POST action handler (update_status, update_priority, delete — all PRG), full ticket SELECT with JOIN, flash session read, and the `admin_ticket_id()` helper. Do not touch a single character of lines 1–61.

Line 62 of the original file is `?>` (the PHP closing tag). Replace line 62 and everything after it with the new HTML block.

The admin page does not have `$username` or `$display_name` — use a one-liner right after `?>` to extract the session username for the sidebar. `$__dn` is always `'Admin'` since `require_admin()` guarantees access.

- [ ] **Step 1: Verify PHP block ends at line 61**

Read `admin/index.php` lines 59–64. Confirm line 61 is the closing `}` of `admin_ticket_id()` and line 62 is `?>`.

```bash
# Expected output of lines 59-64:
# 59:     return 'TH-' . str_pad($id, 3, '0', STR_PAD_LEFT);
# 60: }
# 61: (blank line or closing brace — adjust if needed)
# 62: ?>
```

If line numbers differ, adjust the replacement boundaries accordingly.

- [ ] **Step 2: Replace line 62 to end of file**

Keep lines 1–61 exactly. Replace line 62 (`?>`) and everything after with:

```php
?>
<?php $__u = $_SESSION['username'] ?? ''; ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin panel — TicketSystem</title>
  <link rel="stylesheet" href="/public/css/app.css">
  <link rel="stylesheet" href="/public/css/dashboard.css">
</head>
<body>

<div class="dash">

  <!-- ═══ Sidebar ═══ -->
  <aside class="sidebar">
    <div class="sidebar-logo">
      <span class="sidebar-logo-mark">TS</span>
      TicketSystem
    </div>

    <div class="sidebar-section">Workspace</div>

    <a href="/dashboard/user.php" class="sidebar-link">
      <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/></svg>
      Tickets
    </a>

    <div class="sidebar-section">Account</div>

    <a href="/auth/change-password.php" class="sidebar-link">
      <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
      Change password
    </a>

    <div class="sidebar-section">Admin</div>

    <a href="/admin/index.php" class="sidebar-link active">
      <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
      Admin panel
    </a>

    <div class="sidebar-bottom">
      <a href="/auth/logout.php" class="sidebar-user">
        <div class="avatar"><?php echo htmlspecialchars(strtoupper(substr($__u, 0, 2))); ?></div>
        <div>
          <div class="sidebar-user-name">Admin</div>
          <div class="sidebar-user-role">Sign out &rarr;</div>
        </div>
      </a>
    </div>
  </aside>

  <!-- ═══ Main ═══ -->
  <main class="main">

    <div class="main-head">
      <div>
        <h1 class="page-title">Admin panel.</h1>
        <p class="page-sub"><?php echo $total; ?> tickets total.</p>
      </div>
    </div>

    <?php if (empty($tickets)): ?>
    <div class="empty-state">No tickets yet.</div>

    <?php else: ?>
    <table class="tickets-table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Title</th>
          <th>Author</th>
          <th>Status</th>
          <th>Priority</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($tickets as $ticket):
        $tid = admin_ticket_id((int)$ticket['id']);
      ?>
        <tr class="ticket-row">
          <td class="ticket-id"><?php echo htmlspecialchars($tid); ?></td>
          <td class="ticket-title"><?php echo htmlspecialchars($ticket['title']); ?></td>
          <td><?php echo htmlspecialchars($ticket['author']); ?></td>

          <td>
            <form method="POST">
              <input type="hidden" name="action" value="update_status">
              <input type="hidden" name="id" value="<?php echo (int)$ticket['id']; ?>">
              <select name="status" class="input" style="max-width:140px" onchange="this.form.submit()">
                <option value="open"        <?php if ($ticket['status'] === 'open')        echo 'selected'; ?>>Open</option>
                <option value="in-progress" <?php if ($ticket['status'] === 'in-progress') echo 'selected'; ?>>In Progress</option>
                <option value="closed"      <?php if ($ticket['status'] === 'closed')      echo 'selected'; ?>>Closed</option>
              </select>
            </form>
          </td>

          <td>
            <form method="POST">
              <input type="hidden" name="action" value="update_priority">
              <input type="hidden" name="id" value="<?php echo (int)$ticket['id']; ?>">
              <select name="priority" class="input" style="max-width:130px" onchange="this.form.submit()">
                <option value="low"    <?php if ($ticket['priority'] === 'low')    echo 'selected'; ?>>Low</option>
                <option value="medium" <?php if ($ticket['priority'] === 'medium') echo 'selected'; ?>>Medium</option>
                <option value="high"   <?php if ($ticket['priority'] === 'high')   echo 'selected'; ?>>High</option>
              </select>
            </form>
          </td>

          <td>
            <form method="POST"
              onsubmit="return confirm('Delete <?php echo htmlspecialchars($tid, ENT_QUOTES); ?>? This cannot be undone.')">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?php echo (int)$ticket['id']; ?>">
              <button type="submit" class="btn btn-sm btn-danger">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>

  </main>
</div>

<?php if ($flash): ?>
<div class="toast toast-success" id="flash-toast">
  <?php echo htmlspecialchars($flash); ?>
</div>
<script>
  setTimeout(function () {
    var t = document.getElementById('flash-toast');
    if (t) { t.style.opacity = '0'; t.style.transition = 'opacity 400ms'; setTimeout(function () { t.remove(); }, 400); }
  }, 3000);
</script>
<?php endif; ?>

<script src="/public/js/canvas.js"></script>
</body>
</html>
```

- [ ] **Step 3: Verify PHP logic is intact**

Read `admin/index.php` lines 1–61. Confirm all of the following are present and untouched:
- `require_once __DIR__ . '/../includes/session.php'`
- `require_once __DIR__ . '/../config.php'`
- `require_admin()`
- `$allowed_statuses` and `$allowed_priorities` arrays
- POST handler with `update_status`, `update_priority`, `delete` branches
- PDO SELECT query with JOIN on users
- `$flash = $_SESSION['flash_success'] ?? null` + `unset`
- `admin_ticket_id()` function

- [ ] **Step 4: Commit**

```bash
git add admin/index.php
git commit -m "style: redesign admin/index.php with dark design system"
```
