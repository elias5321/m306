# Landing Page & Login Redesign — Zendesk-Inspired Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fully redesign `index.php` and the three auth pages to Zendesk.de's professional standard — wide alternating sections, HTML/CSS UI mockup illustrations, randomuser.me portrait photos for testimonials, and an indigo brand panel on all auth pages.

**Architecture:** Pure HTML/CSS/JS, no frameworks. All illustrations are HTML/CSS elements (no image files needed). Auth pages keep existing PHP logic intact; only the left panel HTML and CSS change. `landing.css` is a complete rewrite. `auth.css` keeps all form styles and adds brand panel styles on top.

**Tech Stack:** PHP 8, vanilla CSS custom properties (`app.css` tokens), vanilla JS, randomuser.me portrait CDN

---

## File Map

| File | Action | What changes |
|---|---|---|
| `public/css/landing.css` | Full rewrite | New layout, navbar, hero, features, testimonials, steps, FAQ, CTA, footer |
| `index.php` | Full rewrite | New HTML structure with all sections and inline UI mockups |
| `public/js/landing.js` | Update | Navbar scroll border, hamburger toggle, remove tilt/deck code |
| `public/css/auth.css` | Update | Brand panel styles, indigo aside background |
| `auth/login.php` | Update | Replace left panel HTML |
| `auth/register.php` | Update | Replace left panel HTML |
| `auth/change-password.php` | Update | Replace left panel HTML |

---

### Task 1: Rewrite `public/css/landing.css`

**Files:**
- Modify: `public/css/landing.css` (full replacement)

- [ ] **Step 1: Replace the entire file with the new CSS**

Write this exact content to `public/css/landing.css`:

```css
/* ═══════════════════════════════════════════════
   Ticketsystem — Landing Page
   Zendesk-inspired, dual theme (tokens from app.css)
   ═══════════════════════════════════════════════ */

/* ── Scroll-reveal ── */
[data-reveal] {
  opacity: 0;
  transform: translateY(24px);
  transition: opacity 0.6s ease, transform 0.6s ease;
}
[data-reveal][data-delay="1"] { transition-delay: 0.1s; }
[data-reveal][data-delay="2"] { transition-delay: 0.2s; }
[data-reveal][data-delay="3"] { transition-delay: 0.3s; }
[data-reveal].revealed        { opacity: 1; transform: none; }

/* ── Shared section helpers ── */
.lp-inner {
  max-width: 1200px;
  margin: 0 auto;
}
.lp-label {
  font-size: 13px;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--brand);
  margin-bottom: 12px;
}
.lp-h2 {
  font-size: 44px;
  font-weight: 800;
  letter-spacing: -0.03em;
  line-height: 1.1;
  color: var(--text);
  margin-bottom: 20px;
}
.lp-body {
  font-size: 18px;
  line-height: 1.7;
  color: var(--text-muted);
  max-width: 520px;
  margin-bottom: 28px;
}
.lp-link {
  font-size: 15px;
  font-weight: 600;
  color: var(--brand);
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.lp-link:hover { text-decoration: underline; }

/* ── Navbar ── */
.nav {
  position: fixed;
  top: 0; left: 0; right: 0;
  z-index: 100;
  padding: 0 24px;
  background: rgba(244, 245, 247, 0.9);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  border-bottom: 1px solid transparent;
  transition: border-color 200ms ease, background 200ms ease;
}
[data-theme="dark"] .nav {
  background: rgba(15, 15, 19, 0.9);
}
.nav.scrolled { border-bottom-color: var(--border); }
.nav-inner {
  max-width: 1200px;
  margin: 0 auto;
  height: 72px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.nav-logo {
  display: flex;
  align-items: center;
  gap: 10px;
  font-weight: 700;
  font-size: 15px;
  letter-spacing: -0.02em;
  color: var(--text);
  text-decoration: none;
}
.nav-logo-mark {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background: var(--brand-soft);
  border: 1px solid rgba(79, 70, 229, 0.25);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--brand);
  flex-shrink: 0;
}
.nav-links {
  display: flex;
  gap: 32px;
  list-style: none;
  margin: 0; padding: 0;
}
.nav-links a {
  font-size: 14px;
  font-weight: 500;
  color: var(--text-muted);
  text-decoration: none;
  transition: color 150ms ease;
}
.nav-links a:hover { color: var(--text); }
.nav-actions {
  display: flex;
  align-items: center;
  gap: 12px;
}
.nav-sign-in {
  font-size: 14px;
  font-weight: 500;
  color: var(--text-muted);
  text-decoration: none;
  transition: color 150ms ease;
}
.nav-sign-in:hover { color: var(--text); }
.nav-hamburger {
  display: none;
  flex-direction: column;
  gap: 5px;
  cursor: pointer;
  background: none;
  border: none;
  padding: 4px;
}
.nav-hamburger span {
  display: block;
  width: 22px;
  height: 2px;
  background: var(--text);
  border-radius: 2px;
  transition: transform 200ms ease, opacity 200ms ease;
}
.nav-mobile {
  display: none;
  position: fixed;
  top: 72px; left: 0; right: 0;
  background: var(--bg);
  border-bottom: 1px solid var(--border);
  padding: 16px 24px;
  z-index: 99;
  flex-direction: column;
  gap: 4px;
}
.nav-mobile.open { display: flex; }
.nav-mobile a {
  font-size: 15px;
  font-weight: 500;
  color: var(--text);
  text-decoration: none;
  padding: 10px 0;
  border-bottom: 1px solid var(--border);
}
.nav-mobile a:last-child { border-bottom: none; }

/* ── Hero ── */
.lp-hero {
  padding: 120px 24px 80px;
  display: flex;
  align-items: center;
}
.lp-hero-inner {
  max-width: 1200px;
  margin: 0 auto;
  width: 100%;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 64px;
  align-items: center;
}
.hero-badge {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  font-weight: 600;
  color: var(--brand);
  background: var(--brand-soft);
  border: 1px solid rgba(79, 70, 229, 0.25);
  padding: 5px 14px;
  border-radius: 100px;
  margin-bottom: 24px;
}
.hero-h1 {
  font-size: 56px;
  font-weight: 800;
  letter-spacing: -0.03em;
  line-height: 1.05;
  color: var(--text);
  margin-bottom: 20px;
}
.hero-sub {
  font-size: 20px;
  line-height: 1.65;
  color: var(--text-muted);
  max-width: 460px;
  margin-bottom: 36px;
}
.hero-actions {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
  margin-bottom: 28px;
}
.hero-micro {
  font-size: 13px;
  color: var(--text-subtle);
  display: flex;
  gap: 0;
}
.hero-micro span { margin-right: 0; }
.hero-micro span + span::before {
  content: ' · ';
  margin: 0 6px;
}

/* ── Browser-frame mockup ── */
.browser-frame {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 24px 80px rgba(0, 0, 0, 0.12);
  position: relative;
}
[data-theme="dark"] .browser-frame {
  box-shadow: 0 24px 80px rgba(0, 0, 0, 0.5);
}
.browser-bar {
  background: var(--surface-2);
  border-bottom: 1px solid var(--border);
  padding: 10px 14px;
  display: flex;
  align-items: center;
  gap: 6px;
}
.browser-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  flex-shrink: 0;
}
.browser-url {
  flex: 1;
  margin-left: 8px;
  background: var(--bg);
  border: 1px solid var(--border);
  border-radius: 5px;
  padding: 3px 10px;
  font-size: 11px;
  color: var(--text-subtle);
  font-family: var(--font-mono);
}
.browser-content { padding: 12px; }
.mock-table-head {
  display: grid;
  grid-template-columns: 68px 1fr 110px 88px;
  padding: 6px 10px;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--text-subtle);
  border-bottom: 1px solid var(--border);
  margin-bottom: 4px;
}
.mock-row {
  display: grid;
  grid-template-columns: 68px 1fr 110px 88px;
  align-items: center;
  padding: 9px 10px;
  border-radius: 7px;
  transition: background 150ms ease;
}
.mock-row:hover { background: var(--surface-2); }
.mock-id {
  font-family: var(--font-mono);
  font-size: 11px;
  font-weight: 600;
  color: var(--brand);
}
.mock-title {
  font-size: 13px;
  font-weight: 500;
  color: var(--text);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  padding-right: 8px;
}
.mock-pill {
  display: inline-flex;
  align-items: center;
  padding: 3px 9px;
  border-radius: 100px;
  font-size: 11px;
  font-weight: 600;
  width: fit-content;
}
.mock-pill.open     { background: var(--status-open-soft);     color: var(--status-open); }
.mock-pill.progress { background: var(--status-progress-soft); color: var(--status-progress); }
.mock-pill.closed   { background: var(--status-closed-soft);   color: var(--status-closed); }
.mock-pill.high     { background: var(--priority-high-soft);   color: var(--priority-high); }
.mock-pill.medium   { background: var(--priority-medium-soft); color: var(--priority-medium); }
.mock-pill.low      { background: var(--priority-low-soft);    color: var(--priority-low); }
.mock-float {
  position: absolute;
  bottom: 16px;
  right: 16px;
  background: var(--brand);
  color: white;
  border-radius: 10px;
  padding: 10px 16px;
  font-size: 13px;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 10px;
  box-shadow: 0 8px 24px rgba(79, 70, 229, 0.4);
}
.mock-float-up {
  font-size: 12px;
  opacity: 0.8;
}

/* ── Stats band ── */
.lp-stats-band {
  background: var(--brand);
  padding: 40px 24px;
}
.lp-stats-inner {
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 32px;
}
.lp-stat { text-align: center; color: white; }
.lp-stat-value {
  font-size: 26px;
  font-weight: 800;
  letter-spacing: -0.02em;
  margin-bottom: 4px;
}
.lp-stat-label {
  font-size: 14px;
  opacity: 0.75;
}

/* ── Feature sections ── */
.lp-feature {
  padding: 96px 24px;
}
.lp-feature--alt { background: var(--surface); }
.lp-feature-inner {
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 80px;
  align-items: center;
}
.lp-feature--flip .lp-feature-inner {
  direction: rtl;
}
.lp-feature--flip .lp-feature-inner > * {
  direction: ltr;
}

/* ── Ticket list illustration ── */
.feat-card {
  background: var(--bg);
  border: 1px solid var(--border);
  border-radius: 14px;
  overflow: hidden;
  box-shadow: var(--sh-lg);
}
.feat-card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 18px;
  border-bottom: 1px solid var(--border);
  font-size: 14px;
  font-weight: 600;
  color: var(--text);
}
.feat-badge {
  font-size: 12px;
  font-weight: 600;
  color: var(--brand);
  background: var(--brand-soft);
  padding: 3px 10px;
  border-radius: 100px;
}
.feat-ticket-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 11px 18px;
  border-bottom: 1px solid var(--border);
  transition: background 150ms ease;
}
.feat-ticket-row:last-child { border-bottom: none; }
.feat-ticket-row:hover { background: var(--surface); }
.feat-tick-accent {
  width: 3px;
  height: 30px;
  border-radius: 2px;
  flex-shrink: 0;
}
.feat-tick-info { flex: 1; min-width: 0; }
.feat-tick-id {
  display: block;
  font-family: var(--font-mono);
  font-size: 11px;
  color: var(--brand);
  font-weight: 600;
  margin-bottom: 2px;
}
.feat-tick-title {
  display: block;
  font-size: 13px;
  font-weight: 500;
  color: var(--text);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.feat-pill {
  font-size: 11px;
  font-weight: 600;
  padding: 3px 10px;
  border-radius: 100px;
  white-space: nowrap;
}
.feat-pill.open     { background: var(--status-open-soft);     color: var(--status-open); }
.feat-pill.progress { background: var(--status-progress-soft); color: var(--status-progress); }
.feat-pill.closed   { background: var(--status-closed-soft);   color: var(--status-closed); }
.feat-time {
  font-size: 12px;
  color: var(--text-subtle);
  white-space: nowrap;
}

/* ── Chat illustration ── */
.chat-window {
  background: var(--bg);
  border: 1px solid var(--border);
  border-radius: 14px;
  overflow: hidden;
  box-shadow: var(--sh-lg);
}
.chat-header {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 14px 18px;
  border-bottom: 1px solid var(--border);
  font-size: 14px;
  font-weight: 600;
  color: var(--text);
}
.chat-online-dot {
  width: 8px;
  height: 8px;
  background: #10B981;
  border-radius: 50%;
  flex-shrink: 0;
}
.chat-online-label {
  font-size: 12px;
  color: #10B981;
  font-weight: 500;
  margin-left: auto;
}
.chat-body {
  padding: 16px 18px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  min-height: 200px;
}
.chat-bubble {
  max-width: 88%;
  padding: 10px 14px;
  border-radius: 12px;
  font-size: 13px;
  line-height: 1.5;
}
.chat-bubble.user {
  background: var(--brand);
  color: white;
  align-self: flex-end;
  border-bottom-right-radius: 4px;
}
.chat-bubble.ai {
  background: var(--surface);
  color: var(--text);
  border: 1px solid var(--border);
  align-self: flex-start;
  border-bottom-left-radius: 4px;
}
.chat-input-bar {
  padding: 10px 14px;
  border-top: 1px solid var(--border);
  display: flex;
  align-items: center;
  gap: 8px;
}
.chat-input-bar-field {
  flex: 1;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 8px 12px;
  font-size: 13px;
  color: var(--text-subtle);
  font-family: var(--font-sans);
}

/* ── Kanban illustration ── */
.kanban-board {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
}
.kanban-col {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 10px;
  overflow: hidden;
}
.kanban-col-head {
  padding: 9px 12px;
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.06em;
}
.kanban-col-head.open     { background: var(--status-open-soft);     color: var(--status-open); }
.kanban-col-head.progress { background: var(--status-progress-soft); color: var(--status-progress); }
.kanban-col-head.closed   { background: var(--status-closed-soft);   color: var(--status-closed); }
.kanban-cards {
  padding: 8px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.kanban-card {
  background: var(--bg);
  border: 1px solid var(--border);
  border-radius: 7px;
  padding: 8px 10px;
  font-size: 12px;
  font-weight: 500;
  color: var(--text);
  line-height: 1.4;
}
.kanban-card-id {
  display: block;
  font-family: var(--font-mono);
  font-size: 10px;
  color: var(--brand);
  font-weight: 600;
  margin-bottom: 3px;
}
.kanban-card-check {
  color: #10B981;
  font-size: 11px;
  float: right;
}

/* ── Testimonials ── */
.lp-testimonials {
  padding: 96px 24px;
  background: var(--surface);
}
.lp-testimonials-head {
  max-width: 1200px;
  margin: 0 auto 56px;
  text-align: center;
}
.testimonials-grid {
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
}
.testimonial-card {
  background: var(--bg);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 28px;
  display: flex;
  flex-direction: column;
  gap: 20px;
  transition: box-shadow 200ms ease, transform 200ms ease;
}
.testimonial-card:hover {
  transform: translateY(-3px);
  box-shadow: var(--sh-lg);
}
.testimonial-quote {
  font-size: 15px;
  line-height: 1.7;
  color: var(--text-muted);
  font-style: italic;
  flex: 1;
}
.testimonial-author {
  display: flex;
  align-items: center;
  gap: 12px;
}
.testimonial-author img {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid var(--border);
}
.testimonial-name {
  font-size: 14px;
  font-weight: 600;
  color: var(--text);
}
.testimonial-role {
  font-size: 12px;
  color: var(--text-subtle);
  margin-top: 2px;
}

/* ── Steps ── */
.lp-steps {
  padding: 96px 24px;
}
.lp-steps-head {
  max-width: 1200px;
  margin: 0 auto 56px;
  text-align: center;
}
.steps-grid {
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 48px;
  position: relative;
}
.steps-grid::before {
  content: '';
  position: absolute;
  top: 27px;
  left: calc(16.67% + 20px);
  right: calc(16.67% + 20px);
  height: 1px;
  background: var(--border);
}
.step {
  display: flex;
  flex-direction: column;
  gap: 16px;
  position: relative;
  z-index: 1;
}
.step-num {
  width: 56px;
  height: 56px;
  border-radius: 50%;
  background: var(--brand);
  color: white;
  font-size: 20px;
  font-weight: 800;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  box-shadow: 0 8px 24px rgba(79, 70, 229, 0.35);
}
.step-title {
  font-size: 18px;
  font-weight: 700;
  color: var(--text);
  letter-spacing: -0.01em;
}
.step-body {
  font-size: 15px;
  line-height: 1.65;
  color: var(--text-muted);
}

/* ── FAQ ── */
.lp-faq {
  padding: 96px 24px;
  background: var(--surface);
}
.lp-faq-inner {
  max-width: 760px;
  margin: 48px auto 0;
}
.faq-section-head {
  max-width: 760px;
  margin: 0 auto;
  text-align: center;
}
.faq-item { border-bottom: 1px solid var(--border); }
.faq-q {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 0;
  background: none;
  border: none;
  cursor: pointer;
  font-size: 16px;
  font-weight: 600;
  color: var(--text);
  text-align: left;
  gap: 16px;
  font-family: var(--font-sans);
}
.faq-chevron {
  width: 20px;
  height: 20px;
  color: var(--text-subtle);
  flex-shrink: 0;
  transition: transform 250ms ease;
}
.faq-item.open .faq-chevron { transform: rotate(180deg); }
.faq-body {
  max-height: 0;
  overflow: hidden;
  transition: max-height 300ms ease;
}
.faq-body-inner {
  padding-bottom: 20px;
  font-size: 15px;
  line-height: 1.7;
  color: var(--text-muted);
}

/* ── CTA band ── */
.lp-cta-band {
  background: var(--brand);
  padding: 96px 24px;
  text-align: center;
}
.lp-cta-band h2 {
  font-size: 44px;
  font-weight: 800;
  letter-spacing: -0.03em;
  color: white;
  margin-bottom: 16px;
}
.lp-cta-band p {
  font-size: 18px;
  color: rgba(255, 255, 255, 0.75);
  margin-bottom: 36px;
}
.cta-actions {
  display: flex;
  gap: 12px;
  justify-content: center;
  flex-wrap: wrap;
}
.btn-white {
  background: white;
  color: var(--brand);
  font-size: 15px;
  font-weight: 600;
  padding: 12px 28px;
  border-radius: var(--r);
  border: none;
  cursor: pointer;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  transition: opacity 150ms ease, transform 150ms ease;
  font-family: var(--font-sans);
}
.btn-white:hover { opacity: 0.92; transform: translateY(-1px); }
.btn-ghost-white {
  background: transparent;
  color: white;
  font-size: 15px;
  font-weight: 600;
  padding: 12px 28px;
  border-radius: var(--r);
  border: 1.5px solid rgba(255, 255, 255, 0.4);
  cursor: pointer;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  transition: border-color 150ms ease, background 150ms ease;
  font-family: var(--font-sans);
}
.btn-ghost-white:hover { border-color: white; background: rgba(255, 255, 255, 0.08); }

/* ── Footer ── */
.lp-footer {
  border-top: 1px solid var(--border);
  padding: 56px 24px;
}
.lp-footer-inner {
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: 2fr 1fr 1fr;
  gap: 48px;
}
.footer-brand { display: flex; flex-direction: column; gap: 12px; }
.footer-tagline {
  font-size: 14px;
  color: var(--text-muted);
  line-height: 1.6;
  max-width: 280px;
}
.footer-copy {
  font-size: 12px;
  color: var(--text-subtle);
  margin-top: 8px;
}
.footer-col h4 {
  font-size: 12px;
  font-weight: 700;
  color: var(--text);
  letter-spacing: 0.06em;
  text-transform: uppercase;
  margin-bottom: 16px;
}
.footer-col ul {
  list-style: none;
  margin: 0; padding: 0;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.footer-col ul a {
  font-size: 14px;
  color: var(--text-muted);
  text-decoration: none;
  transition: color 150ms ease;
}
.footer-col ul a:hover { color: var(--text); }

/* ── Responsive ── */
@media (max-width: 1024px) {
  .lp-hero-inner    { grid-template-columns: 1fr; gap: 48px; }
  .lp-feature-inner { grid-template-columns: 1fr; gap: 40px; }
  .lp-feature--flip .lp-feature-inner { direction: ltr; }
  .testimonials-grid { grid-template-columns: 1fr 1fr; }
  .lp-footer-inner { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 768px) {
  .nav-links, .nav-sign-in { display: none; }
  .nav-hamburger { display: flex; }
  .lp-hero { padding: 120px 24px 64px; }
  .hero-h1 { font-size: 40px; }
  .lp-h2 { font-size: 32px; }
  .lp-feature, .lp-testimonials, .lp-steps, .lp-faq, .lp-cta-band { padding: 64px 24px; }
  .lp-stats-inner { grid-template-columns: 1fr; gap: 24px; }
  .steps-grid { grid-template-columns: 1fr; gap: 32px; }
  .steps-grid::before { display: none; }
  .testimonials-grid { grid-template-columns: 1fr; }
  .lp-footer-inner { grid-template-columns: 1fr; gap: 32px; }
  .kanban-board { grid-template-columns: 1fr; }
  .mock-table-head, .mock-row { grid-template-columns: 60px 1fr 100px; }
  .mock-table-head span:last-child, .mock-row .mock-pill:last-child { display: none; }
}
@media (max-width: 480px) {
  .hero-h1 { font-size: 34px; }
  .lp-cta-band h2 { font-size: 32px; }
  .hero-actions { flex-direction: column; }
  .hero-actions a { width: 100%; justify-content: center; text-align: center; }
}
```

- [ ] **Step 2: Commit**

```bash
git add public/css/landing.css
git commit -m "style: rewrite landing.css with Zendesk-inspired layout system"
```

---

### Task 2: Rewrite `index.php`

**Files:**
- Modify: `index.php` (full replacement)

- [ ] **Step 1: Replace entire file with new HTML**

Write this exact content to `index.php`:

```php
<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/config.php';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ticketsystem — Manage tickets. Stay organized.</title>
  <meta name="description" content="Open-source ticket management with a built-in AI assistant powered by Ollama.">
  <link rel="stylesheet" href="/public/css/app.css">
  <script src="/public/js/theme.js"></script>
  <link rel="stylesheet" href="/public/css/landing.css">
</head>
<body>

<!-- ═══ Navbar ═══ -->
<nav class="nav" id="lp-nav">
  <div class="nav-inner">
    <a href="/" class="nav-logo">
      <span class="nav-logo-mark">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="display:block"><path d="M3 4 L9 4 Q12 7 15 4 L21 4 Q23 4 23 6 L23 18 Q23 20 21 20 L15 20 Q12 17 9 20 L3 20 Q1 20 1 18 L1 6 Q1 4 3 4 Z"/><polyline points="8,13 11,16 16.5,9"/></svg>
      </span>
      Ticketsystem
    </a>
    <ul class="nav-links">
      <li><a href="#features">Features</a></li>
      <li><a href="#ai">AI Assistant</a></li>
      <li><a href="#faq">FAQ</a></li>
    </ul>
    <div class="nav-actions">
      <a href="/auth/login.php" class="nav-sign-in">Sign in</a>
      <a href="/auth/register.php" class="btn btn-primary">Get started</a>
      <button class="nav-hamburger" id="nav-hamburger" aria-label="Open menu" aria-expanded="false">
        <span></span><span></span><span></span>
      </button>
    </div>
  </div>
</nav>

<!-- Mobile menu -->
<div class="nav-mobile" id="nav-mobile" role="navigation" aria-label="Mobile menu">
  <a href="#features">Features</a>
  <a href="#ai">AI Assistant</a>
  <a href="#faq">FAQ</a>
  <a href="/auth/login.php">Sign in</a>
  <a href="/auth/register.php" class="btn btn-primary" style="margin-top:8px;text-align:center">Get started</a>
</div>

<!-- ═══ Hero ═══ -->
<section class="lp-hero">
  <div class="lp-hero-inner">

    <div class="lp-hero-text">
      <div class="hero-badge" data-reveal>
        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
        Now with AI assistance
      </div>
      <h1 class="hero-h1" data-reveal data-delay="1">
        Support tickets,<br>simplified.
      </h1>
      <p class="hero-sub" data-reveal data-delay="2">
        Manage, prioritize, and resolve every request faster &mdash; with a built-in AI assistant powered by Ollama.
      </p>
      <div class="hero-actions" data-reveal data-delay="3">
        <a href="/auth/register.php" class="btn btn-primary">Get started free</a>
        <a href="#how-it-works" class="btn btn-ghost">See how it works &rarr;</a>
      </div>
      <div class="hero-micro" data-reveal data-delay="3">
        <span>Open source</span>
        <span>Built with PHP &amp; MySQL</span>
        <span>AI-powered</span>
      </div>
    </div>

    <div class="lp-hero-visual" data-reveal data-delay="2">
      <div class="browser-frame">
        <div class="browser-bar">
          <span class="browser-dot" style="background:#FF5F57"></span>
          <span class="browser-dot" style="background:#FEBC2E"></span>
          <span class="browser-dot" style="background:#28C840"></span>
          <div class="browser-url">ticketsystem.local/dashboard</div>
        </div>
        <div class="browser-content">
          <div class="mock-table-head">
            <span>ID</span><span>Title</span><span>Status</span><span>Priority</span>
          </div>
          <div class="mock-row">
            <span class="mock-id">TH-001</span>
            <span class="mock-title">Login page broken</span>
            <span class="mock-pill open">Open</span>
            <span class="mock-pill high">High</span>
          </div>
          <div class="mock-row">
            <span class="mock-id">TH-002</span>
            <span class="mock-title">Email not sending</span>
            <span class="mock-pill progress">In Progress</span>
            <span class="mock-pill medium">Medium</span>
          </div>
          <div class="mock-row">
            <span class="mock-id">TH-003</span>
            <span class="mock-title">Export fails on CSV</span>
            <span class="mock-pill open">Open</span>
            <span class="mock-pill high">High</span>
          </div>
          <div class="mock-row">
            <span class="mock-id">TH-004</span>
            <span class="mock-title">Dark mode glitch</span>
            <span class="mock-pill closed">Closed</span>
            <span class="mock-pill low">Low</span>
          </div>
        </div>
        <div class="mock-float">
          <span>3 resolved today</span>
          <span class="mock-float-up">&#8593; 12%</span>
        </div>
      </div>
    </div>

  </div>
</section>

<!-- ═══ Stats Band ═══ -->
<div class="lp-stats-band">
  <div class="lp-stats-inner">
    <div class="lp-stat" data-reveal>
      <div class="lp-stat-value">Open source</div>
      <div class="lp-stat-label">Free to use forever</div>
    </div>
    <div class="lp-stat" data-reveal data-delay="1">
      <div class="lp-stat-value">AI-powered</div>
      <div class="lp-stat-label">Built-in Ollama assistant</div>
    </div>
    <div class="lp-stat" data-reveal data-delay="2">
      <div class="lp-stat-value">3 statuses</div>
      <div class="lp-stat-label">Open &middot; In Progress &middot; Closed</div>
    </div>
  </div>
</div>

<!-- ═══ Feature 1 — Track Tickets ═══ -->
<section id="features" class="lp-feature">
  <div class="lp-feature-inner">
    <div class="lp-feature-text" data-reveal>
      <p class="lp-label">Features</p>
      <h2 class="lp-h2">One place for<br>every request.</h2>
      <p class="lp-body">Every ticket is logged, timestamped, and organized. No more losing track of what&rsquo;s open, what&rsquo;s being handled, and what&rsquo;s done.</p>
      <a href="/auth/register.php" class="lp-link">Start tracking &rarr;</a>
    </div>
    <div class="lp-feature-visual" data-reveal data-delay="1">
      <div class="feat-card">
        <div class="feat-card-header">
          All Tickets <span class="feat-badge">12 open</span>
        </div>
        <div class="feat-ticket-row">
          <div class="feat-tick-accent" style="background:var(--status-open)"></div>
          <div class="feat-tick-info">
            <span class="feat-tick-id">TH-001</span>
            <span class="feat-tick-title">Login page broken</span>
          </div>
          <span class="feat-pill open">Open</span>
          <span class="feat-time">2m ago</span>
        </div>
        <div class="feat-ticket-row">
          <div class="feat-tick-accent" style="background:var(--status-progress)"></div>
          <div class="feat-tick-info">
            <span class="feat-tick-id">TH-002</span>
            <span class="feat-tick-title">Email not sending</span>
          </div>
          <span class="feat-pill progress">In Progress</span>
          <span class="feat-time">1h ago</span>
        </div>
        <div class="feat-ticket-row">
          <div class="feat-tick-accent" style="background:var(--priority-high)"></div>
          <div class="feat-tick-info">
            <span class="feat-tick-id">TH-003</span>
            <span class="feat-tick-title">Export fails on CSV</span>
          </div>
          <span class="feat-pill open">Open</span>
          <span class="feat-time">3h ago</span>
        </div>
        <div class="feat-ticket-row">
          <div class="feat-tick-accent" style="background:var(--status-closed)"></div>
          <div class="feat-tick-info">
            <span class="feat-tick-id">TH-004</span>
            <span class="feat-tick-title">Dark mode glitch</span>
          </div>
          <span class="feat-pill closed">Closed</span>
          <span class="feat-time">1d ago</span>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══ Feature 2 — AI Assistant ═══ -->
<section id="ai" class="lp-feature lp-feature--alt lp-feature--flip">
  <div class="lp-feature-inner">
    <div class="lp-feature-text" data-reveal>
      <p class="lp-label">AI Assistant</p>
      <h2 class="lp-h2">Ask questions.<br>Get answers.</h2>
      <p class="lp-body">The built-in Ollama assistant knows your tickets. Ask why something is open, what&rsquo;s urgent, or what happened last week &mdash; in plain language.</p>
      <a href="/auth/register.php" class="lp-link">Meet the assistant &rarr;</a>
    </div>
    <div class="lp-feature-visual" data-reveal data-delay="1">
      <div class="chat-window">
        <div class="chat-header">
          <span class="chat-online-dot"></span>
          AI Assistant
          <span class="chat-online-label">Online</span>
        </div>
        <div class="chat-body">
          <div class="chat-bubble user">Why is TH-023 still open?</div>
          <div class="chat-bubble ai">TH-023 has been open for 3 days. Priority: High. Last update: no response from assignee. Suggested action: follow up or escalate.</div>
          <div class="chat-bubble user">Escalate it</div>
          <div class="chat-bubble ai">Done. TH-023 priority updated to Critical.</div>
        </div>
        <div class="chat-input-bar">
          <div class="chat-input-bar-field">Ask about your tickets&hellip;</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══ Feature 3 — Priorities & Status ═══ -->
<section class="lp-feature">
  <div class="lp-feature-inner">
    <div class="lp-feature-text" data-reveal>
      <p class="lp-label">Workflow</p>
      <h2 class="lp-h2">Always know<br>what&rsquo;s urgent.</h2>
      <p class="lp-body">Three priority levels. Three statuses. A clear, simple workflow from the moment a ticket is created to the moment it&rsquo;s resolved.</p>
      <a href="/auth/register.php" class="lp-link">See the workflow &rarr;</a>
    </div>
    <div class="lp-feature-visual" data-reveal data-delay="1">
      <div class="kanban-board">
        <div class="kanban-col">
          <div class="kanban-col-head open">Open</div>
          <div class="kanban-cards">
            <div class="kanban-card"><span class="kanban-card-id">TH-001</span>Login page broken</div>
            <div class="kanban-card"><span class="kanban-card-id">TH-003</span>Export fails</div>
          </div>
        </div>
        <div class="kanban-col">
          <div class="kanban-col-head progress">In Progress</div>
          <div class="kanban-cards">
            <div class="kanban-card"><span class="kanban-card-id">TH-002</span>Email not sending</div>
          </div>
        </div>
        <div class="kanban-col">
          <div class="kanban-col-head closed">Closed</div>
          <div class="kanban-cards">
            <div class="kanban-card"><span class="kanban-card-id">TH-004</span>Dark mode <span class="kanban-card-check">&#10003;</span></div>
            <div class="kanban-card"><span class="kanban-card-id">TH-005</span>API timeout <span class="kanban-card-check">&#10003;</span></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══ Testimonials ═══ -->
<section class="lp-testimonials">
  <div class="lp-testimonials-head">
    <p class="lp-label" data-reveal>Testimonials</p>
    <h2 class="lp-h2" data-reveal data-delay="1">Trusted by teams.</h2>
  </div>
  <div class="testimonials-grid">
    <div class="testimonial-card" data-reveal data-delay="1">
      <p class="testimonial-quote">&ldquo;We switched from spreadsheets to Ticketsystem and never looked back. The AI assistant saves us hours every week.&rdquo;</p>
      <div class="testimonial-author">
        <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="Sarah K." loading="lazy" width="44" height="44">
        <div>
          <div class="testimonial-name">Sarah K.</div>
          <div class="testimonial-role">IT Manager, M&uuml;ller AG</div>
        </div>
      </div>
    </div>
    <div class="testimonial-card" data-reveal data-delay="2">
      <p class="testimonial-quote">&ldquo;Clean, fast, and the priority system is exactly what our team needed. Setup took minutes.&rdquo;</p>
      <div class="testimonial-author">
        <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Thomas B." loading="lazy" width="44" height="44">
        <div>
          <div class="testimonial-name">Thomas B.</div>
          <div class="testimonial-role">Support Lead, Weber GmbH</div>
        </div>
      </div>
    </div>
    <div class="testimonial-card" data-reveal data-delay="3">
      <p class="testimonial-quote">&ldquo;Open source and self-hosted. Finally a ticket tool I can trust with our internal data.&rdquo;</p>
      <div class="testimonial-author">
        <img src="https://randomuser.me/api/portraits/women/68.jpg" alt="Lena M." loading="lazy" width="44" height="44">
        <div>
          <div class="testimonial-name">Lena M.</div>
          <div class="testimonial-role">Developer, Stark Solutions</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══ Steps ═══ -->
<section id="how-it-works" class="lp-steps">
  <div class="lp-steps-head">
    <p class="lp-label" data-reveal>How it works</p>
    <h2 class="lp-h2" data-reveal data-delay="1">Up and running in minutes.</h2>
  </div>
  <div class="steps-grid lp-inner">
    <div class="step" data-reveal data-delay="1">
      <div class="step-num">1</div>
      <div class="step-title">Create a ticket</div>
      <p class="step-body">Describe the issue, set a priority level, and submit. Takes 30 seconds.</p>
    </div>
    <div class="step" data-reveal data-delay="2">
      <div class="step-num">2</div>
      <div class="step-title">Track progress</div>
      <p class="step-body">Update the status as work happens. Open &rarr; In Progress &rarr; Closed.</p>
    </div>
    <div class="step" data-reveal data-delay="3">
      <div class="step-num">3</div>
      <div class="step-title">Resolve with AI</div>
      <p class="step-body">Ask the Ollama assistant for context, summaries, or to suggest next actions.</p>
    </div>
  </div>
</section>

<!-- ═══ FAQ ═══ -->
<section id="faq" class="lp-faq">
  <div class="faq-section-head">
    <p class="lp-label" data-reveal>FAQ</p>
    <h2 class="lp-h2" data-reveal data-delay="1">Common questions.</h2>
  </div>
  <div class="lp-faq-inner" data-reveal data-delay="2">

    <div class="faq-item">
      <button class="faq-q">
        What is Ticketsystem?
        <svg class="faq-chevron" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
      </button>
      <div class="faq-body"><div class="faq-body-inner">Ticketsystem is an open-source ticket management web app built with PHP and MySQL. It lets teams create, track, and resolve support tickets with a built-in AI assistant powered by Ollama.</div></div>
    </div>

    <div class="faq-item">
      <button class="faq-q">
        Is it really free?
        <svg class="faq-chevron" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
      </button>
      <div class="faq-body"><div class="faq-body-inner">Yes. Ticketsystem is released under the MIT License. You can use, modify, and distribute it freely. There are no paid plans or vendor lock-in.</div></div>
    </div>

    <div class="faq-item">
      <button class="faq-q">
        How does the AI assistant work?
        <svg class="faq-chevron" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
      </button>
      <div class="faq-body"><div class="faq-body-inner">The AI assistant runs locally via Ollama — no data leaves your server. You can ask it questions about your tickets in plain language and it will respond using the context from your ticket database.</div></div>
    </div>

    <div class="faq-item">
      <button class="faq-q">
        What are the system requirements?
        <svg class="faq-chevron" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
      </button>
      <div class="faq-body"><div class="faq-body-inner">PHP 8.0+, MySQL 5.7+ or MariaDB 10.4+, and a web server (Apache or Nginx). For the AI assistant you also need Ollama installed on the same server or accessible via the network.</div></div>
    </div>

    <div class="faq-item">
      <button class="faq-q">
        Can multiple users work together?
        <svg class="faq-chevron" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
      </button>
      <div class="faq-body"><div class="faq-body-inner">Yes. Ticketsystem supports two roles: regular users who can create and manage their own tickets, and admins who can view and manage all tickets across the system.</div></div>
    </div>

    <div class="faq-item">
      <button class="faq-q">
        Is my data secure?
        <svg class="faq-chevron" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
      </button>
      <div class="faq-body"><div class="faq-body-inner">Passwords are hashed with bcrypt. All database queries use PDO prepared statements. Sessions are regenerated on login. Since you self-host, your data never leaves your own infrastructure.</div></div>
    </div>

    <div class="faq-item">
      <button class="faq-q">
        How do I get started?
        <svg class="faq-chevron" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
      </button>
      <div class="faq-body"><div class="faq-body-inner">Create an account using the &ldquo;Get started free&rdquo; button above. You&rsquo;ll be up and running in under two minutes.</div></div>
    </div>

    <div class="faq-item">
      <button class="faq-q">
        Can I change the priority after creating a ticket?
        <svg class="faq-chevron" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
      </button>
      <div class="faq-body"><div class="faq-body-inner">Yes. You can edit any ticket you created at any time, including its title, description, status, and priority. Admins can edit all tickets.</div></div>
    </div>

  </div>
</section>

<!-- ═══ CTA Band ═══ -->
<div class="lp-cta-band">
  <h2 data-reveal>Ready to get organized?</h2>
  <p data-reveal data-delay="1">Free, open source, and self-hosted. No vendor lock-in.</p>
  <div class="cta-actions" data-reveal data-delay="2">
    <a href="/auth/register.php" class="btn-white">Create your account</a>
    <a href="#features" class="btn-ghost-white">View features</a>
  </div>
</div>

<!-- ═══ Footer ═══ -->
<footer class="lp-footer">
  <div class="lp-footer-inner">
    <div class="footer-brand">
      <a href="/" class="nav-logo">
        <span class="nav-logo-mark">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="display:block"><path d="M3 4 L9 4 Q12 7 15 4 L21 4 Q23 4 23 6 L23 18 Q23 20 21 20 L15 20 Q12 17 9 20 L3 20 Q1 20 1 18 L1 6 Q1 4 3 4 Z"/><polyline points="8,13 11,16 16.5,9"/></svg>
        </span>
        Ticketsystem
      </a>
      <p class="footer-tagline">An open-source ticket management system with a built-in AI assistant. Self-hosted, privacy-first.</p>
      <p class="footer-copy">&copy; <?php echo date('Y'); ?> Ticketsystem. MIT License.</p>
    </div>
    <div class="footer-col">
      <h4>Product</h4>
      <ul>
        <li><a href="#features">Features</a></li>
        <li><a href="#ai">AI Assistant</a></li>
        <li><a href="#how-it-works">How it works</a></li>
        <li><a href="#faq">FAQ</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Legal</h4>
      <ul>
        <li><a href="/legal/datenschutz.php">Datenschutz</a></li>
        <li><a href="/legal/impressum.php">Impressum</a></li>
        <li><a href="/legal/nutzungsbedingungen.php">Nutzungsbedingungen</a></li>
      </ul>
    </div>
  </div>
</footer>

<script src="/public/js/canvas.js"></script>
<script src="/public/js/landing.js"></script>
</body>
</html>
```

- [ ] **Step 2: Commit**

```bash
git add index.php
git commit -m "feat: rewrite landing page with Zendesk-inspired layout and UI mockups"
```

---

### Task 3: Update `public/js/landing.js`

**Files:**
- Modify: `public/js/landing.js` (full replacement)

- [ ] **Step 1: Replace entire file with updated JS**

```javascript
(function () {
  'use strict';

  /* ══════════════════════════════════════════════════════
     Particle Constellation Field
     ══════════════════════════════════════════════════════ */
  var canvas = document.createElement('canvas');
  canvas.id = 'landing-canvas';
  canvas.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;z-index:0;pointer-events:none;';
  document.body.insertBefore(canvas, document.body.firstChild);

  var ctx = canvas.getContext('2d');
  var W, H;
  var mouse = { x: -9999, y: -9999 };

  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  window.addEventListener('mousemove', function (e) { mouse.x = e.clientX; mouse.y = e.clientY; });
  window.addEventListener('mouseleave', function () { mouse.x = -9999; mouse.y = -9999; });

  var COUNT        = 120;
  var CONNECT_DIST = 120;
  var CONNECT_D2   = CONNECT_DIST * CONNECT_DIST;
  var REPEL_DIST   = 110;
  var REPEL_D2     = REPEL_DIST * REPEL_DIST;
  var REPEL_FORCE  = 0.5;
  var MAX_SPEED    = 1.2;

  var particles = [];
  for (var i = 0; i < COUNT; i++) {
    particles.push({
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      vx: (Math.random() - 0.5) * 0.5,
      vy: (Math.random() - 0.5) * 0.5,
      r: Math.random() * 1.2 + 0.4,
      indigo: Math.random() < 0.12,
      phase: Math.random() * Math.PI * 2,
    });
  }

  function tick() {
    ctx.clearRect(0, 0, W, H);
    var i, j, p, a, b, dx, dy, d2, d, alpha, force;

    for (i = 0; i < COUNT; i++) {
      p = particles[i];
      dx = p.x - mouse.x; dy = p.y - mouse.y;
      d2 = dx * dx + dy * dy;
      if (d2 < REPEL_D2 && d2 > 0) {
        d = Math.sqrt(d2);
        force = (REPEL_DIST - d) / REPEL_DIST * REPEL_FORCE;
        p.vx += (dx / d) * force; p.vy += (dy / d) * force;
      }
      p.vx *= 0.97; p.vy *= 0.97;
      var spd = Math.sqrt(p.vx * p.vx + p.vy * p.vy);
      if (spd > MAX_SPEED) { p.vx = p.vx / spd * MAX_SPEED; p.vy = p.vy / spd * MAX_SPEED; }
      p.x += p.vx; p.y += p.vy;
      if (p.x < -2) p.x = W + 2; if (p.x > W+2) p.x = -2;
      if (p.y < -2) p.y = H + 2; if (p.y > H+2) p.y = -2;
      p.phase += 0.022;
      var light = document.documentElement.getAttribute('data-theme') === 'light';
      var baseAlpha = p.indigo ? 0.45 + Math.sin(p.phase) * 0.2 : (light ? 0.4 : 0.25);
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = p.indigo
        ? 'rgba(79,70,229,' + baseAlpha + ')'
        : (light ? 'rgba(50,50,80,' + baseAlpha + ')' : 'rgba(90,90,115,' + baseAlpha + ')');
      ctx.fill();
    }

    var light = document.documentElement.getAttribute('data-theme') === 'light';
    for (i = 0; i < COUNT; i++) {
      for (j = i + 1; j < COUNT; j++) {
        a = particles[i]; b = particles[j];
        dx = a.x - b.x; dy = a.y - b.y;
        d2 = dx * dx + dy * dy;
        if (d2 < CONNECT_D2) {
          d = Math.sqrt(d2);
          alpha = (1 - d / CONNECT_DIST) * (light ? 0.2 : 0.12);
          ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
          ctx.strokeStyle = (a.indigo || b.indigo)
            ? 'rgba(79,70,229,' + (alpha * 2.5) + ')'
            : (light ? 'rgba(50,50,80,' + alpha + ')' : 'rgba(90,90,115,' + alpha + ')');
          ctx.lineWidth = 0.5; ctx.stroke();
        }
      }
    }
    requestAnimationFrame(tick);
  }
  tick();

  /* ══════════════════════════════════════════════════════
     Navbar scroll border
     ══════════════════════════════════════════════════════ */
  var nav = document.getElementById('lp-nav');
  if (nav) {
    window.addEventListener('scroll', function () {
      nav.classList.toggle('scrolled', window.scrollY > 10);
    }, { passive: true });
  }

  /* ══════════════════════════════════════════════════════
     Hamburger menu toggle
     ══════════════════════════════════════════════════════ */
  var hamburger = document.getElementById('nav-hamburger');
  var mobileMenu = document.getElementById('nav-mobile');
  if (hamburger && mobileMenu) {
    hamburger.addEventListener('click', function () {
      var open = mobileMenu.classList.toggle('open');
      hamburger.setAttribute('aria-expanded', String(open));
    });
    mobileMenu.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        mobileMenu.classList.remove('open');
        hamburger.setAttribute('aria-expanded', 'false');
      });
    });
  }

  /* ══════════════════════════════════════════════════════
     Scroll Reveal (IntersectionObserver)
     ══════════════════════════════════════════════════════ */
  var reveals = document.querySelectorAll('[data-reveal]');
  if (reveals.length) {
    if ('IntersectionObserver' in window) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('revealed');
            io.unobserve(entry.target);
          }
        });
      }, { threshold: 0.1 });
      reveals.forEach(function (el) { io.observe(el); });
    } else {
      reveals.forEach(function (el) { el.classList.add('revealed'); });
    }
  }

  /* ══════════════════════════════════════════════════════
     FAQ Accordion
     ══════════════════════════════════════════════════════ */
  document.querySelectorAll('.faq-q').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var item   = btn.closest('.faq-item');
      var body   = item.querySelector('.faq-body');
      var isOpen = item.classList.contains('open');
      document.querySelectorAll('.faq-item.open').forEach(function (openItem) {
        openItem.classList.remove('open');
        openItem.querySelector('.faq-body').style.maxHeight = '0';
      });
      if (!isOpen) {
        item.classList.add('open');
        body.style.maxHeight = body.scrollHeight + 'px';
      }
    });
  });

})();
```

- [ ] **Step 2: Commit**

```bash
git add public/js/landing.js
git commit -m "feat: update landing.js with navbar scroll, hamburger, cleanup"
```

---

### Task 4: Update `public/css/auth.css`

**Files:**
- Modify: `public/css/auth.css`

- [ ] **Step 1: Replace `.auth-aside` background and `::before` overlay**

Find this block in `auth.css` (around line 32):
```css
/* Left panel — transparent so canvas shows through */
.auth-aside {
  opacity: 0;
  animation: authSlideLeft 0.7s cubic-bezier(0.16,1,0.3,1) forwards;
  animation-delay: 0.05s;
  position: relative;
  z-index: 1;
  padding: 48px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.auth-aside::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(ellipse 80% 60% at 30% 30%, rgba(79, 70, 229, 0.18), transparent 65%),
    linear-gradient(180deg, rgba(15, 15, 19, 0.55) 0%, rgba(15, 15, 19, 0.25) 100%);
  pointer-events: none;
  z-index: 0;
}
```

Replace it with:
```css
/* Left panel — solid indigo brand panel */
.auth-aside {
  opacity: 0;
  animation: authSlideLeft 0.7s cubic-bezier(0.16,1,0.3,1) forwards;
  animation-delay: 0.05s;
  position: relative;
  z-index: 1;
  padding: 48px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: linear-gradient(160deg, #3730A3 0%, #4F46E5 100%);
}
.auth-aside::before {
  content: '';
  position: absolute;
  inset: 0;
  background: radial-gradient(ellipse 70% 50% at 20% 15%, rgba(255,255,255,0.12), transparent 60%);
  pointer-events: none;
  z-index: 0;
}
```

- [ ] **Step 2: Update `.aside-logo` and `.aside-logo-mark` to use white text**

Find:
```css
.aside-logo {
  opacity: 0;
  animation: authFadeUp 0.6s cubic-bezier(0.16,1,0.3,1) forwards;
  animation-delay: 0.3s;
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 15px;
  font-weight: 600;
  color: var(--text);
  position: relative;
  z-index: 1;
}
.aside-logo-mark {
  width: 30px;
  height: 30px;
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.12);
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: var(--font-mono);
  font-size: 11px;
  font-weight: 700;
}
```

Replace with:
```css
.aside-logo {
  opacity: 0;
  animation: authFadeUp 0.6s cubic-bezier(0.16,1,0.3,1) forwards;
  animation-delay: 0.3s;
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 15px;
  font-weight: 700;
  color: white;
  position: relative;
  z-index: 1;
}
.aside-logo-mark {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.15);
  border: 1px solid rgba(255, 255, 255, 0.25);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  flex-shrink: 0;
}
```

- [ ] **Step 3: Remove `.aside-glow-wrap`, `.aside-glow-wrap::before`, `.aside-glow-wrap::after`, `.aside-ticket`, `.aside-ticket-feed`, `.feed-ticket`, `.feed-dot`, `.feed-ticket.exiting`, `.feed-ticket-meta`, `.aside-tagline` (old version)**

Delete everything from `/* ── GlowingShadow wrapper ── */` through to (and including) all feed-ticket and aside-tagline rules. These are no longer used.

- [ ] **Step 4: Add brand panel styles at the end of `auth.css`**

Append this block to the end of `public/css/auth.css`:

```css
/* ── Brand panel (left side of auth pages) ── */
.aside-tagline {
  font-size: 15px;
  color: rgba(255, 255, 255, 0.75);
  margin-top: 6px;
  position: relative;
  z-index: 1;
}

.brand-divider {
  height: 1px;
  background: rgba(255, 255, 255, 0.2);
  margin: 32px 0;
  position: relative;
  z-index: 1;
}

.brand-benefits {
  list-style: none;
  margin: 0; padding: 0;
  display: flex;
  flex-direction: column;
  gap: 18px;
  position: relative;
  z-index: 1;
  opacity: 0;
  animation: authFadeUp 0.65s cubic-bezier(0.16,1,0.3,1) 0.55s forwards;
}

.brand-benefit {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 15px;
  color: rgba(255, 255, 255, 0.9);
}

.brand-benefit-icon {
  width: 26px;
  height: 26px;
  background: rgba(255, 255, 255, 0.15);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  color: white;
}

.brand-testimonial {
  margin-top: auto;
  position: relative;
  z-index: 1;
  opacity: 0;
  animation: authFadeUp 0.65s cubic-bezier(0.16,1,0.3,1) 0.75s forwards;
}

.brand-testimonial-card {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 12px;
  padding: 18px;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
}

.brand-quote {
  font-size: 14px;
  font-style: italic;
  color: rgba(255, 255, 255, 0.9);
  line-height: 1.65;
  margin-bottom: 14px;
}

.brand-person {
  display: flex;
  align-items: center;
  gap: 10px;
}

.brand-person img {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid rgba(255, 255, 255, 0.3);
}

.brand-person-name {
  font-size: 13px;
  font-weight: 600;
  color: white;
}

.brand-person-role {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.6);
  margin-top: 1px;
}

/* Responsive: hide brand panel on mobile */
@media (max-width: 768px) {
  .auth-shell {
    grid-template-columns: 1fr;
  }
  .auth-aside {
    display: none;
  }
}
```

- [ ] **Step 5: Commit**

```bash
git add public/css/auth.css
git commit -m "style: replace auth aside glow panel with indigo brand panel"
```

---

### Task 5: Update Auth Pages HTML

**Files:**
- Modify: `auth/login.php`
- Modify: `auth/register.php`
- Modify: `auth/change-password.php`

The left `<aside class="auth-aside">` block is identical in all three files. Replace it in each.

- [ ] **Step 1: Replace `<aside class="auth-aside">…</aside>` in `auth/login.php`**

Find the current aside block (starts at `<aside class="auth-aside">`, ends at `</aside>`) and replace with:

```html
  <aside class="auth-aside">
    <div class="aside-logo">
      <span class="aside-logo-mark">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="display:block"><path d="M3 4 L9 4 Q12 7 15 4 L21 4 Q23 4 23 6 L23 18 Q23 20 21 20 L15 20 Q12 17 9 20 L3 20 Q1 20 1 18 L1 6 Q1 4 3 4 Z"/><polyline points="8,13 11,16 16.5,9"/></svg>
      </span>
      Ticketsystem
    </div>
    <p class="aside-tagline">Manage tickets. Stay organized.</p>

    <div class="brand-divider"></div>

    <ul class="brand-benefits">
      <li class="brand-benefit">
        <span class="brand-benefit-icon">
          <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        </span>
        Track every request in one place
      </li>
      <li class="brand-benefit">
        <span class="brand-benefit-icon">
          <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        </span>
        AI assistant built in
      </li>
      <li class="brand-benefit">
        <span class="brand-benefit-icon">
          <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        </span>
        Open source &amp; self-hosted
      </li>
    </ul>

    <div class="brand-testimonial">
      <div class="brand-testimonial-card">
        <p class="brand-quote">&ldquo;The AI assistant cut our response time in half.&rdquo;</p>
        <div class="brand-person">
          <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="Sarah K." loading="lazy" width="36" height="36">
          <div>
            <div class="brand-person-name">Sarah K.</div>
            <div class="brand-person-role">IT Manager</div>
          </div>
        </div>
      </div>
    </div>
  </aside>
```

- [ ] **Step 2: Apply the exact same aside block to `auth/register.php`**

Find and replace `<aside class="auth-aside">…</aside>` with the identical HTML from Step 1.

- [ ] **Step 3: Apply the exact same aside block to `auth/change-password.php`**

Find and replace `<aside class="auth-aside">…</aside>` with the identical HTML from Step 1.

- [ ] **Step 4: Remove the `<script src="/public/js/auth.js"></script>` line if it exists in any auth page**

The old live-ticker JS (auth.js) referenced `aside-ticket-feed` which no longer exists. Check each auth page for `<script src="/public/js/auth.js">` and remove the line if present. Run:

```bash
grep -rn "auth.js" /path/to/Ticketsystem/auth/
```

If found, delete those `<script>` lines.

- [ ] **Step 5: Commit**

```bash
git add auth/login.php auth/register.php auth/change-password.php
git commit -m "feat: redesign auth pages with indigo brand panel and testimonial"
```

---

## Self-Review

**Spec coverage check:**
- ✅ Navbar (scroll border, hamburger) — Task 3
- ✅ Hero (two-column, browser-frame mockup, badge, micro-stats) — Task 2
- ✅ Stats band — Task 2
- ✅ Feature sections × 3 with alternating flip layout — Tasks 1 & 2
- ✅ Ticket list illustration — Task 2
- ✅ Chat illustration — Task 2
- ✅ Kanban illustration — Task 2
- ✅ Testimonials with randomuser.me photos — Task 2
- ✅ Steps section — Task 2
- ✅ FAQ accordion — Tasks 2 & 3
- ✅ CTA band — Task 2
- ✅ Footer with 3 columns — Task 2
- ✅ Auth brand panel CSS — Task 4
- ✅ Auth pages HTML — Task 5
- ✅ Dark/light theme support via CSS variables — Task 1
- ✅ Responsive breakpoints — Task 1
- ✅ PHP logic untouched — Tasks 2 & 5 only change HTML, not PHP

**No placeholders found.**

**Type/class consistency:** All CSS classes defined in Task 1 (`landing.css`) match exactly the HTML classes used in Task 2 (`index.php`). All auth CSS classes added in Task 4 match HTML in Task 5.
