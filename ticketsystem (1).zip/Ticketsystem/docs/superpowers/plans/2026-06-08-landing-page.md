# Landing Page Redesign Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the light-theme `index.php` with a professional dark landing page using the existing design system, rebranded as "TicketSystem".

**Architecture:** Two file changes: `public/css/landing.css` (new — all landing-specific styles) and `index.php` (full rewrite — static HTML, no PHP). `app.css` provides tokens, buttons, and reset. `canvas.js` runs as hero background (already exists). No external font CDN — `app.css` already imports Space Grotesk + Space Mono via Google Fonts.

**Tech Stack:** Static HTML, `public/css/app.css` (tokens + buttons), `public/css/landing.css` (new), `public/js/canvas.js` (dot-matrix animation).

---

## File Map

| File | Action |
|------|--------|
| `public/css/landing.css` | **Create** — navbar, hero, features, steps, team, CTA, footer, responsive |
| `index.php` | **Rewrite** — full dark HTML, all sections, "TicketSystem" branding |

---

## Task 1: Create `public/css/landing.css`

**Files:**
- Create: `public/css/landing.css`

- [ ] **Step 1: Verify `public/css/` directory exists**

```bash
ls public/css/
```

Expected: shows `app.css`, `auth.css`, `dashboard.css` (confirms correct directory).

- [ ] **Step 2: Create `public/css/landing.css`**

Write the complete file:

```css
/* ══════════════════════════════════════════
   TicketSystem — Landing Page Styles
   Uses tokens from app.css
   ══════════════════════════════════════════ */

/* ── Navbar ── */
.nav {
  position: fixed;
  top: 0; left: 0; right: 0;
  z-index: 100;
  padding: 0 24px;
  transition: background 200ms ease, border-color 200ms ease;
}

.nav-inner {
  max-width: 1100px;
  margin: 0 auto;
  height: 64px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.nav-logo {
  display: flex;
  align-items: center;
  gap: 10px;
  font-weight: 600;
  font-size: 15px;
  letter-spacing: -0.02em;
  color: var(--text);
}

.nav-logo-mark {
  font-family: var(--font-mono);
  font-size: 12px;
  font-weight: 700;
  color: var(--brand);
  background: var(--brand-soft);
  border: 1px solid rgba(79, 70, 229, 0.3);
  border-radius: 6px;
  padding: 4px 8px;
  letter-spacing: 0;
}

.nav-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.nav.scrolled {
  background: rgba(15, 15, 19, 0.85);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  border-bottom: 1px solid var(--border);
}

/* ── Hero ── */
.hero {
  position: relative;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 120px 24px 80px;
}

.hero-content {
  position: relative;
  z-index: 1;
  max-width: 700px;
  margin: 0 auto;
}

.hero-label {
  display: inline-flex;
  align-items: center;
  font-family: var(--font-mono);
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--brand);
  background: var(--brand-soft);
  border: 1px solid rgba(79, 70, 229, 0.25);
  border-radius: 999px;
  padding: 6px 16px;
  margin-bottom: 32px;
}

.hero-title {
  font-size: clamp(42px, 7vw, 68px);
  font-weight: 700;
  line-height: 1.08;
  letter-spacing: -0.03em;
  color: var(--text);
  margin-bottom: 20px;
}

.hero-title span { color: var(--brand); }

.hero-sub {
  font-size: 18px;
  line-height: 1.6;
  color: var(--text-muted);
  max-width: 480px;
  margin: 0 auto 36px;
}

.hero-actions {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
  margin-bottom: 64px;
  flex-wrap: wrap;
}

.hero-preview {
  position: relative;
  max-width: 780px;
  margin: 0 auto;
}

.hero-glow {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 600px;
  height: 300px;
  background: radial-gradient(ellipse, rgba(79, 70, 229, 0.18) 0%, transparent 70%);
  pointer-events: none;
  z-index: 0;
}

.hero-mock {
  position: relative;
  z-index: 1;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r-xl);
  overflow: hidden;
  box-shadow: var(--sh-lg);
}

.hero-mock-bar {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 12px 16px;
  border-bottom: 1px solid var(--border);
  background: var(--surface-2);
}

.hero-mock-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: var(--border-strong);
}

.hero-mock-dot:nth-child(1) { background: rgba(239, 68, 68, 0.5); }
.hero-mock-dot:nth-child(2) { background: rgba(245, 158, 11, 0.5); }
.hero-mock-dot:nth-child(3) { background: rgba(34, 197, 94, 0.5); }

.hero-mock-title {
  font-size: 11px;
  color: var(--text-subtle);
  font-family: var(--font-mono);
  margin-left: 8px;
}

.hero-mock-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}

.hero-mock-table th {
  padding: 10px 16px;
  text-align: left;
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--text-subtle);
  border-bottom: 1px solid var(--border);
  background: var(--surface-2);
}

.hero-mock-table td {
  padding: 12px 16px;
  border-bottom: 1px solid rgba(42, 42, 53, 0.5);
  color: var(--text);
}

.hero-mock-table tr:last-child td { border-bottom: none; }

.mock-id {
  font-family: var(--font-mono);
  font-size: 11px;
  color: var(--text-muted);
}

.mock-badge {
  display: inline-flex;
  align-items: center;
  font-size: 11px;
  font-weight: 600;
  padding: 3px 10px;
  border-radius: 999px;
}

.mock-badge.open     { background: var(--status-open-soft);     color: var(--status-open); }
.mock-badge.progress { background: var(--status-progress-soft); color: var(--status-progress); }
.mock-badge.closed   { background: var(--status-closed-soft);   color: var(--status-closed); }
.mock-badge.high     { background: var(--priority-high-soft);   color: var(--priority-high); }
.mock-badge.medium   { background: var(--priority-medium-soft); color: var(--priority-medium); }
.mock-badge.low      { background: var(--priority-low-soft);    color: var(--priority-low); }

/* ── Shared section wrapper ── */
.section {
  padding: 100px 24px;
  max-width: 1100px;
  margin: 0 auto;
}

.section-label {
  font-family: var(--font-mono);
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--brand);
  margin-bottom: 12px;
}

.section-heading {
  font-size: clamp(28px, 4vw, 40px);
  font-weight: 700;
  letter-spacing: -0.025em;
  line-height: 1.15;
  color: var(--text);
  margin-bottom: 16px;
}

.section-sub {
  font-size: 16px;
  color: var(--text-muted);
  max-width: 520px;
  line-height: 1.6;
  margin-bottom: 56px;
}

/* ── Features ── */
.features-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
}

.feature-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r-lg);
  padding: 28px;
  transition: transform 200ms ease, border-color 200ms ease, box-shadow 200ms ease;
}

.feature-card:hover {
  transform: translateY(-3px);
  border-color: var(--border-strong);
  box-shadow: var(--sh);
}

.feature-icon {
  width: 40px;
  height: 40px;
  background: var(--brand-soft);
  border: 1px solid rgba(79, 70, 229, 0.2);
  border-radius: var(--r);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 16px;
  color: var(--brand);
}

.feature-title {
  font-size: 15px;
  font-weight: 600;
  letter-spacing: -0.015em;
  color: var(--text);
  margin-bottom: 8px;
}

.feature-desc {
  font-size: 14px;
  color: var(--text-muted);
  line-height: 1.6;
}

/* ── How it works ── */
.steps-section {
  background: var(--surface);
  padding: 100px 24px;
}

.steps-section > .section {
  padding: 0;
  max-width: 1100px;
  margin: 0 auto;
}

.steps-row {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 0;
  position: relative;
}

.steps-row::before {
  content: '';
  position: absolute;
  top: 28px;
  left: 12.5%;
  right: 12.5%;
  height: 1px;
  background: linear-gradient(to right, transparent, var(--border) 15%, var(--border) 85%, transparent);
}

.step {
  padding-right: 24px;
  position: relative;
  z-index: 1;
}

.step-num {
  font-family: var(--font-mono);
  font-size: 48px;
  font-weight: 700;
  color: var(--brand);
  opacity: 0.8;
  line-height: 1;
  margin-bottom: 20px;
  display: block;
}

.step-title {
  font-size: 15px;
  font-weight: 600;
  letter-spacing: -0.015em;
  color: var(--text);
  margin-bottom: 8px;
}

.step-desc {
  font-size: 14px;
  color: var(--text-muted);
  line-height: 1.6;
}

/* ── Team ── */
.team-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
  max-width: 640px;
}

.team-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r-lg);
  padding: 28px;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  gap: 10px;
  transition: transform 200ms ease, border-color 200ms ease;
}

.team-card:hover {
  transform: translateY(-2px);
  border-color: var(--border-strong);
}

.team-avatar {
  width: 52px;
  height: 52px;
  border-radius: 50%;
  background: var(--surface-2);
  border: 1px solid var(--border);
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: var(--font-mono);
  font-size: 14px;
  font-weight: 700;
  color: var(--brand);
  letter-spacing: 0;
}

.team-name {
  font-size: 14px;
  font-weight: 600;
  color: var(--text);
  letter-spacing: -0.01em;
}

.team-role {
  font-size: 12px;
  color: var(--text-muted);
}

/* ── CTA ── */
.cta-section {
  position: relative;
  padding: 100px 24px;
  text-align: center;
  overflow: hidden;
}

.cta-glow {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 800px;
  height: 400px;
  background: radial-gradient(ellipse, rgba(79, 70, 229, 0.12) 0%, transparent 70%);
  pointer-events: none;
}

.cta-section .section-heading { margin-bottom: 12px; }
.cta-section .section-sub { margin: 0 auto 36px; }

/* ── Footer ── */
.footer {
  border-top: 1px solid var(--border);
  padding: 28px 24px;
}

.footer-inner {
  max-width: 1100px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.footer-logo {
  display: flex;
  align-items: center;
  gap: 10px;
  font-weight: 600;
  font-size: 14px;
  color: var(--text-muted);
}

.footer-copy {
  font-size: 13px;
  color: var(--text-subtle);
}

/* ── Responsive ── */
@media (max-width: 768px) {
  .features-grid              { grid-template-columns: 1fr; }
  .steps-row                  { grid-template-columns: 1fr; gap: 40px; }
  .steps-row::before          { display: none; }
  .team-grid                  { grid-template-columns: 1fr; max-width: 280px; }
  .nav-actions .btn-ghost     { display: none; }
  .hero-mock                  { overflow-x: auto; }
}
```

- [ ] **Step 3: Commit**

```bash
git add public/css/landing.css
git commit -m "feat: add landing.css for dark landing page"
```

---

## Task 2: Rewrite `index.php`

**Files:**
- Modify: `index.php` (full rewrite — currently 638 lines of light-theme HTML)

- [ ] **Step 1: Verify current `index.php` starts with `<!doctype html>` (no PHP block)**

```bash
head -3 index.php
```

Expected output:
```
<!doctype html>
<html lang="en">
<head>
```

If there is a PHP block at the top, preserve it and only replace from `<!doctype html>` onwards.

- [ ] **Step 2: Rewrite `index.php`**

Replace the entire file contents with:

```html
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TicketSystem &mdash; Manage tickets. Stay organized.</title>
  <link rel="stylesheet" href="/public/css/app.css">
  <link rel="stylesheet" href="/public/css/landing.css">
</head>
<body>

<!-- ═══ Navbar ═══ -->
<nav class="nav" id="navbar">
  <div class="nav-inner">
    <a href="/" class="nav-logo">
      <span class="nav-logo-mark">TS</span>
      TicketSystem
    </a>
    <div class="nav-actions">
      <a href="/auth/login.php" class="btn btn-ghost">Sign in</a>
      <a href="/auth/register.php" class="btn btn-primary">Get started &rarr;</a>
    </div>
  </div>
</nav>
<script>
  window.addEventListener('scroll', function () {
    document.getElementById('navbar').classList.toggle('scrolled', window.scrollY > 50);
  });
</script>

<!-- ═══ Hero ═══ -->
<section class="hero">
  <div class="hero-content">
    <div class="hero-label">Ticket management, simplified</div>
    <h1 class="hero-title">Manage tickets.<br><span>Stay organized.</span></h1>
    <p class="hero-sub">The simple, fast ticket system built for teams that want clarity over complexity.</p>
    <div class="hero-actions">
      <a href="/auth/register.php" class="btn btn-primary btn-lg">Get started free &rarr;</a>
      <a href="/auth/login.php" class="btn btn-ghost btn-lg">Sign in</a>
    </div>
    <div class="hero-preview">
      <div class="hero-glow"></div>
      <div class="hero-mock">
        <div class="hero-mock-bar">
          <span class="hero-mock-dot"></span>
          <span class="hero-mock-dot"></span>
          <span class="hero-mock-dot"></span>
          <span class="hero-mock-title">TicketSystem &mdash; Dashboard</span>
        </div>
        <table class="hero-mock-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Title</th>
              <th>Status</th>
              <th>Priority</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="mock-id">TH-001</td>
              <td>Login page broken on mobile</td>
              <td><span class="mock-badge open">Open</span></td>
              <td><span class="mock-badge high">High</span></td>
            </tr>
            <tr>
              <td class="mock-id">TH-002</td>
              <td>Add CSV export feature</td>
              <td><span class="mock-badge progress">In Progress</span></td>
              <td><span class="mock-badge medium">Medium</span></td>
            </tr>
            <tr>
              <td class="mock-id">TH-003</td>
              <td>Update email notification template</td>
              <td><span class="mock-badge closed">Closed</span></td>
              <td><span class="mock-badge low">Low</span></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>

<!-- ═══ Features ═══ -->
<div class="section">
  <p class="section-label">Features</p>
  <h2 class="section-heading">Everything you need.<br>Nothing you don&rsquo;t.</h2>
  <div class="features-grid">

    <div class="feature-card">
      <div class="feature-icon">
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/></svg>
      </div>
      <h3 class="feature-title">Track tickets</h3>
      <p class="feature-desc">Keep every request logged and organized in one place.</p>
    </div>

    <div class="feature-card">
      <div class="feature-icon">
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/></svg>
      </div>
      <h3 class="feature-title">Set priorities</h3>
      <p class="feature-desc">Low, medium, high &mdash; always know what&rsquo;s urgent.</p>
    </div>

    <div class="feature-card">
      <div class="feature-icon">
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
      </div>
      <h3 class="feature-title">Manage status</h3>
      <p class="feature-desc">Open, in-progress, closed. Always know where things stand.</p>
    </div>

    <div class="feature-card">
      <div class="feature-icon">
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      </div>
      <h3 class="feature-title">Team roles</h3>
      <p class="feature-desc">Admins manage all tickets. Users own theirs.</p>
    </div>

    <div class="feature-card">
      <div class="feature-icon">
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      </div>
      <h3 class="feature-title">Fast search</h3>
      <p class="feature-desc">Find any ticket in seconds. No noise.</p>
    </div>

    <div class="feature-card">
      <div class="feature-icon">
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
      </div>
      <h3 class="feature-title">Secure by default</h3>
      <p class="feature-desc">Session auth, hashed passwords, prepared statements.</p>
    </div>

  </div>
</div>

<!-- ═══ How it works ═══ -->
<div class="steps-section">
  <div class="section">
    <p class="section-label">How it works</p>
    <h2 class="section-heading">Up and running in minutes.</h2>
    <div class="steps-row">
      <div class="step">
        <span class="step-num">01</span>
        <div class="step-title">Create your account</div>
        <div class="step-desc">Register in seconds. No credit card.</div>
      </div>
      <div class="step">
        <span class="step-num">02</span>
        <div class="step-title">Submit a ticket</div>
        <div class="step-desc">Describe the issue, set priority.</div>
      </div>
      <div class="step">
        <span class="step-num">03</span>
        <div class="step-title">Track progress</div>
        <div class="step-desc">Watch status change as work begins.</div>
      </div>
      <div class="step">
        <span class="step-num">04</span>
        <div class="step-title">Resolve and close</div>
        <div class="step-desc">Mark done when the job is done.</div>
      </div>
    </div>
  </div>
</div>

<!-- ═══ Team ═══ -->
<div class="section">
  <p class="section-label">Team</p>
  <h2 class="section-heading">Built by people who care.</h2>
  <div class="team-grid">
    <div class="team-card">
      <div class="team-avatar">YK</div>
      <div class="team-name">Youssef Khouda</div>
      <div class="team-role">Developer</div>
    </div>
    <div class="team-card">
      <div class="team-avatar">ED</div>
      <div class="team-name">Elias D&uuml;ggeli</div>
      <div class="team-role">Projektleiter</div>
    </div>
    <div class="team-card">
      <div class="team-avatar">PH</div>
      <div class="team-name">Philip Hempel</div>
      <div class="team-role">Product Owner</div>
    </div>
  </div>
</div>

<!-- ═══ CTA ═══ -->
<div class="cta-section">
  <div class="cta-glow"></div>
  <h2 class="section-heading">Ready to get started?</h2>
  <p class="section-sub">Sign up in seconds &mdash; no credit card required.</p>
  <a href="/auth/register.php" class="btn btn-primary btn-lg">Get started free &rarr;</a>
</div>

<!-- ═══ Footer ═══ -->
<footer class="footer">
  <div class="footer-inner">
    <div class="footer-logo">
      <span class="nav-logo-mark">TS</span>
      TicketSystem
    </div>
    <span class="footer-copy">&copy; 2026 TicketSystem. Built for Modul 151.</span>
  </div>
</footer>

<script src="/public/js/canvas.js"></script>
</body>
</html>
```

- [ ] **Step 3: Verify the file looks correct**

```bash
head -10 index.php
```

Expected: starts with `<!doctype html>`, title is "TicketSystem", links `app.css` and `landing.css`.

Also confirm "TicketHub" no longer appears:

```bash
grep -i "tickethub" index.php
```

Expected: no output (zero matches).

- [ ] **Step 4: Commit**

```bash
git add index.php
git commit -m "style: redesign index.php as dark landing page — rebrand to TicketSystem"
```
