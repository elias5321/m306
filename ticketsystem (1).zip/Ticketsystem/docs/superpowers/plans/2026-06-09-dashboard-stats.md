# Dashboard Stats Overview Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the existing per-card progress bar stats with 4 accent-bordered stat cards (Total, Open, In Progress, Closed) plus a single segmented proportion bar — scoped to the current user's tickets on the user dashboard and global on the admin panel.

**Architecture:** Three tasks in sequence: CSS additions first (so later tasks can rely on the classes), then `dashboard/user.php` (adds a second DB query scoped to the logged-in user), then `admin/index.php` (computes priority stats from the already-fetched ticket array and adds priority chips). No JS, no external libraries — pure server-rendered PHP and CSS.

**Tech Stack:** PHP 8, MySQL, PDO, CSS custom properties

---

## File Map

| File | Change |
|------|--------|
| `public/css/dashboard.css` | Add `.stat-card--*` accent variants, `.stats-proportion*` classes, `.stats-priority-row`; update `.stats` margin |
| `dashboard/user.php` | Add user-scoped stats query; remove old admin `.stats-bar` block; replace `.stats` HTML |
| `admin/index.php` | Add `$priority_stats` array; replace `.stats` HTML with new cards + proportion bar + priority chips |

---

### Task 1: Add stats CSS to `dashboard.css`

**Files:**
- Modify: `public/css/dashboard.css`

The file already has `.stat-card` base styles around line 186. We add border-left accent modifiers and the proportion bar classes. The existing `.stat-progress` / `.stat-bar--*` CSS can stay (harmless) since the HTML that uses them gets replaced in Tasks 2 and 3.

- [ ] **Step 1: Add border-left accent modifiers after the closing `}` of `.stat-card`**

Find (around line 190):
```css
.stat-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r-lg);
  padding: 20px 24px;
}
```

Insert immediately after:
```css
.stat-card--total    { border-left: 3px solid var(--border-strong); }
.stat-card--open     { border-left: 3px solid var(--brand); }
.stat-card--progress { border-left: 3px solid #F59E0B; }
.stat-card--closed   { border-left: 3px solid #22C55E; }
```

- [ ] **Step 2: Change `.stats` margin-bottom from 32px to 16px**

Find:
```css
.stats {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-bottom: 32px;
}
```

Change `margin-bottom: 32px` to `margin-bottom: 16px`. The `.stats-proportion` wrapper below provides the remaining bottom spacing.

- [ ] **Step 3: Add the proportion bar CSS block after the existing `.stat-bar--*` rules**

Find the last `.stat-bar--*` rule (around line 223):
```css
.stat-bar--closed   { background: var(--priority-low); }
```

Insert this entire block after it:
```css
/* ── Proportion bar ── */
.stats-proportion { margin-bottom: 32px; }
.stats-proportion-bar {
  display: flex;
  height: 8px;
  border-radius: 4px;
  overflow: hidden;
  background: var(--surface-3);
}
.stats-proportion-seg { height: 100%; }
.stats-proportion-seg--open     { background: var(--brand); }
.stats-proportion-seg--progress { background: #F59E0B; }
.stats-proportion-seg--closed   { background: #22C55E; }
.stats-proportion-seg--empty    { background: var(--border); width: 100%; }
.stats-proportion-legend {
  display: flex;
  gap: 16px;
  margin-top: 10px;
  flex-wrap: wrap;
}
.stats-proportion-legend-item {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: var(--text-muted);
}
.stats-proportion-legend-item::before {
  content: '';
  display: inline-block;
  width: 8px;
  height: 8px;
  border-radius: 2px;
  flex-shrink: 0;
}
.stats-proportion-legend-item--open::before     { background: var(--brand); }
.stats-proportion-legend-item--progress::before { background: #F59E0B; }
.stats-proportion-legend-item--closed::before   { background: #22C55E; }

/* ── Admin priority row ── */
.stats-priority-row {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 12px;
  font-size: 12px;
  color: var(--text-muted);
}
.stats-priority-row strong { color: var(--text); font-weight: 600; }
```

- [ ] **Step 4: Add responsive rule for legend inside the existing `@media (max-width: 768px)` block**

Find the existing responsive block:
```css
@media (max-width: 768px) {
  .dash { grid-template-columns: 1fr; }
  .sidebar { display: none; }
  .main { padding: 24px 20px; }
  .stats { grid-template-columns: 1fr 1fr; }
  .stats-bar { grid-template-columns: 1fr; }
  .form-row { grid-template-columns: 1fr; }
  .ticket-view-grid { grid-template-columns: 1fr; }
}
```

Add one line inside it after `.stats { grid-template-columns: 1fr 1fr; }`:
```css
  .stats-proportion-legend { gap: 10px; }
```

- [ ] **Step 5: Commit**
```bash
git add public/css/dashboard.css
git commit -m "style: add stat card accents and proportion bar CSS"
```

---

### Task 2: Update `dashboard/user.php`

**Files:**
- Modify: `dashboard/user.php`

The current file (lines 10–16) fetches ALL tickets with a single query. Stats are then computed via `array_filter` on the full result — meaning a regular user sees totals for every ticket in the system. We add a second, user-scoped query for the stat cards. The existing `$count_open`, `$count_progress` etc. stay unchanged because the filter chips still use them.

We also remove the admin-only `.stats-bar` block (lines 120–135) and replace the `.stats` block (lines 137–158).

- [ ] **Step 1: Add the user-scoped stats query before the existing `/* Compute stats */` comment**

Find (around line 18):
```php
/* Compute stats */
$count_open     = count(array_filter($tickets, fn($t) => $t['status'] === 'open'));
```

Insert BEFORE that comment:
```php
/* Stat cards: scoped to logged-in user's tickets */
$stmt_us = $pdo->prepare(
    'SELECT status, COUNT(*) AS cnt FROM tickets WHERE user_id = :uid GROUP BY status'
);
$stmt_us->execute([':uid' => (int)$_SESSION['user_id']]);
$stats = ['total' => 0, 'open' => 0, 'in_progress' => 0, 'closed' => 0];
foreach ($stmt_us->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $key = $row['status'] === 'in-progress' ? 'in_progress' : $row['status'];
    if (array_key_exists($key, $stats)) {
        $stats[$key] = (int)$row['cnt'];
    }
    $stats['total'] += (int)$row['cnt'];
}
$u_total        = max($stats['total'], 1);
$pct_open_u     = (int)round($stats['open']        / $u_total * 100);
$pct_progress_u = (int)round($stats['in_progress'] / $u_total * 100);
$pct_closed_u   = (int)round($stats['closed']      / $u_total * 100);
```

- [ ] **Step 2: Verify no PHP parse errors**
```bash
php -l dashboard/user.php
```
Expected: `No syntax errors detected in dashboard/user.php`

- [ ] **Step 3: Remove the admin-only `.stats-bar` block**

Find and delete this entire block:
```php
    <?php if (is_admin()): ?>
    <div class="stats-bar">
      <div class="stat-card">
        <div class="stat-number"><?php echo (int)$count_all; ?></div>
        <div class="stat-label">Total Tickets</div>
      </div>
      <div class="stat-card">
        <div class="stat-number"><?php echo (int)$count_open; ?></div>
        <div class="stat-label">Open</div>
      </div>
      <div class="stat-card">
        <div class="stat-number"><?php echo (int)$count_high; ?></div>
        <div class="stat-label">High Priority</div>
      </div>
    </div>
    <?php endif; ?>
```

- [ ] **Step 4: Replace the old `.stats` block with the new design**

Find this entire block:
```php
    <div class="stats">
      <div class="stat-card">
        <div class="stat-number status-open-num"><?php echo (int)$count_open; ?></div>
        <div class="stat-label">Open</div>
        <div class="stat-progress"><div class="stat-bar stat-bar--open" style="width:<?php echo $pct_open; ?>%"></div></div>
      </div>
      <div class="stat-card">
        <div class="stat-number status-progress-num"><?php echo (int)$count_progress; ?></div>
        <div class="stat-label">In Progress</div>
        <div class="stat-progress"><div class="stat-bar stat-bar--progress" style="width:<?php echo $pct_progress; ?>%"></div></div>
      </div>
      <div class="stat-card">
        <div class="stat-number priority-high-num"><?php echo (int)$count_high; ?></div>
        <div class="stat-label">High Priority</div>
        <div class="stat-progress"><div class="stat-bar stat-bar--high" style="width:<?php echo $pct_high; ?>%"></div></div>
      </div>
      <div class="stat-card">
        <div class="stat-number"><?php echo (int)$count_closed; ?></div>
        <div class="stat-label">Closed</div>
        <div class="stat-progress"><div class="stat-bar stat-bar--closed" style="width:<?php echo $pct_closed; ?>%"></div></div>
      </div>
    </div>
```

Replace with:
```php
    <div class="stats">
      <div class="stat-card stat-card--total">
        <div class="stat-number"><?php echo (int)$stats['total']; ?></div>
        <div class="stat-label">Total</div>
      </div>
      <div class="stat-card stat-card--open">
        <div class="stat-number status-open-num"><?php echo (int)$stats['open']; ?></div>
        <div class="stat-label">Open</div>
      </div>
      <div class="stat-card stat-card--progress">
        <div class="stat-number status-progress-num"><?php echo (int)$stats['in_progress']; ?></div>
        <div class="stat-label">In Progress</div>
      </div>
      <div class="stat-card stat-card--closed">
        <div class="stat-number"><?php echo (int)$stats['closed']; ?></div>
        <div class="stat-label">Closed</div>
      </div>
    </div>
    <div class="stats-proportion">
      <div class="stats-proportion-bar">
        <?php if ($stats['total'] === 0): ?>
        <span class="stats-proportion-seg stats-proportion-seg--empty"></span>
        <?php else: ?>
        <?php if ($stats['open'] > 0): ?>
        <span class="stats-proportion-seg stats-proportion-seg--open" style="width:<?php echo $pct_open_u; ?>%"></span>
        <?php endif; ?>
        <?php if ($stats['in_progress'] > 0): ?>
        <span class="stats-proportion-seg stats-proportion-seg--progress" style="width:<?php echo $pct_progress_u; ?>%"></span>
        <?php endif; ?>
        <?php if ($stats['closed'] > 0): ?>
        <span class="stats-proportion-seg stats-proportion-seg--closed" style="width:<?php echo $pct_closed_u; ?>%"></span>
        <?php endif; ?>
        <?php endif; ?>
      </div>
      <div class="stats-proportion-legend">
        <span class="stats-proportion-legend-item stats-proportion-legend-item--open">Open &mdash; <?php echo $pct_open_u; ?>%</span>
        <span class="stats-proportion-legend-item stats-proportion-legend-item--progress">In Progress &mdash; <?php echo $pct_progress_u; ?>%</span>
        <span class="stats-proportion-legend-item stats-proportion-legend-item--closed">Closed &mdash; <?php echo $pct_closed_u; ?>%</span>
      </div>
    </div>
```

- [ ] **Step 5: Verify no PHP parse errors**
```bash
php -l dashboard/user.php
```
Expected: `No syntax errors detected in dashboard/user.php`

- [ ] **Step 6: Verify in browser**

Visit your local dashboard URL as a regular user.

Expected:
- 4 stat cards in a row: Total · Open · In Progress · Closed, each with a colored left border accent
- Numbers reflect YOUR tickets only (not all tickets in the system)
- Below the cards: an 8px segmented bar in blue/amber/green proportional to status counts
- Legend below bar: `● Open — X%  ● In Progress — X%  ● Closed — X%`
- If you have 0 tickets: all numbers are 0, bar is solid gray, legend shows 0%

- [ ] **Step 7: Commit**
```bash
git add dashboard/user.php
git commit -m "feat: add user-scoped stat cards and proportion bar to dashboard"
```

---

### Task 3: Update `admin/index.php`

**Files:**
- Modify: `admin/index.php`

The current file computes `$count_open`, `$count_progress`, `$count_high`, `$count_closed` via `array_filter` on the full tickets array (lines 57–70) and already has `$pct_open`, `$pct_progress`, `$pct_closed` percentage variables. We add `$priority_stats` and replace the `.stats` HTML block (lines 157–178).

- [ ] **Step 1: Add priority stats computation after the existing percentage variables**

Find (around line 66):
```php
$total_pct    = max($total, 1);
$pct_open     = (int)round($count_open     / $total_pct * 100);
$pct_progress = (int)round($count_progress / $total_pct * 100);
$pct_high     = (int)round($count_high     / $total_pct * 100);
$pct_closed   = (int)round($count_closed   / $total_pct * 100);
```

Insert AFTER those lines:
```php
$priority_stats = [
    'low'    => count(array_filter($tickets, fn($t) => $t['priority'] === 'low')),
    'medium' => count(array_filter($tickets, fn($t) => $t['priority'] === 'medium')),
    'high'   => count(array_filter($tickets, fn($t) => $t['priority'] === 'high')),
];
```

- [ ] **Step 2: Verify no PHP parse errors**
```bash
php -l admin/index.php
```
Expected: `No syntax errors detected in admin/index.php`

- [ ] **Step 3: Replace the old `.stats` block with the new design**

Find this entire block (around lines 157–178):
```php
    <div class="stats">
      <div class="stat-card">
        <div class="stat-number status-open-num"><?php echo (int)$count_open; ?></div>
        <div class="stat-label">Open</div>
        <div class="stat-progress"><div class="stat-bar stat-bar--open" style="width:<?php echo $pct_open; ?>%"></div></div>
      </div>
      <div class="stat-card">
        <div class="stat-number status-progress-num"><?php echo (int)$count_progress; ?></div>
        <div class="stat-label">In Progress</div>
        <div class="stat-progress"><div class="stat-bar stat-bar--progress" style="width:<?php echo $pct_progress; ?>%"></div></div>
      </div>
      <div class="stat-card">
        <div class="stat-number priority-high-num"><?php echo (int)$count_high; ?></div>
        <div class="stat-label">High Priority</div>
        <div class="stat-progress"><div class="stat-bar stat-bar--high" style="width:<?php echo $pct_high; ?>%"></div></div>
      </div>
      <div class="stat-card">
        <div class="stat-number"><?php echo (int)$count_closed; ?></div>
        <div class="stat-label">Closed</div>
        <div class="stat-progress"><div class="stat-bar stat-bar--closed" style="width:<?php echo $pct_closed; ?>%"></div></div>
      </div>
    </div>
```

Replace with:
```php
    <div class="stats">
      <div class="stat-card stat-card--total">
        <div class="stat-number"><?php echo (int)$total; ?></div>
        <div class="stat-label">Total</div>
      </div>
      <div class="stat-card stat-card--open">
        <div class="stat-number status-open-num"><?php echo (int)$count_open; ?></div>
        <div class="stat-label">Open</div>
      </div>
      <div class="stat-card stat-card--progress">
        <div class="stat-number status-progress-num"><?php echo (int)$count_progress; ?></div>
        <div class="stat-label">In Progress</div>
      </div>
      <div class="stat-card stat-card--closed">
        <div class="stat-number"><?php echo (int)$count_closed; ?></div>
        <div class="stat-label">Closed</div>
      </div>
    </div>
    <div class="stats-proportion">
      <div class="stats-proportion-bar">
        <?php if ($total === 0): ?>
        <span class="stats-proportion-seg stats-proportion-seg--empty"></span>
        <?php else: ?>
        <?php if ($count_open > 0): ?>
        <span class="stats-proportion-seg stats-proportion-seg--open" style="width:<?php echo $pct_open; ?>%"></span>
        <?php endif; ?>
        <?php if ($count_progress > 0): ?>
        <span class="stats-proportion-seg stats-proportion-seg--progress" style="width:<?php echo $pct_progress; ?>%"></span>
        <?php endif; ?>
        <?php if ($count_closed > 0): ?>
        <span class="stats-proportion-seg stats-proportion-seg--closed" style="width:<?php echo $pct_closed; ?>%"></span>
        <?php endif; ?>
        <?php endif; ?>
      </div>
      <div class="stats-proportion-legend">
        <span class="stats-proportion-legend-item stats-proportion-legend-item--open">Open &mdash; <?php echo $pct_open; ?>%</span>
        <span class="stats-proportion-legend-item stats-proportion-legend-item--progress">In Progress &mdash; <?php echo $pct_progress; ?>%</span>
        <span class="stats-proportion-legend-item stats-proportion-legend-item--closed">Closed &mdash; <?php echo $pct_closed; ?>%</span>
      </div>
      <div class="stats-priority-row">
        Low: <strong><?php echo (int)$priority_stats['low']; ?></strong>
        &middot;
        Medium: <strong><?php echo (int)$priority_stats['medium']; ?></strong>
        &middot;
        High: <strong style="color:var(--priority-high);"><?php echo (int)$priority_stats['high']; ?></strong>
      </div>
    </div>
```

- [ ] **Step 4: Verify no PHP parse errors**
```bash
php -l admin/index.php
```
Expected: `No syntax errors detected in admin/index.php`

- [ ] **Step 5: Verify in browser**

Visit your local admin panel URL.

Expected:
- 4 stat cards: Total (all tickets in system), Open, In Progress, Closed — each with a colored left border
- Proportion bar showing the global status split in blue/amber/green
- Legend with percentages
- Priority row below legend: `Low: N · Medium: N · High: N` with High count in red

- [ ] **Step 6: Commit**
```bash
git add admin/index.php
git commit -m "feat: add global stat cards, proportion bar, and priority row to admin panel"
```
