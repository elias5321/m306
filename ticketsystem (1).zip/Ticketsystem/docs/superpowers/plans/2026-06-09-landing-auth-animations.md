# Landing & Auth Animations Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make the landing page and auth pages feel alive through improved scroll-reveal stagger, feature card glow, button ripple, dashboard preview 3D tilt, and an auth form card entrance animation.

**Architecture:** Four tasks in sequence — CSS foundations first (ripple/reveal), then JS behaviour (ripple attach + tilt), then auth CSS. No new files, no libraries. The particle canvas, `IntersectionObserver` scroll reveal, and input focus glow already exist and are not touched.

**Tech Stack:** Vanilla JS, CSS `@keyframes`, CSS custom properties

---

## What Already Exists — Do Not Rebuild

- `landing.js`: particle constellation canvas, `IntersectionObserver` reveal (`[data-reveal]` → `.revealed`), navbar scroll border, FAQ accordion
- `landing.css` lines 7–15: `[data-reveal]` / `.revealed` transition CSS
- `auth.css` lines 204–208: `.form-group .input:focus` glow — already done
- All `[data-reveal]` / `[data-delay]` attributes already in `index.php`

---

## File Map

| File | Change |
|------|--------|
| `public/css/app.css` | Add `position: relative; overflow: hidden` to `.btn` base rule (enables ripple on all buttons) |
| `public/css/landing.css` | Improve reveal transitions; add feat-card glow; add ripple CSS; add `will-change` on preview |
| `public/js/landing.js` | Add ripple function + attach to buttons; add preview tilt handler |
| `public/css/auth.css` | Add `card-enter` keyframe + apply to `.auth-card` |

---

### Task 1: Enable ripple on base `.btn` in `app.css`

**Files:**
- Modify: `public/css/app.css` (around line 185)

The `.btn` rule currently has no `position` or `overflow`. Adding both enables the absolutely-positioned ripple span to be clipped correctly on every button. This is a safe global change — no button in this app has overflow children that would be harmed.

- [ ] **Step 1: Open `public/css/app.css` and find the `.btn` rule**

It starts at line 185:
```css
.btn {
  display: inline-flex;
  align-items: center;
  ...
  border: 1px solid transparent;
}
```

- [ ] **Step 2: Add `position: relative` and `overflow: hidden` to `.btn`**

Find:
```css
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 0 20px;
  height: 38px;
  border-radius: 999px;
  font-family: var(--font-sans);
  font-size: 13px;
  font-weight: 600;
  letter-spacing: 0.01em;
  transition: background 180ms ease, box-shadow 180ms ease, transform 180ms ease, border-color 180ms ease, color 180ms ease;
  white-space: nowrap;
  text-decoration: none;
  cursor: pointer;
  border: 1px solid transparent;
}
```

Replace with:
```css
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 0 20px;
  height: 38px;
  border-radius: 999px;
  font-family: var(--font-sans);
  font-size: 13px;
  font-weight: 600;
  letter-spacing: 0.01em;
  transition: background 180ms ease, box-shadow 180ms ease, transform 180ms ease, border-color 180ms ease, color 180ms ease;
  white-space: nowrap;
  text-decoration: none;
  cursor: pointer;
  border: 1px solid transparent;
  position: relative;
  overflow: hidden;
}
```

- [ ] **Step 3: Verify in browser**

Open any page with a button (e.g. `/auth/login.php`). Buttons should look identical — no visual change expected. This step only verifies no regression.

- [ ] **Step 4: Commit**
```bash
git add public/css/app.css
git commit -m "style: add position and overflow to .btn for ripple support"
```

---

### Task 2: Update `landing.css`

**Files:**
- Modify: `public/css/landing.css`

Four changes: improve reveal transitions, upgrade feature card hover glow, add `.btn-white`/`.btn-ghost-white` ripple support, add ripple keyframe CSS, add `will-change` to preview browser.

- [ ] **Step 1: Improve the `[data-reveal]` transition block (lines 7–15)**

Find:
```css
[data-reveal] {
  opacity: 0;
  transform: translateY(24px);
  transition: opacity 0.6s ease, transform 0.6s ease;
}
[data-reveal][data-delay="1"] { transition-delay: 0.1s; }
[data-reveal][data-delay="2"] { transition-delay: 0.2s; }
[data-reveal][data-delay="3"] { transition-delay: 0.3s; }
[data-reveal].revealed        { opacity: 1; transform: none; }
```

Replace with:
```css
[data-reveal] {
  opacity: 0;
  transform: translateY(32px);
  transition: opacity 0.7s cubic-bezier(0.16, 1, 0.3, 1),
              transform 0.7s cubic-bezier(0.16, 1, 0.3, 1);
}
[data-reveal][data-delay="1"] { transition-delay: 0.12s; }
[data-reveal][data-delay="2"] { transition-delay: 0.26s; }
[data-reveal][data-delay="3"] { transition-delay: 0.42s; }
[data-reveal][data-delay="4"] { transition-delay: 0.58s; }
[data-reveal].revealed        { opacity: 1; transform: none; }
```

- [ ] **Step 2: Upgrade `.feat-grid-card:hover` glow**

Find:
```css
.feat-grid-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.08);
  border-color: rgba(79, 70, 229, 0.3);
}
[data-theme="dark"] .feat-grid-card:hover {
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.35);
}
```

Replace with:
```css
.feat-grid-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 0 0 1px var(--brand), 0 12px 32px rgba(79, 70, 229, 0.15);
  border-color: var(--brand);
}
[data-theme="dark"] .feat-grid-card:hover {
  box-shadow: 0 0 0 1px var(--brand), 0 12px 32px rgba(79, 70, 229, 0.28);
}
```

- [ ] **Step 3: Add `position: relative; overflow: hidden` to `.btn-white` and `.btn-ghost-white`**

Find the `.btn-white` rule:
```css
.btn-white {
  background: white;
  color: var(--brand);
  font-size: 15px;
  font-weight: 600;
  padding: 12px 28px;
  border-radius: var(--r);
  border: none;
  cursor: pointer;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  transition: opacity 150ms ease, transform 150ms ease;
  font-family: var(--font-sans);
}
```

Replace with:
```css
.btn-white {
  background: white;
  color: var(--brand);
  font-size: 15px;
  font-weight: 600;
  padding: 12px 28px;
  border-radius: var(--r);
  border: none;
  cursor: pointer;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  transition: opacity 150ms ease, transform 150ms ease;
  font-family: var(--font-sans);
  position: relative;
  overflow: hidden;
}
```

Find the `.btn-ghost-white` rule:
```css
.btn-ghost-white {
  background: transparent;
  color: white;
  font-size: 15px;
  font-weight: 600;
  padding: 12px 28px;
  border-radius: var(--r);
  border: 1.5px solid rgba(255, 255, 255, 0.4);
  cursor: pointer;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  transition: border-color 150ms ease, background 150ms ease;
  font-family: var(--font-sans);
}
```

Replace with:
```css
.btn-ghost-white {
  background: transparent;
  color: white;
  font-size: 15px;
  font-weight: 600;
  padding: 12px 28px;
  border-radius: var(--r);
  border: 1.5px solid rgba(255, 255, 255, 0.4);
  cursor: pointer;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  transition: border-color 150ms ease, background 150ms ease;
  font-family: var(--font-sans);
  position: relative;
  overflow: hidden;
}
```

- [ ] **Step 4: Add ripple CSS after the `.btn-ghost-white` rule block**

Find the line:
```css
.btn-ghost-white:hover { border-color: white; background: rgba(255, 255, 255, 0.08); }
```

Insert after it:
```css
/* ── Button ripple ── */
.ripple {
  position: absolute;
  border-radius: 50%;
  transform: scale(0);
  animation: ripple-out 0.6s linear forwards;
  pointer-events: none;
  width: 100px;
  height: 100px;
  margin-top: -50px;
  margin-left: -50px;
}
.btn-primary .ripple, .btn .ripple { background: rgba(255, 255, 255, 0.25); }
.btn-ghost .ripple, .btn-ghost-white .ripple { background: rgba(79, 70, 229, 0.18); }
.btn-white .ripple { background: rgba(79, 70, 229, 0.15); }
@keyframes ripple-out {
  to { transform: scale(4); opacity: 0; }
}
```

- [ ] **Step 5: Add `will-change: transform` to `.preview-browser`**

Find:
```css
.preview-browser {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 32px 80px rgba(0, 0, 0, 0.14), 0 0 0 1px rgba(79, 70, 229, 0.05);
}
```

Replace with:
```css
.preview-browser {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 32px 80px rgba(0, 0, 0, 0.14), 0 0 0 1px rgba(79, 70, 229, 0.05);
  will-change: transform;
}
```

- [ ] **Step 6: Verify no visual regressions**

Open the landing page. Check:
- Feature cards have a brand-blue glow + outline on hover (not just shadow)
- Buttons still look correct (no clipping of text due to overflow:hidden)
- Preview section unchanged visually

- [ ] **Step 7: Commit**
```bash
git add public/css/landing.css
git commit -m "style: improve reveal stagger, feat card glow, ripple CSS, preview will-change"
```

---

### Task 3: Add ripple JS and preview tilt to `landing.js`

**Files:**
- Modify: `public/js/landing.js`

Add two self-contained sections at the end of the IIFE, before the final `}());`. The ripple attaches a click listener to all landing page buttons. The tilt watches `mousemove` on `.preview-browser`.

- [ ] **Step 1: Open `public/js/landing.js` and find the closing of the IIFE**

The file ends with:
```js
  });
}());
```

- [ ] **Step 2: Add the ripple function before the `}());`**

Insert before the final `}());`:
```js
  /* ══════════════════════════════════════════════════════
     Button Ripple
     Creates an expanding circle from the click point.
     ══════════════════════════════════════════════════════ */
  function attachRipple(btn) {
    btn.addEventListener('click', function (e) {
      var rect   = btn.getBoundingClientRect();
      var span   = document.createElement('span');
      span.className = 'ripple';
      span.style.top  = (e.clientY - rect.top)  + 'px';
      span.style.left = (e.clientX - rect.left) + 'px';
      btn.appendChild(span);
      setTimeout(function () { span.remove(); }, 650);
    });
  }

  document.querySelectorAll('.btn, .btn-white, .btn-ghost-white').forEach(attachRipple);
```

- [ ] **Step 3: Add the preview tilt handler after the ripple block, still before `}());`**

Insert after the ripple block, before `}());`:
```js
  /* ══════════════════════════════════════════════════════
     Dashboard Preview 3D Tilt
     Tilts .preview-browser ±6° following the mouse.
     Eases back slowly on mouseleave.
     ══════════════════════════════════════════════════════ */
  var previewEl = document.querySelector('.preview-browser');
  if (previewEl) {
    previewEl.addEventListener('mousemove', function (e) {
      var rect = previewEl.getBoundingClientRect();
      var cx   = rect.left + rect.width  / 2;
      var cy   = rect.top  + rect.height / 2;
      var rx   = ((e.clientY - cy) / (rect.height / 2)) * -6;
      var ry   = ((e.clientX - cx) / (rect.width  / 2)) *  6;
      previewEl.style.transition = 'transform 0.1s ease-out';
      previewEl.style.transform  =
        'perspective(900px) rotateX(' + rx.toFixed(2) + 'deg) rotateY(' + ry.toFixed(2) + 'deg)';
    });
    previewEl.addEventListener('mouseleave', function () {
      previewEl.style.transition = 'transform 0.6s cubic-bezier(0.16, 1, 0.3, 1)';
      previewEl.style.transform  = 'perspective(900px) rotateX(0deg) rotateY(0deg)';
    });
  }
```

- [ ] **Step 4: Verify in browser**

Open the landing page and:
- Click any button — a circular ripple should expand from the click point and fade out
- Hover over the dashboard preview mockup — it should tilt subtly in 3D following your mouse, then ease back to flat on mouse leave
- Scroll down — each section should animate in with the improved stagger (longer, smoother than before)

- [ ] **Step 5: Commit**
```bash
git add public/js/landing.js
git commit -m "feat: add button ripple and dashboard preview 3D tilt"
```

---

### Task 4: Add auth card entrance animation to `auth.css`

**Files:**
- Modify: `public/css/auth.css`

Add a `card-enter` keyframe and apply it to `.auth-card`. The card fades in and scales up from 96% on page load. Input focus glow already exists at lines 204–208 — do not touch it.

- [ ] **Step 1: Open `public/css/auth.css` and find the `.auth-card` rule (line 55)**

```css
.auth-card {
  width: 100%;
  max-width: 400px;
}
```

- [ ] **Step 2: Add the `card-enter` keyframe and apply it to `.auth-card`**

Find:
```css
.auth-card {
  width: 100%;
  max-width: 400px;
}
```

Replace with:
```css
@keyframes card-enter {
  from {
    opacity: 0;
    transform: scale(0.96) translateY(12px);
  }
  to {
    opacity: 1;
    transform: scale(1) translateY(0);
  }
}

.auth-card {
  width: 100%;
  max-width: 400px;
  animation: card-enter 0.45s cubic-bezier(0.16, 1, 0.3, 1) both;
}
```

- [ ] **Step 3: Verify in browser**

Open `/auth/login.php`. On page load, the form card should fade in and scale up from slightly small. The effect should be subtle — not jarring. If it feels too slow, change `0.45s` to `0.35s`.

- [ ] **Step 4: Verify no regression on register and change-password pages**

Open `/auth/register.php` and `/auth/change-password.php`. Both should show the same entrance animation since they share `.auth-card`.

- [ ] **Step 5: Commit**
```bash
git add public/css/auth.css
git commit -m "style: add card entrance animation to auth pages"
```
