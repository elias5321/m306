# Admin Theme Design

## Goal

When an admin logs in to `dashboard/user.php`, the page automatically switches to a dark charcoal theme, displays "Admin" instead of the username, and shows a stats bar with total, open, and high-priority ticket counts.

## Architecture

Single file modified: `dashboard/user.php`. No new files.

Four targeted changes:

| Change | Location |
|--------|----------|
| `body.admin-theme` CSS block | Bottom of existing `<style>` tag |
| `class="admin-theme"` on `<body>` | `<body>` opening tag |
| `$display_name` variable | Top of PHP, replaces `$username` in sidebar and heading |
| Stats bar block | Between the "Welcome back" heading and the ticket table |

---

## Section 1 — CSS Dark Theme

Add a `body.admin-theme` block at the end of the `<style>` tag that overrides design tokens:

```css
body.admin-theme {
  --bg:            #111827;
  --surface:       #1F2937;
  --surface-2:     #374151;
  --border:        #374151;
  --border-strong: #4B5563;
  --text:          #F9FAFB;
  --text-muted:    #D1D5DB;
  --text-subtle:   #9CA3AF;
}

body.admin-theme .btn-outline {
  background: #1F2937;
  border-color: #374151;
}
```

Brand indigo (`#4F46E5`, `#3730A3`, `#EEF2FF`), priority colors, and status colors are unchanged — they retain sufficient contrast on dark surfaces.

---

## Section 2 — Body Class & Display Name

**`<body>` tag:**
```html
<body<?php if (is_admin()): ?> class="admin-theme"<?php endif; ?>>
```

**Display name variable** (at the top of PHP, after `$username` is set):
```php
$display_name = is_admin() ? 'Admin' : $username;
```

Replace every occurrence of `htmlspecialchars($username)` in the sidebar user card and the "Welcome back" heading with `htmlspecialchars($display_name)`.

The avatar initials (`strtoupper(substr($username, 0, 2))`) keep using `$username` so they still show the real initials.

---

## Section 3 — Stats Bar

**DB queries** — fetched at page load (top of PHP, after the ticket query):
```php
if (is_admin()) {
    $stat_total  = $pdo->query('SELECT COUNT(*) FROM tickets')->fetchColumn();
    $stat_open   = $pdo->query("SELECT COUNT(*) FROM tickets WHERE status = 'open'")->fetchColumn();
    $stat_high   = $pdo->query("SELECT COUNT(*) FROM tickets WHERE priority = 'high'")->fetchColumn();
}
```

**HTML** — inserted between the `<div class="main-head">` block and the ticket table, admin-only:
```php
<?php if (is_admin()): ?>
<div class="stats-bar">
  <div class="stat-card">
    <div class="stat-number"><?php echo (int)$stat_total; ?></div>
    <div class="stat-label">Total Tickets</div>
  </div>
  <div class="stat-card">
    <div class="stat-number"><?php echo (int)$stat_open; ?></div>
    <div class="stat-label">Open</div>
  </div>
  <div class="stat-card">
    <div class="stat-number"><?php echo (int)$stat_high; ?></div>
    <div class="stat-label">High Priority</div>
  </div>
</div>
<?php endif; ?>
```

**CSS** — added alongside the dark theme block:
```css
.stats-bar {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
  margin-bottom: 24px;
}
.stat-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r-lg);
  padding: 20px 24px;
}
.stat-number {
  font-size: 28px;
  font-weight: 700;
  letter-spacing: -0.03em;
  color: var(--text);
}
.stat-label {
  font-size: 12px;
  color: var(--text-muted);
  margin-top: 4px;
}
```

---

## Files Changed

| File | Change |
|------|--------|
| `dashboard/user.php` | CSS block, body class, display name variable, stats bar HTML + queries |

## Out of Scope

- Dark theme on other pages (`admin/index.php`, ticket pages)
- Persistent theme toggle (always dark for admin, always light for user)
- Admin-specific content beyond stats bar (e.g. inline status editing on dashboard)
