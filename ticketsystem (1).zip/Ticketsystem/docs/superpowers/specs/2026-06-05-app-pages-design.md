# App Pages Design

## Goal

Redesign `dashboard/user.php`, `tickets/create.php`, and `tickets/edit.php` using the new design system (`public/css/app.css` + `public/js/canvas.js`). Dark sidebar + main layout, dense ticket table, form cards. All existing PHP logic and variable names are untouched.

## Architecture

All three pages share a `240px sidebar + 1fr main` grid shell. A new `public/css/dashboard.css` holds the shared app-page layout CSS. Each page links `app.css` + `dashboard.css` in `<head>` and loads `canvas.js` before `</body>`. Old inline `<style>` blocks and font imports are removed. The canvas sits at `z-index: 0`; all page content is `z-index: 1`.

## Tech Stack

PHP 8, `public/css/app.css` (existing), `public/css/dashboard.css` (new), `public/js/canvas.js` (existing).

---

## Section 1 — Page Structure

### Shell

```css
.dash {
  display: grid;
  grid-template-columns: 240px 1fr;
  min-height: 100vh;
  position: relative;
  z-index: 1;
}
```

### Sidebar

`position: sticky; top: 0; height: 100vh; overflow-y: auto` — stays fixed while main scrolls.

```css
.sidebar {
  background: var(--surface);
  border-right: 1px solid var(--border);
  padding: 20px 14px;
  display: flex;
  flex-direction: column;
  position: sticky;
  top: 0;
  height: 100vh;
  overflow-y: auto;
  z-index: 1;
}
```

**Logo block:**
```html
<div class="sidebar-logo">
  <span class="sidebar-logo-mark">TS</span>
  TicketSystem
</div>
```
```css
.sidebar-logo {
  display: flex;
  align-items: center;
  gap: 9px;
  font-weight: 600;
  font-size: 14px;
  letter-spacing: -0.01em;
  padding: 4px 8px 20px;
  color: var(--text);
}
.sidebar-logo-mark {
  width: 24px;
  height: 24px;
  border-radius: 6px;
  background: var(--brand);
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: var(--font-mono);
  font-size: 10px;
  font-weight: 700;
}
```

**Nav links:**
```css
.sidebar-section {
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--text-subtle);
  padding: 14px 10px 6px;
}
.sidebar-link {
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 8px 10px;
  border-radius: var(--r);
  font-size: 13px;
  color: var(--text-muted);
  transition: background 130ms ease, color 130ms ease;
  text-decoration: none;
  width: 100%;
}
.sidebar-link:hover {
  background: var(--surface-2);
  color: var(--text);
}
.sidebar-link.active {
  background: var(--brand-soft);
  color: var(--brand);
}
.sidebar-count {
  margin-left: auto;
  font-size: 11px;
  font-weight: 600;
  font-family: var(--font-mono);
  padding: 1px 7px;
  border-radius: 999px;
  background: var(--surface-3);
  color: var(--text-muted);
}
.sidebar-link.active .sidebar-count {
  background: rgba(79, 70, 229, 0.25);
  color: var(--brand);
}
```

**User block at bottom:**
```css
.sidebar-bottom { margin-top: auto; padding-top: 12px; border-top: 1px solid var(--border); }
.sidebar-user {
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 10px;
  border-radius: var(--r);
  width: 100%;
  text-decoration: none;
  transition: background 130ms ease;
  color: var(--text);
}
.sidebar-user:hover { background: var(--surface-2); }
.avatar {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  background: var(--brand-soft);
  color: var(--brand);
  font-family: var(--font-mono);
  font-size: 11px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.sidebar-user-name {
  font-size: 13px;
  font-weight: 500;
  color: var(--text);
}
.sidebar-user-role {
  font-size: 11px;
  color: var(--text-muted);
}
```

### Main Area

```css
.main {
  padding: 40px 48px;
  background: var(--bg);
  position: relative;
  z-index: 1;
}
```

### Responsive

At ≤ 768px: sidebar collapses (`display: none`), main goes full width.

```css
@media (max-width: 768px) {
  .dash { grid-template-columns: 1fr; }
  .sidebar { display: none; }
  .main { padding: 24px 20px; }
}
```

---

## Section 2 — Dashboard (`dashboard/user.php`)

### Page Heading

```html
<div class="main-head">
  <div>
    <h1 class="page-title">Welcome back, <?php echo htmlspecialchars($display_name); ?>.</h1>
    <p class="page-sub">Here's what's happening with your tickets.</p>
  </div>
  <a href="/tickets/create.php" class="btn btn-primary">New ticket</a>
</div>
```

```css
.main-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  margin-bottom: 32px;
  gap: 16px;
}
.page-title {
  font-size: 28px;
  font-weight: 700;
  letter-spacing: -0.02em;
  color: var(--text);
  margin-bottom: 4px;
}
.page-sub {
  font-size: 14px;
  color: var(--text-muted);
}
```

### Stats Row (regular users)

4-column grid, reusing existing `$count_open`, `$count_progress`, `$count_high`, `$count_closed`:

```html
<div class="stats">
  <div class="stat-card">
    <div class="stat-number status-open-num"><?php echo (int)$count_open; ?></div>
    <div class="stat-label">Open</div>
  </div>
  <div class="stat-card">
    <div class="stat-number status-progress-num"><?php echo (int)$count_progress; ?></div>
    <div class="stat-label">In Progress</div>
  </div>
  <div class="stat-card">
    <div class="stat-number priority-high-num"><?php echo (int)$count_high; ?></div>
    <div class="stat-label">High Priority</div>
  </div>
  <div class="stat-card">
    <div class="stat-number"><?php echo (int)$count_closed; ?></div>
    <div class="stat-label">Closed</div>
  </div>
</div>
```

```css
.stats {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-bottom: 32px;
}
.stat-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r-lg);
  padding: 20px 24px;
}
.stat-number {
  font-size: 28px;
  font-weight: 700;
  letter-spacing: -0.03em;
  color: var(--text);
  font-family: var(--font-mono);
}
.stat-label {
  font-size: 12px;
  color: var(--text-muted);
  margin-top: 4px;
}
.status-open-num     { color: var(--status-open); }
.status-progress-num { color: var(--status-progress); }
.priority-high-num   { color: var(--priority-high); }
```

Note: The existing admin stats bar (`div.stats-bar`) that was added earlier sits above this stats row when `is_admin()` is true — leave it in place. The `$display_name = is_admin() ? 'Admin' : $username` logic also stays.

Note: Any `body.admin-theme` CSS class and its CSS variable overrides (added in a prior iteration when the app was light-themed) must be **removed** from `dashboard/user.php`. The entire design system is now dark — that override is no longer needed and will conflict.

### Toolbar

```html
<div class="tickets-toolbar">
  <input class="input" id="search" type="search" placeholder="Search tickets…" style="max-width:260px">
  <select class="input" id="filter-status">
    <option value="">All statuses</option>
    <option value="open">Open</option>
    <option value="in-progress">In Progress</option>
    <option value="closed">Closed</option>
  </select>
  <select class="input" id="filter-priority">
    <option value="">All priorities</option>
    <option value="low">Low</option>
    <option value="medium">Medium</option>
    <option value="high">High</option>
  </select>
</div>
```

```css
.tickets-toolbar {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}
```

### Ticket Table

```css
.tickets-table { width: 100%; border-collapse: collapse; }
.tickets-table th {
  text-align: left;
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  color: var(--text-subtle);
  font-family: var(--font-mono);
  padding: 10px 14px;
  background: var(--surface);
  border-bottom: 1px solid var(--border);
  white-space: nowrap;
}
.ticket-row td {
  padding: 12px 14px;
  vertical-align: middle;
  border-bottom: 1px solid var(--border);
  font-size: 13px;
  color: var(--text);
}
.ticket-row:hover td { background: var(--surface-2); }
.ticket-row:last-child td { border-bottom: none; }
.ticket-id {
  font-family: var(--font-mono);
  font-size: 12px;
  color: var(--text-subtle);
  white-space: nowrap;
}
.ticket-title {
  max-width: 320px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 500;
}
.ticket-actions {
  display: flex;
  gap: 6px;
  justify-content: flex-end;
}
```

**Table columns:** ID | Title | Status | Priority | Author | Age | Actions

**Empty state** (when no tickets match filters):
```html
<tr class="ticket-empty">
  <td colspan="7">
    <div class="empty-state">No tickets found.</div>
  </td>
</tr>
```
```css
.empty-state {
  text-align: center;
  padding: 48px 24px;
  color: var(--text-subtle);
  font-size: 14px;
}
```

### Client-Side Filtering

Inline `<script>` at bottom of page (before `canvas.js`):

```javascript
(function () {
  var search   = document.getElementById('search');
  var fStatus  = document.getElementById('filter-status');
  var fPriority = document.getElementById('filter-priority');
  var rows     = document.querySelectorAll('.ticket-row');
  var empty    = document.querySelector('.ticket-empty');

  function applyFilters() {
    var q  = search.value.toLowerCase();
    var st = fStatus.value;
    var pr = fPriority.value;
    var visible = 0;
    rows.forEach(function (row) {
      var title    = row.dataset.title;
      var status   = row.dataset.status;
      var priority = row.dataset.priority;
      var show = (!q  || title.includes(q))
              && (!st || status === st)
              && (!pr || priority === pr);
      row.style.display = show ? '' : 'none';
      if (show) visible++;
    });
    if (empty) empty.style.display = visible === 0 ? '' : 'none';
  }

  search.addEventListener('input', applyFilters);
  fStatus.addEventListener('change', applyFilters);
  fPriority.addEventListener('change', applyFilters);
}());
```

Each `<tr class="ticket-row">` must carry `data-title`, `data-status`, `data-priority` attributes (lowercase values).

---

## Section 3 — Create & Edit Forms

Both pages use the same sidebar shell. Main area has a centered form card.

```css
.form-wrap {
  max-width: 640px;
  margin: 0 auto;
  padding-top: 8px;
}
.form-card {
  background: var(--surface);
  border: 1px solid var(--border-strong);
  border-radius: var(--r-xl);
  box-shadow: var(--sh-lg);
  overflow: hidden;
}
.form-card-header {
  padding: 24px 28px 0;
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
}
.form-card-body {
  padding: 24px 28px;
  display: flex;
  flex-direction: column;
  gap: 20px;
}
.form-card-footer {
  padding: 20px 28px;
  border-top: 1px solid var(--border);
  display: flex;
  align-items: center;
  gap: 10px;
}
```

**`tickets/create.php` heading area:**
```html
<div class="main-head">
  <a href="/dashboard/user.php" class="page-back">&larr; Dashboard</a>
  <h1 class="page-title">New ticket.</h1>
</div>
```

**`tickets/edit.php` heading area:**
```html
<div class="main-head">
  <a href="/dashboard/user.php" class="page-back">&larr; Dashboard</a>
  <h1 class="page-title">Edit ticket.</h1>
</div>
```

```css
.page-back {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  font-weight: 500;
  color: var(--text-muted);
  margin-bottom: 12px;
  transition: color 140ms ease;
}
.page-back:hover { color: var(--text); }
```

**Form fields:**

All fields use `.label` + `.input` from design system. Status and priority are `<select class="input">`.

```html
<div class="form-group">
  <label class="label" for="title">Title</label>
  <input class="input" type="text" id="title" name="title"
    value="<?php echo htmlspecialchars($title); ?>"
    placeholder="Brief summary of the issue"
    maxlength="100" required>
</div>

<div class="form-group">
  <label class="label" for="description">Description</label>
  <textarea class="input" id="description" name="description"
    placeholder="Describe the issue in detail…" required><?php echo htmlspecialchars($description); ?></textarea>
</div>

<div class="form-row">
  <div class="form-group">
    <label class="label" for="status">Status</label>
    <select class="input" id="status" name="status">
      <option value="open"        <?php if ($status === 'open')        echo 'selected'; ?>>Open</option>
      <option value="in-progress" <?php if ($status === 'in-progress') echo 'selected'; ?>>In Progress</option>
      <option value="closed"      <?php if ($status === 'closed')      echo 'selected'; ?>>Closed</option>
    </select>
  </div>
  <div class="form-group">
    <label class="label" for="priority">Priority</label>
    <select class="input" id="priority" name="priority">
      <option value="low"    <?php if ($priority === 'low')    echo 'selected'; ?>>Low</option>
      <option value="medium" <?php if ($priority === 'medium') echo 'selected'; ?>>Medium</option>
      <option value="high"   <?php if ($priority === 'high')   echo 'selected'; ?>>High</option>
    </select>
  </div>
</div>
```

```css
.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}
```

**Footer buttons:**

Create page:
```html
<button type="submit" class="btn btn-primary">Create ticket</button>
<a href="/dashboard/user.php" class="btn btn-ghost">Cancel</a>
```

Edit page — submit + cancel + delete (delete uses a separate `<form>` with POST to `tickets/delete.php`):
```html
<button type="submit" class="btn btn-primary">Save changes</button>
<a href="/dashboard/user.php" class="btn btn-ghost">Cancel</a>
<form method="POST" action="/tickets/delete.php" style="margin-left:auto"
  onsubmit="return confirm('Delete this ticket?')">
  <input type="hidden" name="id" value="<?php echo (int)$ticket['id']; ?>">
  <button type="submit" class="btn btn-danger">Delete</button>
</form>
```

**Error alert** uses `.alert-error` from `dashboard.css`:
```html
<?php if (!empty($errors)): ?>
  <div class="alert-error">...</div>
<?php endif; ?>
```

`.alert-error` and `.alert-success` are defined in `dashboard.css` (not in `auth.css`):

```css
.alert-error {
  background: var(--priority-high-soft);
  color: var(--priority-high);
  border: 1px solid rgba(239, 68, 68, 0.25);
  border-radius: var(--r);
  padding: 12px 16px;
  font-size: 13px;
  line-height: 1.5;
  margin-bottom: 20px;
}
.alert-error ul { margin: 4px 0 0 16px; padding: 0; }

.alert-success {
  background: var(--priority-low-soft);
  color: var(--priority-low);
  border: 1px solid rgba(34, 197, 94, 0.25);
  border-radius: var(--r);
  padding: 12px 16px;
  font-size: 13px;
  margin-bottom: 20px;
}
```

---

## Section 4 — `edit.php` Not-Found State

The existing light-themed "not found" page (when ticket doesn't exist or user lacks permission) also gets the design system applied: link `app.css`, remove old inline styles, center with dark background.

```html
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Not Found — TicketSystem</title>
  <link rel="stylesheet" href="/public/css/app.css">
</head>
<body style="display:flex;align-items:center;justify-content:center;min-height:100vh;">
  <div style="text-align:center;max-width:400px;padding:24px;">
    <div class="text-subtle" style="margin-bottom:20px;opacity:0.4;">
      <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
    </div>
    <h1 style="font-size:32px;font-weight:700;letter-spacing:-0.02em;margin-bottom:10px;color:var(--text);">Not found.</h1>
    <p class="text-muted" style="font-size:14px;line-height:1.6;margin-bottom:24px;">
      This ticket doesn't exist or you don't have permission to view it.
    </p>
    <a href="/dashboard/user.php" class="btn btn-primary">Back to dashboard</a>
  </div>
  <script src="/public/js/canvas.js"></script>
</body>
</html>
```

Note: this page only links `app.css` (not `dashboard.css`) since it has no sidebar layout.

---

## Section 5 — Files

| File | Change |
|------|--------|
| `public/css/dashboard.css` | Create — shared app-page layout CSS |
| `dashboard/user.php` | Modify — replace HTML shell, keep all PHP logic |
| `tickets/create.php` | Modify — replace HTML shell, keep all PHP logic |
| `tickets/edit.php` | Modify — replace both HTML sections (not-found + form), keep PHP logic |

No new JS files. The client-side filter script is an inline `<script>` in `dashboard/user.php` only.

## Integration

Each page `<head>`:
```html
<link rel="stylesheet" href="/public/css/app.css">
<link rel="stylesheet" href="/public/css/dashboard.css">
```

Before `</body>`:
```html
<script src="/public/js/canvas.js"></script>
```

Old inline `<style>` blocks and Inter/Instrument Serif/JetBrains Mono font imports removed entirely.

Title tags updated: `Dashboard — TicketSystem`, `New ticket — TicketSystem`, `Edit ticket — TicketSystem`.

## Out of Scope

- Admin panel (sub-project 4)
- `tickets/delete.php` — no HTML, just PHP redirect logic
- `auth/logout.php` — no HTML
