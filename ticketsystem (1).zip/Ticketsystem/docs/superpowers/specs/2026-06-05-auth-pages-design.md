# Auth Pages Design

## Goal

Redesign `auth/login.php`, `auth/register.php`, and `auth/change-password.php` using the new design system (`public/css/app.css` + `public/js/canvas.js`). Dark animated split-panel layout. All existing inline styles and old Google Fonts imports are removed. PHP logic is untouched.

## Architecture

Split-panel layout (`1fr 1fr` grid). Left panel is transparent over the fixed dot-matrix canvas — animation bleeds through with no extra JavaScript. Right panel is solid `var(--surface)` with the form. All three pages share the same HTML shell; only the form fields and left panel tagline differ. No new files — inline `<style>` blocks and old font imports are replaced by the shared design system.

## Tech Stack

PHP 8, `public/css/app.css` design tokens + components, `public/js/canvas.js` animation engine, Google Fonts already loaded by `app.css`.

---

## Section 1 — Page Structure

Full-viewport split grid on all three pages:

```css
.auth-shell {
  display: grid;
  grid-template-columns: 1fr 1fr;
  min-height: 100vh;
  position: relative;
  z-index: 1;
}
```

**Left panel** — `position: relative; z-index: 1; overflow: hidden`. No solid background — the fixed canvas (z-index 0) shows through. A radial gradient overlay applied via a pseudo-element or child div keeps content readable:

```css
.auth-aside {
  position: relative;
  z-index: 1;
  padding: 48px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.auth-aside::before {
  content: '';
  position: absolute;
  inset: 0;
  background: radial-gradient(ellipse 80% 60% at 30% 30%, rgba(79,70,229,0.18), transparent 65%),
              linear-gradient(180deg, rgba(15,15,19,0.55) 0%, rgba(15,15,19,0.25) 100%);
  pointer-events: none;
  z-index: 0;
}
```

**Right panel** — solid dark surface, no canvas visible:

```css
.auth-form-wrap {
  background: var(--surface);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 48px;
  position: relative;
  z-index: 1;
}
```

**Responsive** — at ≤900px the left panel hides, right panel goes full-width:

```css
@media (max-width: 900px) {
  .auth-shell { grid-template-columns: 1fr; }
  .auth-aside { display: none; }
  .auth-form-wrap { padding: 32px 24px; align-items: flex-start; padding-top: 48px; }
}
```

---

## Section 2 — Left Panel

Three vertically-stacked layers inside `.auth-aside`.

### Wordmark (top)

```html
<div class="aside-logo">
  <span class="aside-logo-mark">TS</span>
  TicketSystem
</div>
```

```css
.aside-logo {
  display: flex;
  align-items: center;
  gap: 10px;
  font-family: var(--font-sans);
  font-size: 15px;
  font-weight: 600;
  color: var(--text);
  position: relative;
  z-index: 1;
}
.aside-logo-mark {
  width: 30px;
  height: 30px;
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.12);
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: var(--font-mono);
  font-size: 11px;
  font-weight: 700;
  color: var(--text);
}
```

### Glass Ticket Card (middle)

```html
<div class="aside-ticket">
  <div class="aside-ticket-top">
    <span class="aside-ticket-id font-mono">TS-042</span>
    <span class="pill priority-high"><span class="pill-dot"></span>High</span>
  </div>
  <div class="aside-ticket-title">API gateway timeout on /tickets endpoint</div>
  <div class="aside-ticket-meta">Opened 3m ago &middot; Assigned to you</div>
</div>
```

```css
.aside-ticket {
  margin-top: 48px;
  background: rgba(255, 255, 255, 0.04);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: var(--r-lg);
  padding: 20px 22px;
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  position: relative;
  z-index: 1;
}
.aside-ticket-top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}
.aside-ticket-id {
  font-size: 12px;
  color: var(--text-subtle);
}
.aside-ticket-title {
  font-size: 14px;
  font-weight: 500;
  color: var(--text);
  margin-bottom: 8px;
  line-height: 1.4;
}
.aside-ticket-meta {
  font-size: 12px;
  color: var(--text-muted);
}
```

### Tagline (bottom)

Pushed to the bottom of the flex column via `margin-top: auto`.

```html
<div class="aside-tagline">
  Every issue tracked.<br>Nothing lost.
</div>
```

```css
.aside-tagline {
  margin-top: auto;
  font-family: var(--font-sans);
  font-size: 34px;
  font-weight: 700;
  letter-spacing: -0.03em;
  line-height: 1.1;
  color: var(--text);
  position: relative;
  z-index: 1;
}
```

**`change-password.php` left panel variation:** tagline reads `"Keep your account<br>secure."` instead. Wordmark and ticket card are identical.

---

## Section 3 — Right Panel (Form)

```html
<div class="auth-form-wrap">
  <form class="auth-form" method="POST" action="...">
    <!-- heading, alerts, fields, submit, link -->
  </form>
</div>
```

```css
.auth-form {
  width: 100%;
  max-width: 400px;
  display: flex;
  flex-direction: column;
  gap: 0;
}
```

### Headings

Each page uses a distinct heading — no filler copy:

| Page | `<h1>` | Sub-lede |
|------|--------|----------|
| `login.php` | `Welcome back.` | `Sign in to your workspace.` |
| `register.php` | `Create account.` | `Join TicketSystem today.` |
| `change-password.php` | `New password.` | `Choose a strong password.` |

```css
.auth-form h1 {
  font-family: var(--font-sans);
  font-size: 40px;
  font-weight: 700;
  letter-spacing: -0.03em;
  line-height: 1.05;
  color: var(--text);
  margin-bottom: 8px;
}
.auth-lede {
  font-size: 15px;
  color: var(--text-muted);
  margin-bottom: 28px;
}
```

### Alerts

Error and success alerts use design system color tokens:

```css
.alert-error {
  background: var(--priority-high-soft);
  color: var(--priority-high);
  border: 1px solid rgba(239, 68, 68, 0.25);
  border-radius: var(--r);
  padding: 12px 16px;
  font-size: 13px;
  line-height: 1.5;
  margin-bottom: 20px;
}
.alert-error ul { margin: 4px 0 0 16px; padding: 0; }

.alert-success {
  background: var(--priority-low-soft);
  color: var(--priority-low);
  border: 1px solid rgba(34, 197, 94, 0.25);
  border-radius: var(--r);
  padding: 12px 16px;
  font-size: 13px;
  margin-bottom: 20px;
}
```

### Fields

Labels use `.label` class from design system. Inputs use `.input` class from design system. Fields are wrapped in a `.fields` container:

```css
.fields { display: flex; flex-direction: column; gap: 16px; margin-bottom: 24px; }
```

```html
<div class="fields">
  <div class="form-group">
    <label class="label" for="email">Email</label>
    <input class="input" type="email" id="email" name="email" ...>
  </div>
  <!-- more fields -->
</div>
```

Password fields wrap in a relative container for the toggle button. Each password field has a unique `id` and a matching icon `id`:

```html
<div class="form-group">
  <label class="label" for="password">Password</label>
  <div class="password-wrap">
    <input class="input" type="password" id="password" name="password" ...>
    <button type="button" class="password-toggle" onclick="togglePw('password','pw-icon1')" aria-label="Show or hide password">
      <span id="pw-icon1"><!-- eye SVG --></span>
    </button>
  </div>
</div>
```

The `togglePw(fieldId, iconId)` function is defined once per page (no shared JS file needed):

```javascript
var SVG_EYE     = '<svg ...eye open...></svg>';
var SVG_EYE_OFF = '<svg ...eye closed...></svg>';
function togglePw(fieldId, iconId) {
  var input = document.getElementById(fieldId);
  var icon  = document.getElementById(iconId);
  if (input.type === 'password') {
    input.type = 'text';
    icon.innerHTML = SVG_EYE_OFF;
  } else {
    input.type = 'password';
    icon.innerHTML = SVG_EYE;
  }
}
```

Pages with multiple password fields call `togglePw` with different IDs:
- `register.php`: `togglePw('password','pw-icon1')` and `togglePw('confirm_password','pw-icon2')`
- `change-password.php`: `togglePw('current_password','pw-icon1')`, `togglePw('new_password','pw-icon2')`, `togglePw('confirm_password','pw-icon3')`

```css
.password-wrap { position: relative; }
.password-wrap .input { padding-right: 44px; }
.password-toggle {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  padding: 4px;
  border-radius: 6px;
  color: var(--text-muted);
  transition: color 140ms ease;
  line-height: 1;
}
.password-toggle:hover { color: var(--text); }
```

### Submit Button

Full-width primary button using design system classes. The `.btn-block` modifier handles full-width + top margin:

```css
.btn-block { width: 100%; margin-top: 24px; }
```

```html
<button type="submit" class="btn btn-primary btn-lg btn-block">
  Sign in
</button>
```

Button labels per page: `Sign in` (login), `Create account` (register), `Update password` (change-password).

### Page Links

```html
<p class="auth-switch">
  Don&rsquo;t have an account? <a href="/auth/register.php">Create one</a>
</p>
```

```css
.auth-switch {
  text-align: center;
  font-size: 14px;
  color: var(--text-muted);
  margin-top: 20px;
}
.auth-switch a { color: var(--brand); font-weight: 500; }
.auth-switch a:hover { text-decoration: underline; }
```

**`change-password.php`** has no `.auth-switch` link (user is already logged in). Instead a small back link at the top: `← Back to dashboard` linking to `/dashboard/user.php`.

---

## Section 4 — Page-Specific Details

### `login.php`

Fields: email, password (with toggle).
Links: "Don't have an account? Create one" → `/auth/register.php`
Flash: `$_SESSION['flash_success']` shown as `.alert-success`

### `register.php`

Fields: username, email, password (with toggle), confirm password (with toggle).
Links: "Already have an account? Sign in" → `/auth/login.php`

### `change-password.php`

Fields: current password (with toggle), new password (with toggle), confirm new password (with toggle).
No page links. Back link at top: `← Dashboard` → `/dashboard/user.php`.
Left panel tagline: `"Keep your account<br>secure."`

---

## Section 5 — Integration

Each page `<head>` gets:
```html
<link rel="stylesheet" href="/public/css/app.css">
```

Each page before `</body>` gets:
```html
<script src="/public/js/canvas.js"></script>
```

All existing `<style>` blocks, old `@import` font links, and `<link>` tags for Instrument Serif / Inter / JetBrains Mono are removed and replaced entirely by the design system.

The title tag on each page is updated: `Sign in — TicketSystem`, `Create account — TicketSystem`, `Change password — TicketSystem`.

---

## Section 6 — Files Modified

| File | Change |
|------|--------|
| `auth/login.php` | Remove inline styles + old fonts. Add design system link + canvas script. Rewrite HTML shell. |
| `auth/register.php` | Remove inline styles + old fonts. Add design system link + canvas script. Rewrite HTML shell. |
| `auth/change-password.php` | Remove inline styles + old fonts. Add design system link + canvas script. Rewrite HTML shell. |

No new files created. PHP logic (validation, DB queries, session handling) is completely untouched.

## Out of Scope

- Dashboard or ticket pages (sub-project 3)
- Admin panel (sub-project 4)
- Any changes to PHP business logic
