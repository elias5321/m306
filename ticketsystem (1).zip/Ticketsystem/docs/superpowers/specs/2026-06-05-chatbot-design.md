# Dashboard Chatbot Design

## Goal

Add a floating AI chat widget to the dashboard that lets users have general conversations and get ticket analysis by mentioning a ticket number (e.g. "TH-042"). Powered by Ollama running locally with `llama3.1:8b`.

## Architecture

Three new files, zero modifications to existing files. The browser sends messages to a PHP proxy (`chat/message.php`) which handles ticket context injection server-side and calls the Ollama API. JS manages the floating widget UI and in-memory conversation history (session-only — clears on page refresh).

**Message flow:**
```
User types → chat.js → POST /chat/message.php → Ollama API → JSON reply → chat.js renders it
```

## Tech Stack

PHP 8, PDO, vanilla JS, Ollama REST API (`http://localhost:11434/api/chat`), model `llama3.1:8b`.

---

## Section 1 — Files

| File | Purpose |
|------|---------|
| `chat/message.php` | PHP proxy endpoint — receives message, injects ticket context, calls Ollama, returns JSON |
| `chat/chat.js` | Vanilla JS — widget HTML, open/close toggle, message history, fetch calls |
| `dashboard/user.php` | Add one `<script src="/chat/chat.js">` tag at the bottom (only change to existing file) |

---

## Section 2 — Chat UI

### States

**Collapsed** — Fixed round button, bottom-right corner (`bottom: 24px; right: 24px`), brand indigo `#4F46E5`, chat bubble SVG icon, `z-index: 200`. Small unread indicator dot when a reply arrives while collapsed.

**Expanded** — Card pops up above the button (360px wide, 480px tall):

- **Header:** "TicketHub AI" + close (×) button
- **Message area:** Scrollable bubble list
  - User messages: right-aligned, brand color background, white text
  - Assistant messages: left-aligned, surface color background, muted border
  - Timestamp per message (HH:MM format)
- **Input row:** Text input (placeholder: "Ask anything or mention TH-042…") + Send button. `Enter` key sends.
- **Welcome message** pre-loaded on first open: *"Hi! I can help you analyse any ticket — just mention a ticket number like TH-042."*

### Styling

Uses existing CSS design tokens: `--brand`, `--surface`, `--surface-2`, `--border`, `--text`, `--text-muted`, `--font-sans`, `--r`, `--r-lg`, `--sh-lg`. Fully self-contained in `chat.js` (injects its own `<style>` tag).

---

## Section 3 — PHP Backend (`chat/message.php`)

### Security

- `require_login()` — returns HTTP 401 JSON error for unauthenticated requests
- Input: read via `file_get_contents('php://input')`, decoded as JSON
- Message validated: non-empty string, max 1000 characters

### Ticket Detection

Regex: `/\bTH-(\d+)\b/i` — extracts numeric ID from message.

If matched: fetch from DB:
```sql
SELECT t.id, t.title, t.description, t.status, t.priority, u.username AS author
FROM tickets t JOIN users u ON t.user_id = u.id
WHERE t.id = :id
LIMIT 1
```
No ownership check — any logged-in user can ask about any ticket.

### System Prompt

**Without ticket context:**
```
You are a helpful IT support assistant for TicketHub. Answer questions clearly and concisely.
```

**With ticket context:**
```
You are a helpful IT support assistant for TicketHub.
The user is asking about the following ticket:

ID: TH-042
Title: [title]
Description: [description]
Status: [status] | Priority: [priority] | Author: [username]

Analyse this issue and suggest practical, step-by-step resolution strategies.
```

### Ollama Call

```
POST http://localhost:11434/api/chat
Content-Type: application/json

{
  "model": "llama3.1:8b",
  "messages": [
    {"role": "system", "content": "[system prompt]"},
    {"role": "user",   "content": "[user message]"}
  ],
  "stream": false
}
```

Timeout: 30 seconds.

### Responses

Success: `{"reply": "assistant message text"}`
Error: `{"error": "Could not reach AI. Is Ollama running?"}` (HTTP 200, handled gracefully in UI)

### Error Cases

| Scenario | Response |
|----------|----------|
| Not logged in | HTTP 401 `{"error": "Unauthorized"}` |
| Empty/missing message | HTTP 400 `{"error": "Message is required."}` |
| Message too long | HTTP 400 `{"error": "Message too long."}` |
| Ollama unreachable | HTTP 200 `{"error": "Could not reach AI. Is Ollama running?"}` |
| Ticket ID not found in DB | Proceeds without ticket context (bot answers as general assistant) |

---

## Section 4 — Conversation History (Session-Only)

History lives in a JS array in memory — never sent to or stored on the server. Each call to `message.php` sends only the current message (stateless backend). The visual history in the widget is purely client-side.

On page refresh or navigation away, history clears. No DB storage, no cookies.

---

## Out of Scope

- Streaming / typing animation
- Persistent chat history (DB storage)
- Multi-turn context sent to Ollama (each message is independent)
- Admin-only access (all logged-in users can use the chatbot)
- Chat history export
