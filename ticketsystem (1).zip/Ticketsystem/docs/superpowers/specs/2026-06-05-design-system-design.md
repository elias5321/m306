# Design System Design

## Goal

Create a shared CSS + JS foundation for TicketSystem's full visual redesign. Dark charcoal theme, indigo accent, Space Grotesk typography, and a live dot-matrix Canvas animation on every page. This is sub-project 1 of 4 — auth pages, app pages, and admin panel each consume this foundation in subsequent sub-projects.

## Architecture

Two new files: `public/css/app.css` and `public/js/canvas.js`. All pages link them. Page-specific layouts stay inline per page and are replaced in sub-projects 2–4. No build tools, no npm — pure CSS and vanilla JS.

## Tech Stack

PHP 8, vanilla CSS (custom properties), vanilla JS (Canvas 2D API), Google Fonts (Space Grotesk + Space Mono).

---

## Section 1 — Design Tokens

All tokens defined as CSS custom properties on `:root` in `public/css/app.css`.

### Color Palette

```css
/* Backgrounds */
--bg:          #0F0F13;
--surface:     #16161C;
--surface-2:   #1E1E26;
--surface-3:   #252530;

/* Borders */
--border:        #2A2A35;
--border-strong: #3A3A48;

/* Text */
--text:        #F0F0F5;
--text-muted:  #8888A0;
--text-subtle: #555568;

/* Brand */
--brand:       #4F46E5;
--brand-deep:  #3730A3;
--brand-soft:  rgba(79, 70, 229, 0.15);

/* Priority */
--priority-low:          #22C55E;
--priority-low-soft:     rgba(34, 197, 94, 0.12);
--priority-medium:       #F59E0B;
--priority-medium-soft:  rgba(245, 158, 11, 0.12);
--priority-high:         #EF4444;
--priority-high-soft:    rgba(239, 68, 68, 0.12);

/* Status */
--status-open:            #3B82F6;
--status-open-soft:       rgba(59, 130, 246, 0.12);
--status-progress:        #A855F7;
--status-progress-soft:   rgba(168, 85, 247, 0.12);
--status-closed:          #6B7280;
--status-closed-soft:     rgba(107, 114, 128, 0.12);

/* Spacing & Shape */
--r:    10px;
--r-lg: 14px;
--r-xl: 20px;

/* Shadows */
--sh:    0 4px 24px rgba(0, 0, 0, 0.4);
--sh-lg: 0 8px 40px rgba(0, 0, 0, 0.6);
```

### Typography

```css
/* Google Fonts import */
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Space+Mono:wght@400;700&display=swap');

--font-sans: 'Space Grotesk', ui-sans-serif, system-ui, sans-serif;
--font-mono: 'Space Mono', ui-monospace, monospace;
```

---

## Section 2 — Canvas Animation Engine (`public/js/canvas.js`)

Self-contained IIFE. Injects a fixed full-screen `<canvas>` into `<body>` automatically on page load.

### Behaviour

- Fixed position, `inset: 0`, `z-index: 0`, `pointer-events: none`
- Grid of 4px dots spaced 22px apart, covering the full viewport
- Each dot pulses independently via `sin(time * speed + phaseOffset)` where `phaseOffset` is seeded from dot position
- Dot color: indigo `rgba(79, 70, 229, α)` — max opacity 0.35
- A radial gradient overlay (dark center, slightly lighter edges) keeps center content readable
- Time increment: `0.0008` per frame — slow enough for long work sessions
- Canvas redraws grid on `window.resize`

### API

No public API. Script auto-runs when loaded. Body must exist when script executes (place before `</body>`).

---

## Section 3 — Base Components (`public/css/app.css`)

### Reset

```css
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
  font-family: var(--font-sans);
  background: var(--bg);
  color: var(--text);
  -webkit-font-smoothing: antialiased;
  letter-spacing: -0.01em;
  position: relative;
  z-index: 1;
}

/* Ensure page content sits above canvas */
body > *:not(canvas) { position: relative; z-index: 1; }

a { color: inherit; text-decoration: none; }
button { font: inherit; cursor: pointer; border: none; background: none; color: inherit; }
```

### Buttons

```css
.btn {
  display: inline-flex; align-items: center; justify-content: center; gap: 6px;
  padding: 0 20px; height: 38px; border-radius: 999px;
  font-size: 13px; font-weight: 600; letter-spacing: 0.01em;
  transition: all 180ms ease; white-space: nowrap; text-decoration: none;
  cursor: pointer;
}
.btn-sm { height: 30px; padding: 0 14px; font-size: 12px; }
.btn-lg { height: 46px; padding: 0 28px; font-size: 15px; }

.btn-primary {
  background: var(--brand); color: #fff;
  box-shadow: 0 0 0 rgba(79,70,229,0);
  transition: all 180ms ease, box-shadow 300ms ease;
}
.btn-primary:hover {
  background: var(--brand-deep);
  box-shadow: 0 0 20px rgba(79,70,229,0.4);
  transform: translateY(-1px);
}

.btn-ghost {
  background: transparent; color: var(--text-muted);
  border: 1px solid var(--border);
}
.btn-ghost:hover {
  border-color: var(--brand);
  color: var(--brand);
  background: var(--brand-soft);
}

.btn-danger {
  background: rgba(239,68,68,0.12); color: #EF4444;
  border: 1px solid rgba(239,68,68,0.2);
}
.btn-danger:hover {
  background: rgba(239,68,68,0.2);
  border-color: rgba(239,68,68,0.4);
}
```

### Inputs

```css
.input {
  font: inherit; font-size: 14px; color: var(--text);
  background: var(--surface-2); border: 1px solid var(--border);
  border-radius: var(--r); padding: 10px 14px;
  transition: border-color 150ms, box-shadow 150ms; outline: none;
  width: 100%;
}
.input::placeholder { color: var(--text-subtle); }
.input:focus {
  border-color: var(--brand);
  box-shadow: 0 0 0 3px rgba(79,70,229,0.15);
}

select.input { cursor: pointer; }
textarea.input { resize: vertical; min-height: 100px; line-height: 1.6; }
```

### Cards

```css
.card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r-lg);
  box-shadow: var(--sh);
}
.card-elevated {
  background: var(--surface);
  border: 1px solid var(--border-strong);
  border-radius: var(--r-xl);
  box-shadow: var(--sh-lg);
}
```

### Pills / Badges

```css
.pill {
  display: inline-flex; align-items: center; gap: 5px;
  padding: 3px 10px; border-radius: 999px;
  font-size: 11px; font-weight: 600; letter-spacing: 0.03em;
  font-family: var(--font-mono);
}
.pill-dot { width: 5px; height: 5px; border-radius: 50%; background: currentColor; flex-shrink: 0; }

.priority-low    { background: var(--priority-low-soft);    color: var(--priority-low);    }
.priority-medium { background: var(--priority-medium-soft); color: var(--priority-medium); }
.priority-high   { background: var(--priority-high-soft);   color: var(--priority-high);   }

.status-open     { background: var(--status-open-soft);     color: var(--status-open);     }
.status-progress { background: var(--status-progress-soft); color: var(--status-progress); }
.status-closed   { background: var(--status-closed-soft);   color: var(--status-closed);   }
```

### Flash Toast

```css
.toast {
  position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%);
  background: var(--surface); border: 1px solid var(--border);
  border-left: 3px solid var(--brand);
  border-radius: var(--r); padding: 12px 20px;
  font-size: 13px; font-weight: 500; color: var(--text);
  box-shadow: var(--sh-lg);
  animation: toast-in 0.3s ease forwards;
  z-index: 999; white-space: nowrap;
}
.toast-error { border-left-color: var(--priority-high); }

@keyframes toast-in {
  from { opacity: 0; transform: translateX(-50%) translateY(12px); }
  to   { opacity: 1; transform: translateX(-50%) translateY(0); }
}
```

### Label

```css
.label {
  display: block; font-size: 12px; font-weight: 600;
  color: var(--text-muted); letter-spacing: 0.06em;
  text-transform: uppercase; margin-bottom: 6px;
}
```

### Utility Classes

```css
.font-mono   { font-family: var(--font-mono); }
.text-muted  { color: var(--text-muted); }
.text-subtle { color: var(--text-subtle); }
.text-brand  { color: var(--brand); }
.sr-only     { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0,0,0,0); }
```

---

## Section 4 — Files Created

| File | Purpose |
|------|---------|
| `public/css/app.css` | All tokens, reset, components, utilities |
| `public/js/canvas.js` | Dot-matrix animation engine |

## Integration (Sub-projects 2–4)

Each page adds to `<head>`:
```html
<link rel="stylesheet" href="/public/css/app.css">
```

And before `</body>`:
```html
<script src="/public/js/canvas.js"></script>
```

## Out of Scope

- Page-specific layouts (sidebar, ticket table, forms) — handled in sub-projects 2–4
- Dark/light mode toggle — always dark
- CSS minification / bundling — plain files, no build step
