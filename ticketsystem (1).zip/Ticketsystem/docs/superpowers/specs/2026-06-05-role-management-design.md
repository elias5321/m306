# Role Management (Rollenverwaltung) Design

## Goal

Add an `admin` role to TicketHub. Admin users get a dedicated `/admin/` panel where they can manage every ticket regardless of ownership — changing status, priority, and deleting. Regular users are completely unaffected.

## Architecture

A single `role` ENUM column on `users` drives everything. The role is loaded into `$_SESSION` at login. Two new helper functions (`is_admin()`, `require_admin()`) in `includes/session.php` act as the central gate. A new `/admin/index.php` page provides the admin interface. Three existing files (`tickets/delete.php`, `tickets/edit.php`, `dashboard/user.php`) get small targeted changes to lift ownership restrictions for admins.

## Tech Stack

PHP 8, MySQL, PDO, vanilla JS — same as the rest of the app.

---

## Section 1 — Database

Add a `role` column to the `users` table:

```sql
ALTER TABLE users ADD COLUMN role ENUM('user','admin') NOT NULL DEFAULT 'user';
```

All existing users default to `'user'`. To promote someone:

```sql
UPDATE users SET role = 'admin' WHERE username = 'youssef';
```

No changes to the `tickets` table.

---

## Section 2 — Auth & Session

**`auth/login.php`** — fetch `role` in the SELECT query and store it in the session:

```php
// SELECT query must include role:
// SELECT id, username, password, role FROM users WHERE username = :username

$_SESSION['user_id']  = $user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['role']     = $user['role'];
```

**`includes/session.php`** — add two helpers alongside the existing `require_login()`:

```php
function is_admin(): bool {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function require_admin(): void {
    require_login();
    if (!is_admin()) {
        header('Location: /dashboard/user.php');
        exit();
    }
}
```

Non-admins hitting any admin URL are silently redirected to their dashboard.

---

## Section 3 — Admin Panel (`/admin/index.php`)

**File:** `admin/index.php` (new)

Protected by `require_admin()` at the top.

### Actions (all POST, same page)

| `action`          | What it does                                     |
|-------------------|--------------------------------------------------|
| `update_status`   | Sets `status` for any ticket ID (whitelisted)    |
| `update_priority` | Sets `priority` for any ticket ID (whitelisted)  |
| `delete`          | Deletes any ticket by ID, no ownership check     |

All inputs validated: `ctype_digit()` for ID, `in_array($val, $allowed, true)` for ENUM values.

### UI

- Page title: "Admin Panel" with total ticket count
- One row per ticket: ID · Title · Creator username · Status dropdown · Priority dropdown · Delete button
- Status/priority dropdowns use `onchange="this.form.submit()"` — no separate Save button
- Delete has `onsubmit="return confirm('Delete this ticket?')"` guard
- Flash toast on success (same `$_SESSION['flash_success']` / PRG pattern as the rest of the app)
- "← Back to dashboard" link at top

### Navigation hook

`dashboard/user.php` sidebar shows an "Admin panel →" link when `is_admin()` is true, placed under the Account section.

---

## Section 4 — Lifting Ownership Restrictions

### `tickets/delete.php`

```php
if (is_admin()) {
    $stmt = $pdo->prepare('DELETE FROM tickets WHERE id = :id');
    $stmt->execute([':id' => $id]);
} else {
    $stmt = $pdo->prepare('DELETE FROM tickets WHERE id = :id AND user_id = :uid');
    $stmt->execute([':id' => $id, ':uid' => $_SESSION['user_id']]);
}
```

### `tickets/edit.php`

Same pattern — admin fetches any ticket, regular user still requires `AND user_id = :user_id`.

### `dashboard/user.php`

Edit/Delete action buttons currently render only for the ticket owner. Add admin override:

```php
if ($is_owner || is_admin()):
```

---

## Files Changed / Created

| File                        | Change                                              |
|-----------------------------|-----------------------------------------------------|
| `admin/index.php`           | **New** — admin panel page                          |
| `includes/session.php`      | Add `is_admin()` and `require_admin()` helpers      |
| `auth/login.php`            | Fetch and store `role` in session                   |
| `tickets/delete.php`        | Bypass ownership check for admins                   |
| `tickets/edit.php`          | Bypass ownership check for admins                   |
| `dashboard/user.php`        | Show action buttons for admins + sidebar admin link |

## Out of Scope

- Admin promoting/demoting users via UI (done manually in DB)
- Full ticket editing (title, description) from admin panel — admins use the normal edit page
- User management page
