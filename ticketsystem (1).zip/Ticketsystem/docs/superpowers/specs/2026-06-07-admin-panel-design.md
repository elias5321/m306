# Admin Panel Design

## Goal

Redesign `admin/index.php` using the new design system (`public/css/app.css` + `public/css/dashboard.css`). Same dark sidebar+main shell as the other app pages. Inline status/priority editing and delete functionality are preserved exactly. PHP logic is untouched.

## Architecture

Single file change: `admin/index.php`. PHP lines 1–61 kept exactly (POST action handling, ticket fetch, flash read, `admin_ticket_id()` helper). Everything from the closing `?>` at line 62 to end of file is replaced with new dark HTML. A one-liner before `<!doctype html>` extracts `$__u` from `$_SESSION['username']` for the sidebar user block. No new CSS files — `app.css` + `dashboard.css` cover all layout and component needs.

## Tech Stack

PHP 8, `public/css/app.css` design tokens + components, `public/css/dashboard.css` sidebar+main layout, `public/js/canvas.js` animation engine.

---

## Section 1 — Page Structure

Same `.dash` grid shell as `dashboard/user.php`, `tickets/create.php`, and `tickets/edit.php`:

```html
<div class="dash">
  <aside class="sidebar">...</aside>
  <main class="main">...</main>
</div>
```

`<head>` links:
```html
<link rel="stylesheet" href="/public/css/app.css">
<link rel="stylesheet" href="/public/css/dashboard.css">
```

Before `</body>`:
```html
<script src="/public/js/canvas.js"></script>
```

Title tag: `Admin panel — TicketSystem`

One-liner before `<!doctype html>`:
```php
<?php $__u = $_SESSION['username'] ?? ''; ?>
```

---

## Section 2 — Sidebar

Identical structure to `tickets/create.php` and `tickets/edit.php` with one difference: the "Admin panel" link carries `class="sidebar-link active"` since we are on that page.

```
Workspace section
  Tickets           → /dashboard/user.php        (no active)

Account section
  Change password   → /auth/change-password.php  (no active)

Admin section
  Admin panel       → /admin/index.php            (active ✓)

Bottom
  Avatar (initials from $__u) + "Admin" label + "Sign out →" → /auth/logout.php
```

`$__dn` is hardcoded `'Admin'` — `require_admin()` at the top of the file guarantees admin access.

Sidebar user block:
```html
<div class="avatar"><?php echo htmlspecialchars(strtoupper(substr($__u, 0, 2))); ?></div>
<div class="sidebar-user-name">Admin</div>
<div class="sidebar-user-role">Sign out &rarr;</div>
```

---

## Section 3 — Main Area

### Header

```html
<div class="main-head">
  <div>
    <h1 class="page-title">Admin panel.</h1>
    <p class="page-sub"><?php echo $total; ?> tickets total.</p>
  </div>
</div>
```

No "New ticket" button — admins manage existing tickets, not create them here.

### Ticket Table

Uses `.tickets-table` from `dashboard.css`. Columns: ID, Title, Author, Status, Priority, Delete.

```html
<table class="tickets-table">
  <thead>
    <tr>
      <th>ID</th>
      <th>Title</th>
      <th>Author</th>
      <th>Status</th>
      <th>Priority</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($tickets as $ticket):
      $tid = admin_ticket_id((int)$ticket['id']);
    ?>
    <tr class="ticket-row">
      <td class="ticket-id"><?php echo htmlspecialchars($tid); ?></td>
      <td class="ticket-title"><?php echo htmlspecialchars($ticket['title']); ?></td>
      <td><?php echo htmlspecialchars($ticket['author']); ?></td>

      <!-- Inline status form -->
      <td>
        <form method="POST">
          <input type="hidden" name="action" value="update_status">
          <input type="hidden" name="id" value="<?php echo (int)$ticket['id']; ?>">
          <select name="status" class="input" style="max-width:140px" onchange="this.form.submit()">
            <option value="open"        <?php if ($ticket['status'] === 'open')        echo 'selected'; ?>>Open</option>
            <option value="in-progress" <?php if ($ticket['status'] === 'in-progress') echo 'selected'; ?>>In Progress</option>
            <option value="closed"      <?php if ($ticket['status'] === 'closed')      echo 'selected'; ?>>Closed</option>
          </select>
        </form>
      </td>

      <!-- Inline priority form -->
      <td>
        <form method="POST">
          <input type="hidden" name="action" value="update_priority">
          <input type="hidden" name="id" value="<?php echo (int)$ticket['id']; ?>">
          <select name="priority" class="input" style="max-width:130px" onchange="this.form.submit()">
            <option value="low"    <?php if ($ticket['priority'] === 'low')    echo 'selected'; ?>>Low</option>
            <option value="medium" <?php if ($ticket['priority'] === 'medium') echo 'selected'; ?>>Medium</option>
            <option value="high"   <?php if ($ticket['priority'] === 'high')   echo 'selected'; ?>>High</option>
          </select>
        </form>
      </td>

      <!-- Delete form -->
      <td>
        <form method="POST"
          onsubmit="return confirm('Delete <?php echo htmlspecialchars($tid, ENT_QUOTES); ?>? This cannot be undone.')">
          <input type="hidden" name="action" value="delete">
          <input type="hidden" name="id" value="<?php echo (int)$ticket['id']; ?>">
          <button type="submit" class="btn btn-sm btn-danger">Delete</button>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>
```

### Empty State

```html
<div class="empty-state">No tickets yet.</div>
```

### Flash Toast

```html
<?php if ($flash): ?>
<div class="toast toast-success" id="flash-toast">
  <?php echo htmlspecialchars($flash); ?>
</div>
<script>
  setTimeout(function () {
    var t = document.getElementById('flash-toast');
    if (t) { t.style.opacity = '0'; t.style.transition = 'opacity 400ms'; setTimeout(function () { t.remove(); }, 400); }
  }, 3000);
</script>
<?php endif; ?>
```

---

## Section 4 — Files Modified

| File | Change |
|------|--------|
| `admin/index.php` | Remove inline styles + old fonts. Add design system links + canvas script. Rewrite HTML shell. PHP logic (lines 1–61) completely untouched. |

No new files created.

## Out of Scope

- User management (create/delete users)
- Any changes to POST action handling or PHP business logic
- Admin-specific stats row (not requested)
