# Landing Page & Login Redesign — Zendesk-Inspired

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Redesign `index.php` and the auth pages to match the visual quality of Zendesk.de — wide alternating sections, SVG illustrations, real portrait photos for testimonials, and a brand illustration panel on auth pages. Both dark and light themes supported via the existing toggle.

**Architecture:** Pure HTML/CSS/JS — no frameworks, no build step. All SVG illustrations are inline. Person photos use `randomuser.me` URLs. CSS lives in `landing.css` (landing) and `auth.css` (auth). The existing PHP logic, session handling, and MySQL queries are untouched.

**Tech Stack:** PHP 8, vanilla CSS custom properties, vanilla JS, inline SVG, randomuser.me portrait CDN

---

## Visual Language

### Colors
- **Accent:** `#4F46E5` (indigo) — unchanged
- **Light mode:** bg `#FFFFFF`, sections alternate with `#F9FAFB`, headings `#111827`, body `#6B7280`, border `#E5E7EB`
- **Dark mode:** bg `#0F0F13`, alternate `#111118`, headings `#F9FAFB`, body `#9CA3AF`, border `rgba(255,255,255,0.08)`
- **Indigo soft bg (light):** `#EEF2FF`
- **Indigo soft bg (dark):** `rgba(79,70,229,0.12)`

### Typography
- Headings: `font-weight: 800`, `letter-spacing: -0.03em`, sizes 56px (hero), 44px (section), 32px (feature)
- Section labels: `font-size: 13px`, `font-weight: 600`, `letter-spacing: 0.08em`, `text-transform: uppercase`, color `#4F46E5`
- Body: `font-size: 18px`, `line-height: 1.7`, color muted

### Spacing
- Section vertical padding: `96px 0` (desktop), `64px 0` (mobile)
- Max content width: `1200px`, centered, `padding: 0 24px`
- Feature section gap (text ↔ illustration): `64px`

---

## Landing Page Sections (`index.php`)

### 1. Navbar
- Fixed, `backdrop-filter: blur(16px)`, `background: rgba(255,255,255,0.85)` light / `rgba(15,15,19,0.85)` dark
- Bottom border appears on scroll via JS (`window.scrollY > 10`)
- Left: SVG logo + "Ticketsystem"
- Center: anchor links — Features, AI Assistant, FAQ
- Right: "Sign in" ghost link + "Get started" indigo button
- Mobile: hamburger collapses to vertical menu

### 2. Hero
Two-column grid (`1fr 1fr`), `align-items: center`, `min-height: calc(100vh - 72px)`.

**Left column:**
- Badge: indigo pill — "✦ Now with AI assistance"
- H1: "Support tickets,\nsimplified." (line break via `<br>`)
- Subline: "Manage, prioritize, and resolve every request faster — with a built-in AI assistant powered by Ollama."
- Two buttons: "Get started free" (indigo, → `/auth/register.php`) + "See how it works" (ghost, → `#how-it-works`)
- Below buttons: 3 micro-stats inline — "Open source · Built with PHP & MySQL · AI-powered"

**Right column:**
- Browser-frame SVG illustration: a fake ticket dashboard
  - Grey top bar with 3 colored dots (red/yellow/green) + fake URL bar
  - Table header: ID / Title / Status / Priority
  - 4 ticket rows: TH-001 "Login page broken" Open High, TH-002 "Email not sending" In Progress Medium, TH-003 "Export fails" Open High, TH-004 "Dark mode glitch" Closed Low
  - Status pills: Open=indigo, In Progress=amber, Closed=green
  - Priority pills: High=red-tinted, Medium=yellow-tinted, Low=gray
- Floating card overlapping bottom-right of frame: "3 tickets resolved today ↑12%"

### 3. Stats Strip
Full-width indigo background band (`#4F46E5`), 3 stats centered in a row:
- "Open source" / "Free to use"
- "AI-powered" / "Built-in Ollama assistant"
- "3 statuses" / "Open · In Progress · Closed"

Light: white text on indigo. Dark: same.

### 4. Feature Section — Track Tickets (text left, SVG right)
**Text:** Label "FEATURES" · H2 "One place for every request." · Body "Every ticket is logged, timestamped, and organized. No more losing track of what's open, what's being handled, and what's done." · Link "Start tracking →"

**SVG:** Ticket list card (400×300px):
- Rounded card with subtle shadow
- Header: "All Tickets" + badge "12 open"
- 4 list rows each with: colored left-border accent, ticket ID + title, status pill, time ago

### 5. Feature Section — AI Assistant (SVG left, text right)
**Text:** Label "AI ASSISTANT" · H2 "Ask questions.\nGet answers." · Body "The built-in Ollama assistant knows your tickets. Ask why something is open, what's urgent, or what happened last week — in plain language." · Link "Meet the assistant →"

**SVG:** Chat window (400×320px):
- Chat header: "AI Assistant" + green dot "Online"
- User bubble (right-aligned, indigo bg): "Why is TH-023 still open?"
- AI bubble (left-aligned, surface bg): "TH-023 has been open for 3 days. Priority: High. Last update: no response from assignee. Suggested action: follow up or escalate."
- User bubble: "Escalate it"
- AI bubble: "Done. TH-023 priority updated to Critical."
- Input bar at bottom: placeholder "Ask about your tickets…"

### 6. Feature Section — Priorities & Status (text left, SVG right)
**Text:** Label "WORKFLOW" · H2 "Always know\nwhat's urgent." · Body "Three priority levels. Three statuses. A clear, simple workflow from the moment a ticket is created to the moment it's resolved." · Link "See the workflow →"

**SVG:** Three-column kanban board (420×280px):
- Column 1 "Open" (indigo header): 2 small ticket cards
- Column 2 "In Progress" (amber header): 1 card
- Column 3 "Closed" (green header): 2 cards with checkmark
- Each card: ticket ID, short title, priority badge

### 7. Testimonials (new section)
Three-card grid. Each card:
- Quote text (italic, 16px)
- Portrait photo from `randomuser.me` (48×48, circle)
- Name + role below photo

People:
- `https://randomuser.me/api/portraits/women/44.jpg` — "Sarah K." — "IT Manager, Müller AG" — "We switched from spreadsheets to Ticketsystem and never looked back. The AI assistant saves us hours every week."
- `https://randomuser.me/api/portraits/men/32.jpg` — "Thomas B." — "Support Lead, Weber GmbH" — "Clean, fast, and the priority system is exactly what our team needed. Setup took minutes."
- `https://randomuser.me/api/portraits/women/68.jpg` — "Lena M." — "Developer, Stark Solutions" — "Open source and self-hosted. Finally a ticket tool I can trust with our internal data."

### 8. How It Works
Id `how-it-works`. Three numbered steps horizontal:
1. "Create a ticket" — describe the issue, set priority
2. "Track progress" — update status as work happens
3. "Resolve with AI" — use the assistant to speed up resolution

Each step: large number (indigo, 48px bold), icon, title, body.

### 9. FAQ
Existing 8-item accordion, kept as-is but restyled to match new visual language (more padding, cleaner chevron, alternating bg section).

### 10. CTA Section
Full-width, indigo background:
- H2 "Ready to get organized?"
- Body "Free, open source, and self-hosted. No vendor lock-in."
- Two buttons: "Create your account" (white bg, indigo text) + "View on GitHub" (ghost white)

### 11. Footer
Three columns:
- Col 1: Logo + tagline + copyright
- Col 2: Product links (Features, AI Assistant, FAQ)
- Col 3: Legal links (Datenschutz, Impressum, Nutzungsbedingungen)
Top border, muted text.

---

## Auth Page Redesign (`auth/login.php`, `auth/register.php`, `auth/change-password.php`)

### Layout
Two-column split: left 45% brand panel, right 55% form panel.

### Left Brand Panel
- Background: indigo gradient (`#3730A3` → `#4F46E5`)
- Large ticket SVG logo (64×64, white stroke)
- H2: "Ticketsystem" (white, 28px bold)
- Tagline: "Manage tickets. Stay organized." (white, muted)
- Divider line
- Three benefit rows (white icon + white text):
  - "Track every request in one place"
  - "AI assistant built in"
  - "Open source & self-hosted"
- Bottom: testimonial card (white bg with 10% opacity, rounded):
  - Portrait photo (randomuser.me, 40×40, circle)
  - Quote: "The AI assistant cut our response time in half."
  - Name: "Sarah K., IT Manager"
- Subtle radial glow behind logo (indigo lighter, opacity 0.3)

### Right Form Panel
- Background: `var(--bg)` — adapts to dark/light
- Form card centered vertically, max-width 400px
- Title + subtitle above form
- Existing form fields + validation (unchanged)
- "Don't have an account?" / "Already have one?" link below form

### Responsive
Below 768px: left panel hidden, form takes full width. Logo + brand name shown above the form instead.

---

## CSS Architecture

### `landing.css` changes
- Remove: `.feature-glow-wrap`, `glow-hue`, `glow-blur-hue` keyframes (no longer used)
- Add: `.lp-nav`, `.lp-hero`, `.lp-stats-band`, `.lp-feature`, `.lp-feature--flip`, `.lp-testimonials`, `.lp-steps`, `.lp-cta-band`, `.lp-footer`
- Add: `.browser-frame` (SVG wrapper), `.chat-window` (SVG wrapper), `.kanban-board` (SVG wrapper)
- Keep: FAQ styles, scroll-reveal, `.section`, `.section-label`, `.section-heading`

### `auth.css` changes
- Remove: `.aside-glow-wrap` and its keyframes
- Add: `.auth-brand` (left panel), `.brand-benefits`, `.brand-testimonial`
- Keep: right panel form styles, all input/button styles

### `app.css`
No changes needed.

---

## JS Changes (`landing.js`)

### Additions
- Navbar scroll border: `window.addEventListener('scroll', () => nav.classList.toggle('scrolled', scrollY > 10))`
- Mobile hamburger toggle

### Keep
- Particle canvas
- Typewriter (hero title — update text)
- Scroll reveal
- FAQ accordion

### Remove
- 3D tilt on hero-mock (replaced by static browser-frame SVG)
- Card deck shuffle

---

## Responsive Breakpoints

- `< 1024px`: feature sections stack (illustration below text), hero stacks
- `< 768px`: nav collapses to hamburger, auth hides left panel, stats strip wraps
- `< 480px`: hero headline drops to 40px, section padding reduces

---

## What Does NOT Change

- All PHP logic (auth, session, PDO queries)
- `app.css` tokens (CSS custom properties)
- `theme.js` (dark/light toggle)
- `canvas.js` (particle background)
- Dashboard, admin, tickets pages
- Legal pages (minor footer link update only)
