# Landing Page Redesign Design

## Goal

Redesign `index.php` using the dark design system (`public/css/app.css` + a new `public/css/landing.css`). Rebrand "TicketHub" → "TicketSystem" everywhere. Public-facing, visually attractive, and consistent with the app's dark charcoal + indigo aesthetic. All 6 sections kept: Navbar, Hero, Features, How it works, Team, CTA + Footer.

## Architecture

Two file changes: `index.php` (full rewrite — no PHP at the top, pure HTML) and `public/css/landing.css` (new file). `app.css` provides design tokens and base styles. `canvas.js` powers the hero dot-matrix background. No external fonts or CDN dependencies — Space Grotesk and Space Mono are already loaded via `app.css`.

## Tech Stack

PHP 8 (static page — no PHP needed), `public/css/app.css` (design tokens), `public/css/landing.css` (landing-specific layouts), `public/js/canvas.js` (dot-matrix animation).

---

## Section 1 — Page Structure

**Files:**

| File | Action |
|------|--------|
| `index.php` | Full rewrite — replace everything |
| `public/css/landing.css` | New file |

**`<head>` links:**
```html
<link rel="stylesheet" href="/public/css/app.css">
<link rel="stylesheet" href="/public/css/landing.css">
```

**Before `</body>`:**
```html
<script src="/public/js/canvas.js"></script>
```

**Title tag:** `TicketSystem — Manage tickets. Stay organized.`

---

## Section 2 — Navbar

Fixed top, full-width. Starts transparent; gains `backdrop-filter: blur(12px)` + dark semi-transparent background after 50px scroll via a `.scrolled` class toggled by an inline `<script>`.

```
[ TS  TicketSystem ]                    [ Sign in ]  [ Get started → ]
```

- Left: `TS` logo mark (indigo, Space Mono) + "TicketSystem" (Space Grotesk)
- Right: "Sign in" ghost link → `/auth/login.php` + "Get started" indigo button → `/auth/register.php`
- Thin bottom border on `.scrolled` state

HTML structure:
```html
<nav class="nav" id="navbar">
  <div class="nav-inner">
    <a href="/" class="nav-logo">
      <span class="nav-logo-mark">TS</span>
      TicketSystem
    </a>
    <div class="nav-actions">
      <a href="/auth/login.php" class="btn btn-ghost">Sign in</a>
      <a href="/auth/register.php" class="btn btn-primary">Get started &rarr;</a>
    </div>
  </div>
</nav>
<script>
  window.addEventListener('scroll', function () {
    document.getElementById('navbar').classList.toggle('scrolled', window.scrollY > 50);
  });
</script>
```

---

## Section 3 — Hero

Full viewport height (`min-height: 100vh`), centered content. `canvas.js` dot-matrix runs as the background (fixed, z-index 0). Content sits above at z-index 1.

```
         [canvas.js dot matrix background]

    TS

  Manage tickets.
  Stay organized.

  The simple, fast ticket system built for teams
  that want clarity over complexity.

  [ Get started free → ]   [ Sign in ]

  [mock dashboard preview card]
```

- Headline: 56–64px, bold, tight letter-spacing (two lines)
- Subtext: 16–18px, `--text-muted` color, max-width 480px
- CTAs: indigo primary + ghost, side by side
- Mock dashboard card: dark surface card below CTAs showing a mini static ticket table (3 rows: one open/high, one in-progress/medium, one closed/low). Styled with `app.css` tokens. Subtle indigo radial glow behind it.

Mock ticket table rows (static, no PHP):
```
TH-001  Login page broken        Open        High
TH-002  Add export feature       In Progress  Medium
TH-003  Update email template    Closed       Low
```

---

## Section 4 — Features

Section label "FEATURES" in small indigo monospace above the heading. 3-column card grid on desktop, 1-column on mobile.

**Heading:** "Everything you need. Nothing you don't."

**6 cards:**

| Icon | Title | Description |
|------|-------|-------------|
| Inbox SVG | Track tickets | Keep every request logged and organized. |
| Flag SVG | Set priorities | Low, medium, high — always know what's urgent. |
| Toggle SVG | Manage status | Open, in-progress, closed. Always know where things stand. |
| Users SVG | Team roles | Admins manage all tickets. Users own theirs. |
| Search SVG | Fast search | Find any ticket in seconds. No noise. |
| Lock SVG | Secure by default | Session auth, hashed passwords, prepared statements. |

Card structure:
```html
<div class="feature-card">
  <div class="feature-icon"><!-- SVG --></div>
  <h3 class="feature-title">Track tickets</h3>
  <p class="feature-desc">Keep every request logged and organized.</p>
</div>
```

Cards: `--surface` background, `1px solid var(--border)` border, `border-radius: 12px`, `padding: 28px`, hover: slight translate-Y lift.

---

## Section 5 — How It Works

Slightly darker background (`--surface` instead of `--bg`) to separate from Features visually. Section label "HOW IT WORKS" above heading.

**Heading:** "Up and running in minutes."

4 steps in a horizontal row on desktop (stacked on mobile). Connector line between steps on desktop.

**Steps:**

| Number | Title | Description |
|--------|-------|-------------|
| 01 | Create your account | Register in seconds. No credit card. |
| 02 | Submit a ticket | Describe the issue, set priority. |
| 03 | Track progress | Watch status change as work begins. |
| 04 | Resolve and close | Mark done when the job is done. |

Step number: large indigo monospace (`48px`, `font-family: var(--font-mono)`). Connector line: `1px solid var(--border)` between step boxes on desktop, hidden on mobile.

---

## Section 6 — Team

Section label "TEAM" above heading. 3-column card grid.

**Heading:** "Built by people who care."

**3 team members:**

| Initials | Name | Role |
|----------|------|------|
| YK | Youssef Khouda | Developer |
| ED | Elias Düggeli | Projektleiter |
| PH | Philip Hempel | Product Owner |

Card structure:
```html
<div class="team-card">
  <div class="team-avatar">YK</div>
  <div class="team-name">Youssef Khouda</div>
  <div class="team-role">Developer</div>
</div>
```

Avatar: `48px` circle, `--surface-2` background, indigo-tinted initials (Space Mono). Same visual pattern as sidebar avatar. Card style matches feature cards.

---

## Section 7 — CTA

Dark section with a subtle indigo radial glow (CSS `radial-gradient` in background). Centered content.

```
  Ready to get started?
  Sign up in seconds — no credit card required.

  [ Get started free → ]
```

- Heading: bold, large
- Subtext: muted
- Single indigo CTA button → `/auth/register.php`

---

## Section 8 — Footer

Minimal, single row with thin top border.

```
  TS  TicketSystem          © 2026 TicketSystem. Built for Modul 151.
```

- Left: logo mark + name
- Right: copyright text in `--text-muted`
- Same dark charcoal background as page

---

## Section 9 — CSS (`public/css/landing.css`)

Landing-specific styles only — no duplication of `app.css` tokens. Key classes:

- `.nav`, `.nav-inner`, `.nav-logo`, `.nav-logo-mark`, `.nav-actions` — navbar layout
- `.nav.scrolled` — backdrop-filter + border on scroll
- `.hero`, `.hero-content`, `.hero-title`, `.hero-sub`, `.hero-actions`, `.hero-preview` — hero section
- `.hero-mock` — mock dashboard card
- `.section`, `.section-label`, `.section-heading` — shared section wrapper
- `.features-grid` — 3-col CSS grid
- `.feature-card`, `.feature-icon`, `.feature-title`, `.feature-desc` — feature cards
- `.steps-row`, `.step`, `.step-num`, `.step-title`, `.step-desc` — how it works
- `.team-grid`, `.team-card`, `.team-avatar`, `.team-name`, `.team-role` — team section
- `.cta-section` — CTA with indigo glow
- `.footer` — minimal footer

---

## Section 10 — Files Modified

| File | Change |
|------|--------|
| `index.php` | Full rewrite: dark design system, all sections, "TicketSystem" branding |
| `public/css/landing.css` | New file: all landing-specific layout and component styles |

No changes to `app.css`, `dashboard.css`, `canvas.js`, or any PHP files.

## Out of Scope

- Any PHP logic or authentication changes
- Mobile hamburger menu
- Animations beyond `canvas.js` dot-matrix and CSS hover effects
- A blog, docs, or pricing page
