# Dashboard Stats Overview — Design Spec

**Goal:** Add a stats block at the top of both the user dashboard and admin panel showing ticket counts by status with a segmented proportion bar.

**Architecture:** Pure PHP + CSS, no JS charts or external libraries. Stats are computed via a single GROUP BY SQL query per page load. The same visual component is used on both pages, scoped to the current user's tickets (user view) or all tickets (admin view).

**Tech Stack:** PHP 8, MySQL, PDO, CSS custom properties

---

## Data Layer

### User dashboard (`dashboard/user.php`)

One query added before the ticket list fetch:

```sql
SELECT status, COUNT(*) AS cnt
FROM tickets
WHERE user_id = :me
GROUP BY status
```

Results folded into:
```php
$stats = ['total' => 0, 'open' => 0, 'in_progress' => 0, 'closed' => 0];
foreach ($rows as $row) {
    $key = $row['status'] === 'in-progress' ? 'in_progress' : $row['status'];
    $stats[$key] = (int)$row['cnt'];
    $stats['total'] += (int)$row['cnt'];
}
```

### Admin panel (`admin/index.php`)

Two queries added before the ticket list fetch:

```sql
-- Status breakdown (all tickets)
SELECT status, COUNT(*) AS cnt FROM tickets GROUP BY status

-- Priority breakdown (all tickets)
SELECT priority, COUNT(*) AS cnt FROM tickets GROUP BY priority
```

Results folded into `$stats` (same shape as user) plus:
```php
$priority_stats = ['low' => 0, 'medium' => 0, 'high' => 0];
```

---

## UI Components

### Stat cards row

Four cards in a horizontal row: **Total**, **Open**, **In Progress**, **Closed**.

Each card:
- Large monospaced number (the count)
- Small label below
- Left border accent in status color: neutral (total), `--brand` (open), amber (in-progress), green (closed)

### Proportion bar

Full-width segmented bar below the cards:
- Three colored segments sized by percentage of total: Open (brand blue), In Progress (amber), Closed (green)
- Rounded ends on the full bar
- If total = 0: a solid gray placeholder bar at full width
- Legend row beneath: `● Open XX%  ● In Progress XX%  ● Closed XX%`

### Admin priority chips (admin only)

A small row of 3 chips below the proportion bar:
`Low: N  ·  Medium: N  ·  High: N`

---

## Layout & Responsiveness

- **Desktop (>600px):** 4-column grid for stat cards
- **Mobile (≤600px):** 2×2 grid for stat cards

Stats block sits between the `.main-head` and the `.tickets-toolbar`.

---

## Files Changed

| File | Change |
|------|--------|
| `dashboard/user.php` | Add stats query + stats block HTML |
| `admin/index.php` | Add stats queries (status + priority) + stats block HTML with priority chips |
| `public/css/dashboard.css` | Add `.stats-grid`, `.stat-card`, `.stat-card-value`, `.stat-card-label`, `.stat-bar`, `.stat-bar-segment`, `.stat-bar-legend`, `.stat-priority-row` |

---

## CSS Color Tokens

| Status | Color |
|--------|-------|
| Open | `var(--brand)` (indigo) |
| In Progress | `#F59E0B` (amber) |
| Closed | `#22C55E` (green) |
| Total | `var(--text-subtle)` |

---

## Edge Cases

- **Zero tickets:** Proportion bar renders as a full-width gray bar; percentages all show 0%.
- **All one status:** One segment fills the bar 100%, others are hidden (0 width).
- **Very small segment:** Minimum visual width is not enforced — a 1/100 segment may appear as a thin sliver, which is acceptable.
