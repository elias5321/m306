# Landing Page & Auth Pages — Live Animations Design Spec

**Goal:** Make the landing page and auth pages feel dynamic and "alive" through improved entrance animations, scroll reveals, hover interactions, button ripples, and a 3D tilt on the dashboard preview mockup.

**Architecture:** All changes are pure CSS + vanilla JS. The scroll reveal system (`[data-reveal]` / `.revealed`) and particle canvas already exist — we extend them rather than replace them. A shared ripple function is added to `landing.js`. Auth pages already load `canvas.js` (animated dot grid background) so no background work is needed there.

**Tech Stack:** Vanilla JS, CSS custom properties, CSS `@keyframes`, `IntersectionObserver` (already in place)

---

## What Already Exists (do not rebuild)

- `landing.js`: particle constellation canvas, `IntersectionObserver` scroll reveal, navbar scroll border, FAQ accordion
- `landing.css`: `[data-reveal]` / `.revealed` CSS transitions (opacity + translateY), testimonial card hover lift, feature card hover lift
- `canvas.js`: pulsing dot grid — already loads on auth pages
- All `[data-reveal]` and `[data-delay]` attributes already on `index.php` elements

---

## Changes Required

### 1. Improved stagger delays (`landing.css`)

Current delays (0.1s / 0.2s / 0.3s) are too small to feel dramatic. Replace with:

```css
[data-reveal][data-delay="1"] { transition-delay: 0.12s; }
[data-reveal][data-delay="2"] { transition-delay: 0.26s; }
[data-reveal][data-delay="3"] { transition-delay: 0.42s; }
[data-reveal][data-delay="4"] { transition-delay: 0.58s; }
```

Also increase the base translate distance from 24px to 32px and extend duration from 0.6s to 0.7s for more presence:

```css
[data-reveal] {
  opacity: 0;
  transform: translateY(32px);
  transition: opacity 0.7s cubic-bezier(0.16, 1, 0.3, 1),
              transform 0.7s cubic-bezier(0.16, 1, 0.3, 1);
}
[data-reveal].revealed { opacity: 1; transform: none; }
```

### 2. Feature card glow on hover (`landing.css`)

The `.feat-grid-card` already has a hover lift. Add a brand glow:

```css
.feat-grid-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 0 0 1px var(--brand), 0 12px 32px rgba(79, 70, 229, 0.18);
  border-color: var(--brand);
}
```

### 3. Button ripple effect (`landing.js` + `landing.css`)

A shared `addRipple(btn)` function attaches a click listener to a button. On click, it creates a `<span class="ripple">` positioned at the click coordinates, appends it to the button, and removes it after the animation completes (600ms).

Apply to all `.btn-primary`, `.btn-white`, `.btn-ghost` elements on the landing page via `document.querySelectorAll`.

CSS:
```css
.btn-primary, .btn-white, .btn-ghost { overflow: hidden; position: relative; }
.ripple {
  position: absolute;
  border-radius: 50%;
  transform: scale(0);
  animation: ripple-out 0.6s linear;
  background: rgba(255, 255, 255, 0.3);
  pointer-events: none;
}
@keyframes ripple-out {
  to { transform: scale(4); opacity: 0; }
}
```

For dark buttons (`.btn-primary`), ripple is white (rgba 255,255,255,0.3). For ghost buttons, use brand color (rgba 79,70,229,0.2).

### 4. Dashboard preview 3D tilt (`landing.js` + `landing.css`)

The `.preview-browser` element gets a subtle 3D tilt that follows the mouse, capped at ±6° on both axes. On `mouseleave`, it eases back to `rotateX(0) rotateY(0)`.

```css
.preview-browser {
  transform-style: preserve-3d;
  transition: transform 0.1s ease-out;
  will-change: transform;
}
```

JS logic:
```js
var preview = document.querySelector('.preview-browser');
if (preview) {
  preview.addEventListener('mousemove', function (e) {
    var rect = preview.getBoundingClientRect();
    var cx = rect.left + rect.width  / 2;
    var cy = rect.top  + rect.height / 2;
    var rx = ((e.clientY - cy) / (rect.height / 2)) * -6;
    var ry = ((e.clientX - cx) / (rect.width  / 2)) *  6;
    preview.style.transition = 'transform 0.1s ease-out';
    preview.style.transform  = 'perspective(800px) rotateX(' + rx + 'deg) rotateY(' + ry + 'deg)';
  });
  preview.addEventListener('mouseleave', function () {
    preview.style.transition = 'transform 0.6s cubic-bezier(0.16, 1, 0.3, 1)';
    preview.style.transform  = 'perspective(800px) rotateX(0deg) rotateY(0deg)';
  });
}
```

The `transition` is set inline per event: fast (0.1s) while tracking the mouse, slow ease-back (0.6s) on leave.

### 5. Auth form card entrance animation (`auth.css`)

The `.form-card` element fades in and scales up from 96% on page load:

```css
@keyframes card-enter {
  from { opacity: 0; transform: scale(0.96) translateY(12px); }
  to   { opacity: 1; transform: scale(1)    translateY(0); }
}
.form-card {
  animation: card-enter 0.4s cubic-bezier(0.16, 1, 0.3, 1) both;
}
```

### 6. Auth input focus glow (`auth.css`)

Add a smooth focus glow to `.input` on auth pages:

```css
.input {
  transition: border-color 200ms ease, box-shadow 200ms ease;
}
.input:focus {
  border-color: var(--brand);
  box-shadow: 0 0 0 3px var(--brand-soft);
  outline: none;
}
```

---

## Files Changed

| File | Change |
|------|--------|
| `public/css/landing.css` | Update `[data-reveal]` transitions; add feature card glow; add ripple CSS |
| `public/js/landing.js` | Add ripple function + attach to buttons; add preview tilt handler |
| `public/css/auth.css` | Add `card-enter` keyframe + `.form-card` animation; add `.input` focus glow |

---

## Out of Scope

- No changes to `canvas.js` (dot grid already runs on auth pages)
- No changes to `index.php` (all `[data-reveal]` attributes already in place)
- No changes to auth PHP files (purely CSS-driven)
- No external animation libraries
