-- ============================================================
--  TicketSystem — Add comments table
--  Run against the tickethub database after ticketsystem.sql
-- ============================================================

USE tickethub;

CREATE TABLE IF NOT EXISTS comments (
  id         INT          NOT NULL AUTO_INCREMENT,
  ticket_id  INT          NOT NULL,
  user_id    INT          NOT NULL,
  body       TEXT         NOT NULL,
  created_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_comments_ticket (ticket_id),
  KEY idx_comments_user   (user_id),

  CONSTRAINT fk_comments_ticket
    FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  CONSTRAINT fk_comments_user
    FOREIGN KEY (user_id)   REFERENCES users(id)   ON DELETE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
