-- ============================================================
--  TicketSystem — Database Setup
--  Run this on your AWS RDS MySQL instance (MySQL 8.0+)
--  Execute as the RDS master user
-- ============================================================

-- ── 1. Database ──────────────────────────────────────────────
CREATE DATABASE IF NOT EXISTS tickethub
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE tickethub;

-- ── 2. App user ───────────────────────────────────────────────
-- Replace 'TicketHub_2024!' with a strong password of your choice.
-- Also update config.php on the server to match.
CREATE USER IF NOT EXISTS 'tickethub_user'@'%'
  IDENTIFIED BY 'TicketHub_2024!';

GRANT SELECT, INSERT, UPDATE, DELETE
  ON tickethub.*
  TO 'tickethub_user'@'%';

FLUSH PRIVILEGES;

-- ── 3. Tables ─────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS users (
  id         INT UNSIGNED                 NOT NULL AUTO_INCREMENT,
  username   VARCHAR(50)                  NOT NULL,
  email      VARCHAR(150)                 NOT NULL,
  password   VARCHAR(255)                 NOT NULL,
  role       ENUM('user', 'admin')        NOT NULL DEFAULT 'user',
  created_at TIMESTAMP                    NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_username (username),
  UNIQUE KEY uq_email    (email)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS tickets (
  id          INT UNSIGNED                          NOT NULL AUTO_INCREMENT,
  user_id     INT UNSIGNED                          NOT NULL,
  title       VARCHAR(100)                          NOT NULL,
  description TEXT                                  NOT NULL,
  status      ENUM('open', 'in-progress', 'closed') NOT NULL DEFAULT 'open',
  priority    ENUM('low', 'medium', 'high')         NOT NULL DEFAULT 'medium',
  created_at  TIMESTAMP                             NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_user_id  (user_id),
  KEY idx_status   (status),
  KEY idx_priority (priority),
  KEY idx_created  (created_at),

  CONSTRAINT fk_tickets_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

-- ── 4. Default admin account ──────────────────────────────────
-- Username : admin
-- Email    : admin@example.com
-- Password : Admin1234!          ← CHANGE THIS AFTER FIRST LOGIN
--
-- To generate a new hash for a different password, run:
--   php -r "echo password_hash('YourNewPassword', PASSWORD_BCRYPT);"
-- Then replace the hash value below before executing.

INSERT INTO users (username, email, password, role) VALUES (
  'admin',
  'admin@example.com',
  '$2y$12$jMkMA7c.h08dba0k20PYYeMHGHtTPT0lgv8c8D0FesviUZupRBbgK',
  'admin'
);
