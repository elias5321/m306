<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config.php';

// If already logged in, go straight to the dashboard
if (is_logged_in()) {
    header('Location: /dashboard/user.php');
    exit();
}

$errors = [];
$email  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email    = trim($_POST['email']    ?? '');
    $password = $_POST['password']      ?? '';

    // Validate inputs
    if ($email === '') {
        $errors[] = 'Email is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Email is not valid.';
    }

    if ($password === '') {
        $errors[] = 'Password is required.';
    }

    // If no validation errors, check the database
    if (empty($errors)) {

        $stmt = $pdo->prepare('SELECT id, username, password FROM users WHERE email = :email LIMIT 1');
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {

            // Password is correct — log the user in
            session_regenerate_id(true); // prevent session fixation attacks

            $_SESSION['user_id']  = $user['id'];
            $_SESSION['username'] = $user['username'];

            header('Location: /dashboard/user.php');
            exit();

        } else {
            // Generic message — never say if it was the email or password that was wrong
            $errors[] = 'Invalid email or password.';
        }
    }
}

// Show flash message from register.php if there is one
$flash = $_SESSION['flash_success'] ?? null;
unset($_SESSION['flash_success']);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Log in — TicketHub</title>
</head>
<body>

<h1>Log in</h1>

<?php if ($flash): ?>
    <p><?php echo htmlspecialchars($flash); ?></p>
<?php endif; ?>

<?php if (!empty($errors)): ?>
    <ul>
        <?php foreach ($errors as $error): ?>
            <li><?php echo htmlspecialchars($error); ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>

<form method="POST" action="/auth/login.php">

    <div>
        Email *<br />
        <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required />
    </div>

    <div>
        Password *<br />
        <input type="password" name="password" required />
    </div>

    <div>
        <button type="submit">Log in</button>
    </div>

</form>

<p>Don't have an account? <a href="/auth/register.php">Register</a></p>

</body>
</html>
