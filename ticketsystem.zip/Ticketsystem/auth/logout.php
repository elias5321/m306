<?php

// ---------------------------------------------------------------------------
// auth/logout.php — Log the current user out and redirect to login
//
// No HTML here — this file is pure logic.
// A user reaches this page by clicking a "Log out" link/button.
// ---------------------------------------------------------------------------

// Step 1: Start (or resume) the session so we can work with it.
// session_start() is called inside session.php, so including it here is
// enough — we don't call session_start() twice.
require_once __DIR__ . '/../includes/session.php';

// Step 2: Clear all session variables from the $_SESSION array.
// This removes the stored data (user_id, username, etc.) from memory
// immediately, before the session record itself is deleted.
$_SESSION = [];

// Step 3: Delete the session cookie from the browser.
// session_destroy() removes the session data on the server, but the browser
// still holds a cookie with the session ID. If we leave that cookie in place,
// the browser will send the old (now invalid) session ID on the next request,
// which can cause confusing "ghost session" behaviour.
// We overwrite the cookie with an expiry time in the past to tell the browser
// to delete it right now.
if (ini_get('session.use_cookies')) {
    $cookie_params = session_get_cookie_params();
    setcookie(
        session_name(),         // the cookie name PHP chose (usually "PHPSESSID")
        '',                     // empty value — nothing to store
        time() - 42000,         // expiry in the past → browser deletes the cookie
        $cookie_params['path'],
        $cookie_params['domain'],
        $cookie_params['secure'],
        $cookie_params['httponly']
    );
}

// Step 4: Destroy the session record on the server.
// This deletes the session file (or DB row, depending on the handler) so the
// session ID that was in the cookie can never be reused — even if someone kept
// a copy of the old cookie value.
session_destroy();

// Step 5: Send the user to the login page.
// exit() is called right after header() so no further code runs accidentally.
header('Location: /auth/login.php');
exit();
