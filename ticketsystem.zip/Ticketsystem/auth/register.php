<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config.php';

// If already logged in, go to dashboard
if (is_logged_in()) {
    redirect_to_dashboard();
}

$errors   = [];
$username = '';
$email    = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Get inputs and trim whitespace
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email']    ?? '');
    $password = $_POST['password']      ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    // Validate username
    if ($username === '') {
        $errors[] = 'Username is required.';
    } elseif (strlen($username) < 3) {
        $errors[] = 'Username must be at least 3 characters.';
    } elseif (strlen($username) > 50) {
        $errors[] = 'Username cannot be longer than 50 characters.';
    } elseif (!ctype_alnum($username)) {
        $errors[] = 'Username may only contain letters and numbers.';
    }

    // Validate email
    if ($email === '') {
        $errors[] = 'Email is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Email is not valid.';
    }

    // Validate password
    if ($password === '') {
        $errors[] = 'Password is required.';
    } elseif (strlen($password) < 8) {
        $errors[] = 'Password must be at least 8 characters.';
    }

    // Validate confirm password
    if ($confirm === '') {
        $errors[] = 'Please confirm your password.';
    } elseif ($password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    }

    // Check for duplicate username or email
    if (empty($errors)) {
        $stmt = $pdo->prepare('SELECT username, email FROM users WHERE username = :username OR email = :email LIMIT 1');
        $stmt->execute([':username' => $username, ':email' => $email]);
        $existing = $stmt->fetch();

        if ($existing) {
            if ($existing['username'] === $username) {
                $errors[] = 'That username is already taken.';
            }
            if ($existing['email'] === $email) {
                $errors[] = 'An account with that email already exists.';
            }
        }
    }

    // Insert new user
    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_BCRYPT);

        $stmt = $pdo->prepare('INSERT INTO users (username, email, password) VALUES (:username, :email, :password)');
        $stmt->execute([':username' => $username, ':email' => $email, ':password' => $hash]);

        $_SESSION['flash_success'] = 'Account created! You can now log in.';
        header('Location: /auth/login.php');
        exit();
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Register — TicketHub</title>
</head>
<body>

<h1>Create an account</h1>

<?php if (!empty($errors)): ?>
    <ul>
        <?php foreach ($errors as $error): ?>
            <li><?php echo htmlspecialchars($error); ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>

<form method="POST" action="/auth/register.php">

    <div>
        Username *<br />
        <input type="text" name="username" value="<?php echo htmlspecialchars($username); ?>" required minlength="3" maxlength="50" />
    </div>

    <div>
        Email *<br />
        <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required maxlength="100" />
    </div>

    <div>
        Password *<br />
        <input type="password" name="password" required minlength="8" />
    </div>

    <div>
        Confirm password *<br />
        <input type="password" name="confirm_password" required minlength="8" />
    </div>

    <div>
        <button type="submit">Register</button>
    </div>

</form>

<p>Already have an account? <a href="/auth/login.php">Log in</a></p>

</body>
</html>
