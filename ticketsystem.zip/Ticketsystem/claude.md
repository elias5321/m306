# TicketHub – CLAUDE.md

## Project Overview
TicketHub is a PHP + MySQL ticket management system.
Two roles: Admin and User.
Language: English (UI), PHP backend, MySQL database.

---

## File Structure
```
tickethub/
├── config.php          # DB connection (PDO)
├── auth/
│   ├── login.php
│   ├── register.php
│   └── logout.php
├── dashboard/
│   ├── user.php        # Empty dashboard for users
│   └── admin.php       # Empty dashboard for admins
├── includes/
│   ├── session.php     # Session start + role check helpers
│   └── validate.php    # Server-side validation functions
└── sql/
    └── tickethub.sql   # Full DB schema
```

---

## Database
- Name: `tickethub`
- Use PDO only, never mysqli
- Config in `config.php`

### Tables to create:
```sql
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin', 'user') DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## Phase 1 – Build in this order:
1. `sql/tickethub.sql` – DB schema
2. `config.php` – PDO connection
3. `includes/session.php` – session helpers + role guards
4. `includes/validate.php` – reusable validation functions
5. `auth/register.php` – registration with validation
6. `auth/login.php` – login with validation
7. `auth/logout.php` – destroy session, redirect
8. `dashboard/user.php` – empty dashboard (role: user)
9. `dashboard/admin.php` – empty dashboard (role: admin)

---

## Authentication Rules
- After login → check role → redirect to correct dashboard
- `role = admin` → `dashboard/admin.php`
- `role = user` → `dashboard/user.php`
- Protect all dashboard pages: if not logged in → redirect to login
- Use `session_regenerate_id(true)` after successful login
- Passwords: `password_hash($pw, PASSWORD_BCRYPT)` on register
- Verify: `password_verify($pw, $hash)` on login

---

## Validation Rules

### Registration (client + server):
| Field    | Rules                                      |
|----------|--------------------------------------------|
| username | Required, 3–50 chars, alphanumeric only    |
| email    | Required, valid email format               |
| password | Required, min 8 chars                      |
| confirm  | Must match password                        |

### Login (client + server):
| Field    | Rules                 |
|----------|-----------------------|
| email    | Required, valid email |
| password | Required              |

### Client-side: HTML5 attributes (`required`, `minlength`, `type="email"`)
### Server-side: validate in `includes/validate.php`, show errors inline on form

---

## HTML Style Rules
Plain, minimal HTML only. No exceptions.

- No CSS frameworks (no Bootstrap, Tailwind, etc.)
- No external stylesheets unless explicitly asked
- No inline styles unless explicitly asked
- No JavaScript unless explicitly asked
- Native HTML elements only
- Labels as plain text with `<br />` before input
- Each field wrapped in `<div>`
- Always include `<!doctype html>`, `lang="en"`, charset + viewport meta
- Form method: `POST` for login/register

**Correct pattern:**
```html
<div>
  Email *<br />
  <input type="email" name="email" required />
</div>
```

---

## PHP Rules
- Always use PDO with prepared statements
- Never raw SQL / string concatenation in queries
- `htmlspecialchars()` on all output
- Validate server-side even if client-side exists
- No framework, pure PHP only
- Error messages shown inline on the form, not via alert/JS

---

## Security
- Never store plain text passwords
- Use `htmlspecialchars()` on all echoed user data
- Regenerate session ID on login
- Role check at top of every protected page
- No sensitive data in URLs

---

## What NOT to do
- No CSS styling unless asked
- No JavaScript unless asked
- No fancy UI, animations, gradients
- No OOP/classes unless asked — procedural PHP only
- Do not skip server-side validation
- Do not use `$_GET` for forms (use `$_POST`)
