<?php
// Database connection settings
$dbHost = '127.0.0.1'; // use TCP, not Unix socket — fixes caching_sha2_password on macOS
$dbName = 'tickethub';
$dbUser = 'tickethub_user';   // dedicated user, not root
$dbPass = 'TicketHub_2024!';  // change this to your actual password

// Connect to the database using PDO
try {
    $pdo = new PDO(
        "mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4",
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // throw errors as exceptions
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // return rows as arrays
            PDO::ATTR_EMULATE_PREPARES   => false,                  // use real prepared statements
        ]
    );
} catch (PDOException $e) {
    error_log('DB connection failed: ' . $e->getMessage()); // log the real error
    die('Could not connect to the database. Please try again later.');
}
