<?php
require_once __DIR__ . '/../includes/session.php';

// Only logged-in users can see this page
require_login();

// Username was saved in the session at login — no DB query needed here
$username = htmlspecialchars($_SESSION['username']);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dashboard — TicketHub</title>
</head>
<body>

<h1>Welcome, <?php echo $username; ?></h1>

<p>Your tickets will appear here.</p>

<p><a href="/auth/logout.php">Log out</a></p>

</body>
</html>
