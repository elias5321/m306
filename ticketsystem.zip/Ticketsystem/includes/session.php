<?php
// Start the session — must run before any HTML output
session_start();

// Check if a user is logged in
// Returns true if logged in, false if not
function is_logged_in() {
    return isset($_SESSION['user_id']) && $_SESSION['user_id'] !== '';
}

// Protect a page — if not logged in, redirect to login and stop
function require_login() {
    if (!is_logged_in()) {
        header('Location: /auth/login.php');
        exit();
    }
}
