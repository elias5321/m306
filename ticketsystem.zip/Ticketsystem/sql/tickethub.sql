-- Create the database
CREATE DATABASE IF NOT EXISTS tickethub
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE tickethub;

-- Users table (no role column — everyone is a regular user)
CREATE TABLE IF NOT EXISTS users (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    username   VARCHAR(50)  NOT NULL UNIQUE,
    email      VARCHAR(100) NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,           -- bcrypt hash, never plain text
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create a dedicated database user with only the permissions the app needs.
-- Never use root in an application — if the app gets hacked, the attacker
-- only gets SELECT/INSERT/UPDATE/DELETE, not full server control.
CREATE USER IF NOT EXISTS 'tickethub_user'@'localhost' IDENTIFIED BY 'TicketHub_2024!';
GRANT SELECT, INSERT, UPDATE, DELETE ON tickethub.* TO 'tickethub_user'@'localhost';
FLUSH PRIVILEGES;
